#pragma once
#include "../Nova.h"
#include "../math/Vec2.h"
#include <vector>
#include <functional>
#include <unordered_map>

namespace Nova {

// ═══════════════════════════════════════════════════════
//  INPUT MANAGER — نظام الإدخال الكامل
//  لمس + كيبورد + جيمباد + أكسليرومتر
// ═══════════════════════════════════════════════════════

// ── Key Codes ──
enum class Key : u32 {
    UNKNOWN=0,
    A=65,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,
    NUM0=48,NUM1,NUM2,NUM3,NUM4,NUM5,NUM6,NUM7,NUM8,NUM9,
    SPACE=32, ENTER=13, ESCAPE=27, TAB=9, BACKSPACE=8,
    LEFT=37,UP=38,RIGHT=39,DOWN=40,
    SHIFT=16,CTRL=17,ALT=18,
    F1=112,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,
    PLUS=187,MINUS=189,
};

// ── Touch Point ──
struct TouchPoint {
    u32   id       = 0;
    Vec2  position = Vec2::ZERO;
    Vec2  delta    = Vec2::ZERO;
    Vec2  startPos = Vec2::ZERO;
    f32   pressure = 1.0f;
    bool  active   = false;
    f32   downTime = 0.0f;
};

// ── Gamepad ──
struct GamepadState {
    bool  connected   = false;
    Vec2  leftStick   = Vec2::ZERO;
    Vec2  rightStick  = Vec2::ZERO;
    f32   leftTrigger = 0.0f;
    f32   rightTrigger= 0.0f;
    bool  buttons[16] = {};

    enum Button {
        A=0,B=1,X=2,Y=3,
        LB=4,RB=5,LT=6,RT=7,
        START=8,SELECT=9,
        DPAD_UP=10,DPAD_DOWN=11,DPAD_LEFT=12,DPAD_RIGHT=13,
        L3=14,R3=15
    };

    bool isPressed(Button b) const { return buttons[(u32)b]; }
};

// ── Virtual Joystick ──
struct VirtualJoystick {
    Vec2  center    = Vec2::ZERO;
    Vec2  current   = Vec2::ZERO;
    f32   radius    = 80.0f;
    f32   deadzone  = 0.1f;
    bool  active    = false;
    bool  visible   = true;
    u32   touchId   = 0;

    Vec2 getAxis() const {
        if(!active) return Vec2::ZERO;
        Vec2 dir  = current - center;
        f32  dist = dir.length();
        if(dist < deadzone * radius) return Vec2::ZERO;
        return (dir / radius).limit(1.0f);
    }

    bool contains(Vec2 pos) const {
        return (pos - center).length() <= radius * 1.5f;
    }
};

// ── Gesture ──
struct Gesture {
    enum Type { NONE, TAP, DOUBLE_TAP, LONG_PRESS, SWIPE, PINCH, ROTATE };
    Type  type      = NONE;
    Vec2  position  = Vec2::ZERO;
    Vec2  direction = Vec2::ZERO;  // For swipe
    f32   scale     = 1.0f;        // For pinch
    f32   rotation  = 0.0f;        // For rotate
    f32   velocity  = 0.0f;
};

// ── Action Mapping ──
struct InputAction {
    std::string name;
    std::vector<Key> keys;
    std::vector<u32> gamepadButtons;
    f32  value = 0.0f;
    bool held  = false;
    bool justPressed  = false;
    bool justReleased = false;
};

// ═══════════════════════════════════════════════════════
//  INPUT MANAGER
// ═══════════════════════════════════════════════════════
class InputManager {
public:
    static constexpr u32 MAX_TOUCHES = 10;

    // ── Callbacks ──
    std::function<void(const Gesture&)>      onGesture;
    std::function<void(Key, bool)>            onKey;
    std::function<void(u32, Vec2, bool)>      onTouch;
    std::function<void(Vec2)>                 onMouseMove;

    // ── Screen size (for normalizing) ──
    u32 screenW = 1920;
    u32 screenH = 1080;

    // ── Virtual Joysticks ──
    VirtualJoystick leftJoystick;
    VirtualJoystick rightJoystick;
    bool useVirtualJoysticks = false;

    // ── Init ──
    void init(u32 w, u32 h) {
        screenW = w; screenH = h;
        // Setup default virtual joysticks for mobile
        leftJoystick.center  = {w * 0.15f, h * 0.75f};
        rightJoystick.center = {w * 0.85f, h * 0.75f};
        leftJoystick.radius  = rightJoystick.radius = w * 0.08f;
        memset(_keyState, 0, sizeof(_keyState));
        memset(_keyPrev,  0, sizeof(_keyPrev));
    }

    // ── Frame Update ──
    void update(f32 dt) {
        // Update key just-pressed state
        for(u32 i=0;i<512;i++) {
            _keyJustPressed[i]  = _keyState[i] && !_keyPrev[i];
            _keyJustReleased[i] = !_keyState[i] && _keyPrev[i];
            _keyPrev[i] = _keyState[i];
        }

        // Update touch deltas
        for(auto& t : _touches) {
            if(t.active) {
                t.delta = t.position - _touchPrevPos[t.id];
                _touchPrevPos[t.id] = t.position;
                t.downTime += dt;
            }
        }

        // Update actions
        for(auto& [name, action] : _actions) {
            bool wasHeld = action.held;
            action.held = false;
            for(Key k : action.keys)
                if(isKeyHeld(k)) { action.held=true; break; }
            for(u32 b : action.gamepadButtons)
                if(_gamepad.buttons[b%16]) { action.held=true; break; }
            action.value = action.held ? 1.0f : 0.0f;
            action.justPressed  = action.held && !wasHeld;
            action.justReleased = !action.held && wasHeld;
        }

        // Detect gestures
        _detectGestures(dt);

        // Accelerometer gravity handling
        if(_accelEnabled) _updateAccel(dt);

        _time += dt;
    }

    // ── Key Input ──
    void onKeyEvent(u32 keycode, bool pressed) {
        if(keycode < 512) _keyState[keycode] = pressed;
        if(onKey) onKey((Key)keycode, pressed);
    }

    bool isKeyHeld    (Key k) const { u32 c=(u32)k; return c<512&&_keyState[c]; }
    bool isKeyPressed (Key k) const { u32 c=(u32)k; return c<512&&_keyJustPressed[c]; }
    bool isKeyReleased(Key k) const { u32 c=(u32)k; return c<512&&_keyJustReleased[c]; }

    // ── Touch Input ──
    void onTouchEvent(u32 id, Vec2 pos, bool down) {
        if(id >= MAX_TOUCHES) return;

        if(down) {
            _touches[id].id       = id;
            _touches[id].position = pos;
            _touches[id].startPos = pos;
            _touches[id].delta    = Vec2::ZERO;
            _touches[id].active   = true;
            _touches[id].downTime = 0;
            _touchPrevPos[id]     = pos;

            // Virtual joystick
            if(useVirtualJoysticks) {
                if(leftJoystick.contains(pos) && !leftJoystick.active) {
                    leftJoystick.active  = true;
                    leftJoystick.touchId = id;
                    leftJoystick.center  = pos;
                    leftJoystick.current = pos;
                } else if(rightJoystick.contains(pos) && !rightJoystick.active) {
                    rightJoystick.active  = true;
                    rightJoystick.touchId = id;
                    rightJoystick.center  = pos;
                    rightJoystick.current = pos;
                }
            }
        } else {
            _touches[id].active = false;
            if(leftJoystick.touchId == id)  { leftJoystick.active=false; leftJoystick.current=leftJoystick.center; }
            if(rightJoystick.touchId == id) { rightJoystick.active=false; rightJoystick.current=rightJoystick.center; }
        }

        if(onTouch) onTouch(id, pos, down);
    }

    void onTouchMove(u32 id, Vec2 pos) {
        if(id >= MAX_TOUCHES || !_touches[id].active) return;
        _touches[id].position = pos;

        if(useVirtualJoysticks) {
            if(leftJoystick.active  && leftJoystick.touchId==id)  leftJoystick.current=pos;
            if(rightJoystick.active && rightJoystick.touchId==id) rightJoystick.current=pos;
        }
    }

    const TouchPoint& getTouch(u32 id) const { return _touches[id]; }
    u32 getTouchCount() const {
        u32 n=0; for(auto& t:_touches) if(t.active) n++; return n;
    }
    bool isTouching() const { return getTouchCount() > 0; }

    Vec2 getLeftStick()  const {
        if(useVirtualJoysticks) return leftJoystick.getAxis();
        return _gamepad.leftStick;
    }
    Vec2 getRightStick() const {
        if(useVirtualJoysticks) return rightJoystick.getAxis();
        return _gamepad.rightStick;
    }

    // ── Mouse ──
    Vec2  getMousePos()     const { return _mousePos; }
    Vec2  getMouseDelta()   const { return _mouseDelta; }
    bool  isMouseDown(u32 btn=0)    const { return btn<3&&_mouseButtons[btn]; }
    bool  isMousePressed(u32 btn=0) const { return btn<3&&_mouseJustPressed[btn]; }

    void onMouseEvent(Vec2 pos, Vec2 delta, u32 btn, bool down) {
        _mouseDelta = delta;
        Vec2 prev = _mousePos;
        _mousePos  = pos;
        if(btn < 3) {
            _mouseJustPressed[btn]  = down && !_mouseButtons[btn];
            _mouseJustReleased[btn] = !down && _mouseButtons[btn];
            _mouseButtons[btn] = down;
        }
        if(onMouseMove) onMouseMove(pos);
    }

    f32 getMouseWheel() const { return _mouseWheel; }
    void onMouseWheel(f32 delta) { _mouseWheel = delta; }

    // ── Gamepad ──
    const GamepadState& getGamepad() const { return _gamepad; }
    void updateGamepad(const GamepadState& state) { _gamepad = state; }

    // ── Accelerometer ──
    Vec3 getAcceleration() const { return _accel; }
    Vec3 getTilt()         const { return _tilt; }
    void onAccelEvent(Vec3 accel) { _accelRaw=accel; }
    void enableAccelerometer(bool e) { _accelEnabled=e; }

    // ── Action Mapping ──
    void registerAction(const std::string& name,
                        std::vector<Key> keys={},
                        std::vector<u32> buttons={}) {
        InputAction a;
        a.name = name;
        a.keys = keys;
        a.gamepadButtons = buttons;
        _actions[name] = a;
    }

    bool isActionHeld    (const std::string& n) const { auto it=_actions.find(n); return it!=_actions.end()&&it->second.held; }
    bool isActionPressed (const std::string& n) const { auto it=_actions.find(n); return it!=_actions.end()&&it->second.justPressed; }
    bool isActionReleased(const std::string& n) const { auto it=_actions.find(n); return it!=_actions.end()&&it->second.justReleased; }
    f32  getActionValue  (const std::string& n) const { auto it=_actions.find(n); return it!=_actions.end()?it->second.value:0; }

    // ── Screen Resize ──
    void onResize(u32 w, u32 h) {
        screenW=w; screenH=h;
        leftJoystick.center  = {w*0.15f, h*0.75f};
        rightJoystick.center = {w*0.85f, h*0.75f};
        leftJoystick.radius  = rightJoystick.radius = w*0.08f;
    }

    // ── Gesture Result ──
    const Gesture& getLastGesture() const { return _lastGesture; }

private:
    TouchPoint  _touches[MAX_TOUCHES]    = {};
    Vec2        _touchPrevPos[MAX_TOUCHES]={};
    bool        _keyState[512]           = {};
    bool        _keyPrev[512]            = {};
    bool        _keyJustPressed[512]     = {};
    bool        _keyJustReleased[512]    = {};
    bool        _mouseButtons[3]         = {};
    bool        _mouseJustPressed[3]     = {};
    bool        _mouseJustReleased[3]    = {};
    Vec2        _mousePos                = Vec2::ZERO;
    Vec2        _mouseDelta              = Vec2::ZERO;
    f32         _mouseWheel              = 0.0f;
    GamepadState _gamepad;
    Vec3        _accelRaw = Vec3::ZERO;
    Vec3        _accel    = Vec3::ZERO;
    Vec3        _tilt     = Vec3::ZERO;
    bool        _accelEnabled = false;
    f32         _time     = 0.0f;
    Gesture     _lastGesture;
    std::unordered_map<std::string,InputAction> _actions;

    void _detectGestures(f32 dt) {
        u32 activeCount = getTouchCount();
        _lastGesture.type = Gesture::NONE;

        // Single touch gestures
        if(activeCount == 1) {
            auto& t = _touches[0];
            if(!t.active) { for(auto& tt:_touches) if(tt.active){t=tt;break;} }

            // Long press
            if(t.active && t.downTime > 0.5f &&
               (t.position-t.startPos).length() < 10.0f) {
                _lastGesture = {Gesture::LONG_PRESS, t.position};
                if(onGesture) onGesture(_lastGesture);
            }

            // Swipe
            if(!t.active && _time > 0) {
                Vec2 swipe = t.position - t.startPos;
                if(swipe.length() > 50.0f && t.downTime < 0.3f) {
                    _lastGesture.type      = Gesture::SWIPE;
                    _lastGesture.position  = t.startPos;
                    _lastGesture.direction = swipe.normalized();
                    _lastGesture.velocity  = swipe.length() / t.downTime;
                    if(onGesture) onGesture(_lastGesture);
                }
            }
        }

        // Pinch (2 fingers)
        if(activeCount == 2) {
            TouchPoint *t0=nullptr, *t1=nullptr;
            for(auto& t:_touches) {
                if(t.active){ if(!t0)t0=&t; else{t1=&t;break;} }
            }
            if(t0 && t1) {
                f32 dist    = (t1->position - t0->position).length();
                f32 prevDist= (t1->position-t1->delta - (t0->position-t0->delta)).length();
                if(fabsf(prevDist) > EPSILON) {
                    _lastGesture.type  = Gesture::PINCH;
                    _lastGesture.scale = dist / prevDist;
                    _lastGesture.position = (t0->position + t1->position) * 0.5f;
                    if(onGesture) onGesture(_lastGesture);
                }
            }
        }
    }

    void _updateAccel(f32 dt) {
        // Low-pass filter
        f32 alpha = 0.1f;
        _accel = _accel * (1-alpha) + _accelRaw * alpha;
        // Calculate tilt angles
        _tilt.x = atan2f(_accel.y, _accel.z) * RAD2DEG;
        _tilt.y = atan2f(-_accel.x, sqrtf(_accel.y*_accel.y+_accel.z*_accel.z)) * RAD2DEG;
    }
};

} // namespace Nova
