#pragma once
#include "../Nova.h"
#include "../renderer/SoftwareRenderer.h"
#include "../renderer/PerformanceTest.h"
#include "../platform/android/AndroidRenderer.h"
#include "../geometry/SceneGraph.h"
#include "../physics/PhysicsWorld.h"
#include "../particles/ParticleSystem.h"
#include "../audio/AudioEngine.h"
#include "../input/InputManager.h"
#include <functional>

namespace Nova {

// ═══════════════════════════════════════════════════════
//  NOVA ENGINE — الواجهة الرئيسية الموحدة
//  يجمع كل أنظمة المحرك في مكان واحد
// ═══════════════════════════════════════════════════════

struct EngineConfig {
    const char* appName     = "NOVA Game";
    u32         targetFPS   = 60;
    bool        autoQuality = true;   // اختيار الجودة تلقائياً
    bool        enablePhysics = true;
    bool        enableAudio   = true;
    bool        enableParticles = true;
    u32         maxParticles  = 8000;
    bool        mobileControls = true;
    Vec3        gravity       = {0,-9.81f,0};
};

class Engine {
public:
    // ── الأنظمة العامة ──
    AndroidRenderer  renderer;
    Scene            scene;
    PhysicsWorld     physics;
    ParticleSystem   particles;
    AudioEngine      audio;
    InputManager     input;
    QualityManager   quality;

    // ── Callbacks للعبة ──
    std::function<void()>      onInit;
    std::function<void(f32)>   onUpdate;
    std::function<void()>      onRender;
    std::function<void()>      onShutdown;

    // ── Init ──
    bool init(const EngineConfig& cfg = {}) {
        _config = cfg;

        // Renderer
        renderer.init(1280, 720);

        // Quality auto-detection
        if(cfg.autoQuality)
            quality.initialize(renderer.renderer);

        // Physics
        if(cfg.enablePhysics) {
            physics.gravity = cfg.gravity;
        }

        // Particles
        // (already initialized via constructor)

        // Audio
        if(cfg.enableAudio) {
            audio.init();
            _loadBuiltinSounds();
        }

        // Input
        input.init(1280, 720);
        input.useVirtualJoysticks = cfg.mobileControls;
        _registerDefaultActions();

        _running = true;
        _lastTime = _getCurrentTime();

        if(onInit) onInit();
        return true;
    }

    // ── Main Tick (يُستدعى كل فريم من Java/Kotlin) ──
    void tick() {
        if(!_running) return;

        u64 now = _getCurrentTime();
        f32 dt  = fminf((now - _lastTime) / 1e9f, 0.05f); // max 50ms
        _lastTime = now;
        _frameCount++;
        _accumTime += dt;

        // Fixed update (physics)
        _physicsAccum += dt;
        while(_physicsAccum >= physics.fixedStep) {
            if(_config.enablePhysics) physics.step(physics.fixedStep);
            _physicsAccum -= physics.fixedStep;
        }

        // Input
        input.update(dt);

        // User update
        if(onUpdate) onUpdate(dt);

        // Scene
        scene.update(dt);

        // Particles
        if(_config.enableParticles) particles.update(dt);

        // Audio
        if(_config.enableAudio) audio.mixFrame();

        // Render
        scene.applyLights(renderer.renderer);
        renderer.renderer.beginFrame();
        scene.render(renderer.renderer);
        if(_config.enableParticles) {
            // particles.render(renderer.renderer.getProcessor().getFramebuffer(), vp);
        }
        if(onRender) onRender();
        renderer.renderer.endFrame();
        renderer.present();

        // FPS tracking
        if(_accumTime >= 1.0f) {
            _fps = _frameCount / _accumTime;
            _frameCount = 0;
            _accumTime  = 0;
        }
    }

    void shutdown() {
        if(onShutdown) onShutdown();
        audio.shutdown();
        renderer.shutdown();
        _running = false;
    }

    // ── Getters ──
    f32  getFPS()        const { return _fps; }
    bool isRunning()     const { return _running; }
    u64  getFrameCount() const { return _frameCount; }
    const EngineConfig& getConfig() const { return _config; }

    // ── Screen Resize ──
    void onSurfaceChanged(u32 w, u32 h) {
        renderer.onSurfaceChanged(w, h);
        input.onResize(w, h);
    }

    // ── Touch passthrough ──
    void onTouchDown(f32 x, f32 y, u32 id) { input.onTouchEvent(id,{x,y},true); }
    void onTouchMove(f32 x, f32 y, u32 id) { input.onTouchMove(id,{x,y}); }
    void onTouchUp(u32 id) { input.onTouchEvent(id,{},false); }

private:
    EngineConfig _config;
    bool  _running      = false;
    u64   _lastTime     = 0;
    u64   _frameCount   = 0;
    f32   _fps          = 0.0f;
    f32   _accumTime    = 0.0f;
    f32   _physicsAccum = 0.0f;

    void _loadBuiltinSounds() {
        audio.loadBuffer("explosion", SoundBuffer::generateExplosion());
        audio.loadBuffer("gunshot",   SoundBuffer::generateGunshot());
        audio.loadBuffer("engine",    SoundBuffer::generateEngine(3000));
        audio.loadBuffer("whoosh",    SoundBuffer::generateWhoosh());
    }

    void _registerDefaultActions() {
        input.registerAction("fire",       {Key::SPACE},      {(u32)GamepadState::A});
        input.registerAction("jump",       {Key::UP},         {(u32)GamepadState::B});
        input.registerAction("moveLeft",   {Key::LEFT, Key::A},{});
        input.registerAction("moveRight",  {Key::RIGHT,Key::D},{});
        input.registerAction("moveForward",{Key::UP,  Key::W}, {});
        input.registerAction("moveBack",   {Key::DOWN, Key::S},{});
        input.registerAction("throttleUp", {Key::W},           {});
        input.registerAction("throttleDown",{Key::S},          {});
        input.registerAction("pause",      {Key::ESCAPE},     {(u32)GamepadState::START});
    }

    u64 _getCurrentTime() {
#ifdef NOVA_PLATFORM_ANDROID
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        return (u64)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
#else
        return (u64)(0); // Desktop fallback
#endif
    }
};

// ── Global Engine Instance ──
inline Engine& getEngine() {
    static Engine instance;
    return instance;
}

} // namespace Nova

// ═══════════════════════════════════════════════════════
//  JNI Entry Points (Android)
// ═══════════════════════════════════════════════════════
#ifdef NOVA_PLATFORM_ANDROID
extern "C" {

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_engineInit(JNIEnv* env, jobject, jobject surface) {
    Nova::EngineConfig cfg;
    cfg.autoQuality    = true;
    cfg.mobileControls = true;
    cfg.enableAudio    = true;
    cfg.enablePhysics  = true;

    auto& eng = Nova::getEngine();
    eng.init(cfg);

    ANativeWindow* win = ANativeWindow_fromSurface(env, surface);
    eng.renderer.init(win);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_engineTick(JNIEnv*, jobject) {
    Nova::getEngine().tick();
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_engineShutdown(JNIEnv*, jobject) {
    Nova::getEngine().shutdown();
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_engineSurfaceChanged(JNIEnv*,jobject,jint w,jint h) {
    Nova::getEngine().onSurfaceChanged(w,h);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_engineTouchDown(JNIEnv*,jobject,jfloat x,jfloat y,jint id) {
    Nova::getEngine().onTouchDown(x,y,id);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_engineTouchMove(JNIEnv*,jobject,jfloat x,jfloat y,jint id) {
    Nova::getEngine().onTouchMove(x,y,id);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_engineTouchUp(JNIEnv*,jobject,jint id) {
    Nova::getEngine().onTouchUp(id);
}

} // extern "C"
#endif
