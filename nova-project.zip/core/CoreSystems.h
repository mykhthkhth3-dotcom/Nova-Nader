#pragma once
#include "../Nova.h"
#include <cstdio>
#include <ctime>
#include <queue>
#include <thread>
#include <condition_variable>

#ifdef NOVA_PLATFORM_ANDROID
    #include <android/log.h>
    #define NOVA_LOG_TAG "NOVAEngine"
#endif

namespace Nova {

// ══════════════════════════════════
//  LOGGER
// ══════════════════════════════════
class Logger {
public:
    enum Level { DEBUG=0, INFO, WARN, ERROR, FATAL };
    static Level minLevel;

    static void log(Level lvl, const char* fmt, ...) {
        if(lvl < minLevel) return;
        char buf[1024];
        va_list args; va_start(args,fmt);
        vsnprintf(buf,sizeof(buf),fmt,args);
        va_end(args);

        const char* tags[]={"DEBUG","INFO","WARN","ERROR","FATAL"};
#ifdef NOVA_PLATFORM_ANDROID
        int aprio[]={ANDROID_LOG_DEBUG,ANDROID_LOG_INFO,ANDROID_LOG_WARN,
                     ANDROID_LOG_ERROR,ANDROID_LOG_FATAL};
        __android_log_print(aprio[lvl], NOVA_LOG_TAG, "[%s] %s", tags[lvl], buf);
#else
        printf("[NOVA/%s] %s\n", tags[lvl], buf);
        fflush(stdout);
#endif
    }

    static void Debug(const char* fmt,...){ va_list a;va_start(a,fmt);char b[512];vsnprintf(b,512,fmt,a);va_end(a);log(DEBUG,"%s",b); }
    static void Info (const char* fmt,...){ va_list a;va_start(a,fmt);char b[512];vsnprintf(b,512,fmt,a);va_end(a);log(INFO, "%s",b); }
    static void Warn (const char* fmt,...){ va_list a;va_start(a,fmt);char b[512];vsnprintf(b,512,fmt,a);va_end(a);log(WARN, "%s",b); }
    static void Error(const char* fmt,...){ va_list a;va_start(a,fmt);char b[512];vsnprintf(b,512,fmt,a);va_end(a);log(ERROR,"%s",b); }
    static void Fatal(const char* fmt,...){ va_list a;va_start(a,fmt);char b[512];vsnprintf(b,512,fmt,a);va_end(a);log(FATAL,"%s",b); abort(); }
};
inline Logger::Level Logger::minLevel = Logger::INFO;

// ══════════════════════════════════
//  TIMER
// ══════════════════════════════════
class Timer {
public:
    static u64 now() {
#ifdef NOVA_PLATFORM_ANDROID
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC,&ts);
        return (u64)ts.tv_sec*1000000000ULL+ts.tv_nsec;
#else
        return (u64)(clock()*1000000ULL/CLOCKS_PER_SEC)*1000ULL;
#endif
    }
    static f32 elapsed(u64 start) { return (f32)(now()-start)/1e9f; }
    static f32 elapsedMs(u64 start){ return (f32)(now()-start)/1e6f; }

    void start() { _start=now(); }
    f32  getElapsed()   const { return elapsed(_start); }
    f32  getElapsedMs() const { return elapsedMs(_start); }
    void reset() { _start=now(); }

private:
    u64 _start = 0;
};

// ══════════════════════════════════
//  EVENT SYSTEM
// ══════════════════════════════════
struct Event {
    u32 type;
    union {
        struct { f32 x,y; u32 id; } touch;
        struct { u32 keycode; bool pressed; } key;
        struct { f32 value; } axis;
        struct { void* data; u32 size; } custom;
    };
};

class EventSystem {
public:
    using Handler = std::function<void(const Event&)>;

    void subscribe(u32 type, Handler handler) {
        _handlers[type].push_back(handler);
    }
    void emit(const Event& e) {
        std::lock_guard<std::mutex> lock(_mutex);
        _queue.push(e);
    }
    void dispatch() {
        std::queue<Event> q;
        { std::lock_guard<std::mutex> lock(_mutex); std::swap(q,_queue); }
        while(!q.empty()){
            auto& e=q.front();
            auto it=_handlers.find(e.type);
            if(it!=_handlers.end())
                for(auto& h:it->second) h(e);
            q.pop();
        }
    }
    void clear() {
        std::lock_guard<std::mutex> lock(_mutex);
        while(!_queue.empty()) _queue.pop();
        _handlers.clear();
    }
private:
    std::unordered_map<u32,std::vector<Handler>> _handlers;
    std::queue<Event> _queue;
    std::mutex _mutex;
};

// ══════════════════════════════════
//  JOB SYSTEM (Thread Pool)
// ══════════════════════════════════
class JobSystem {
public:
    explicit JobSystem(u32 threads=0){
        u32 n=threads>0?threads:std::max(1u,(u32)std::thread::hardware_concurrency()-1);
        _running=true;
        for(u32 i=0;i<n;i++)
            _workers.emplace_back([this]{ _workerLoop(); });
    }
    ~JobSystem(){
        {std::lock_guard<std::mutex> lock(_mutex); _running=false;}
        _cv.notify_all();
        for(auto& t:_workers) if(t.joinable()) t.join();
    }
    void submit(std::function<void()> job){
        {std::lock_guard<std::mutex> lock(_mutex); _jobs.push(std::move(job));}
        _cv.notify_one();
    }
    void waitAll(){
        while(_pending.load()>0) std::this_thread::yield();
    }
    u32 getThreadCount() const { return (u32)_workers.size(); }
private:
    std::vector<std::thread> _workers;
    std::queue<std::function<void()>> _jobs;
    std::mutex _mutex;
    std::condition_variable _cv;
    std::atomic<bool> _running{false};
    std::atomic<u32>  _pending{0};
    void _workerLoop(){
        while(true){
            std::function<void()> job;
            {std::unique_lock<std::mutex> lock(_mutex);
             _cv.wait(lock,[this]{return !_jobs.empty()||!_running;});
             if(!_running&&_jobs.empty()) return;
             job=std::move(_jobs.front()); _jobs.pop();}
            _pending++;
            job();
            _pending--;
        }
    }
};

// ══════════════════════════════════
//  UUID
// ══════════════════════════════════
struct UUID {
    u64 lo=0, hi=0;
    bool operator==(const UUID& o) const { return lo==o.lo&&hi==o.hi; }
    bool operator!=(const UUID& o) const { return !(*this==o); }
    bool isNull() const { return lo==0&&hi==0; }
    static UUID generate(){
        static std::atomic<u64> counter{1};
        UUID id;
        id.lo = counter++;
        id.hi = (u64)Timer::now();
        return id;
    }
    std::string toString() const {
        char buf[32]; snprintf(buf,sizeof(buf),"%016llx%016llx",(unsigned long long)hi,(unsigned long long)lo);
        return buf;
    }
};

// ══════════════════════════════════
//  FILE SYSTEM
// ══════════════════════════════════
class FileSystem {
public:
    static std::string assetPath;

    static bool exists(const std::string& path){
        FILE* f=fopen(path.c_str(),"r");
        if(f){fclose(f);return true;} return false;
    }
    static std::vector<byte> readAll(const std::string& path){
        FILE* f=fopen(path.c_str(),"rb");
        if(!f) return {};
        fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
        std::vector<byte> buf(sz);
        fread(buf.data(),1,sz,f); fclose(f);
        return buf;
    }
    static std::string readText(const std::string& path){
        auto b=readAll(path);
        return std::string(b.begin(),b.end());
    }
    static bool writeAll(const std::string& path, const void* data, usize size){
        FILE* f=fopen(path.c_str(),"wb");
        if(!f) return false;
        fwrite(data,1,size,f); fclose(f); return true;
    }
    static bool writeText(const std::string& path, const std::string& text){
        return writeAll(path,text.c_str(),text.size());
    }
    static std::string getAssetPath(const std::string& name){
        return assetPath + "/" + name;
    }
};
inline std::string FileSystem::assetPath = "/data/local/tmp";

} // namespace Nova
