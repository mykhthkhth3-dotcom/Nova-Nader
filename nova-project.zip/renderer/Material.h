#pragma once
#include "../Nova.h"
#include "PixelProcessor.h"

namespace Nova {

// ═══════════════════════════════════════════════════════
//  MATERIAL — مادة السطح (PBR بالكود)
// ═══════════════════════════════════════════════════════

class Material {
public:
    // PBR Properties
    Vec4  albedo          = Vec4::WHITE;
    f32   metallic        = 0.0f;
    f32   roughness       = 0.5f;
    f32   specularStrength= 0.5f;
    f32   shininess       = 32.0f;
    f32   emissive        = 0.0f;
    Vec3  emissiveColor   = Vec3::ZERO;
    f32   opacity         = 1.0f;

    // معادلات RGB المخصصة
    bool  useCustomEquation = false;
    i16   eqRA=0, eqGA=0, eqBA=0;
    u8    eqRB=1, eqGB=1, eqBB=1;

    // Shader function
    PixelProcessor::PixelShaderFn getShader() const {
        if(useCustomEquation)
            return _equationShader;
        return _pbrShader;
    }

    // ── Built-in Shaders ──
    static Pixel _pbrShader(
        u32 x, u32 y, f32 u, f32 v,
        const Vec3& wp, const Vec3& n,
        const Vec4& color, f32 depth, void* ud)
    {
        Material* mat = static_cast<Material*>(ud);
        if(!mat) return Pixel::fromFloat(color.x, color.y, color.z);

        Vec4 base = mat->albedo * color;

        // Simple PBR approximation
        f32 metalFactor = mat->metallic;
        f32 roughFactor = mat->roughness;

        // Fresnel approximation (Schlick)
        Vec3 norm = n.isZero() ? Vec3::UP : n;
        f32  ndv  = fmaxf(0.0f, norm.dot(Vec3(0,0,1)));
        f32  fresnel = metalFactor + (1.0f - metalFactor) * powf(1.0f - ndv, 5.0f);

        // Mix diffuse and specular
        Vec3 diffuse  = base.rgb() * (1.0f - metalFactor);
        Vec3 specular = Vec3(fresnel) * (1.0f - roughFactor);
        Vec3 result   = (diffuse + specular).clamp(0,1);

        // Emissive
        if(mat->emissive > 0) {
            result = result + mat->emissiveColor * mat->emissive;
            result = result.clamp(0,1);
        }

        return Pixel::fromFloat(result.x, result.y, result.z, mat->opacity);
    }

    static Pixel _equationShader(
        u32 x, u32 y, f32 u, f32 v,
        const Vec3& wp, const Vec3& n,
        const Vec4& color, f32 depth, void* ud)
    {
        Material* mat = static_cast<Material*>(ud);
        if(!mat) return Pixel::fromFloat(color.x, color.y, color.z);

        // تطبيق المعادلات الثلاث على كل بكسل
        // R = (RA × RB) → clamp(0,999) → map to 0-255
        i32 R = (i32)mat->eqRA * (i32)mat->eqRB;
        i32 G = (i32)mat->eqGA * (i32)mat->eqGB;
        i32 B = (i32)mat->eqBA * (i32)mat->eqBB;

        // تعديل بناءً على موقع البكسل (gradient/pattern)
        f32 px = (f32)x / 1920.0f;
        f32 py = (f32)y / 1080.0f;
        R = (i32)(R * (0.8f + px * 0.4f));
        G = (i32)(G * (0.8f + py * 0.4f));
        B = (i32)(B * (0.8f + (px+py)*0.2f));

        // Clamp إلى 0-999 ثم تحويل لـ 0-255
        R = Nova::clampi(R, 0, 999);
        G = Nova::clampi(G, 0, 999);
        B = Nova::clampi(B, 0, 999);

        // Map 0-999 → 0-255
        u8 fr = (u8)(R * 255 / 999);
        u8 fg = (u8)(G * 255 / 999);
        u8 fb = (u8)(B * 255 / 999);

        // طباعة RRRGGGBBB للتشخيص (مثال: 009212189)
        // u32 rgbStr = (u32)R*1000000 + (u32)G*1000 + (u32)B;

        // دمج مع لون القاعدة
        return {
            (u8)(fr * color.x),
            (u8)(fg * color.y),
            (u8)(fb * color.z),
            (u8)(mat->opacity * 255)
        };
    }
};

// ═══════════════════════════════════════════════════════
//  LIGHT — مصدر الإضاءة
// ═══════════════════════════════════════════════════════
struct Light {
    enum Type { DIRECTIONAL = 0, POINT = 1, SPOT = 2 };

    Type  type       = DIRECTIONAL;
    Vec3  position   = {0, 10, 0};
    Vec3  direction  = {0, -1, 0};
    Vec3  color      = {1, 1, 1};
    f32   intensity  = 1.0f;
    f32   attenuation= 0.01f;
    f32   spotAngle  = 30.0f;
    bool  castShadow = false;

    static Light directional(const Vec3& dir, const Vec3& color={1,1,1}, f32 intensity=1.0f) {
        Light l; l.type=DIRECTIONAL; l.direction=dir.normalized();
        l.color=color; l.intensity=intensity;
        return l;
    }
    static Light point(const Vec3& pos, const Vec3& color={1,1,1}, f32 intensity=1.0f, f32 att=0.01f) {
        Light l; l.type=POINT; l.position=pos;
        l.color=color; l.intensity=intensity; l.attenuation=att;
        return l;
    }
};

} // namespace Nova
