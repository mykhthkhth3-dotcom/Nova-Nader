#pragma once
#include "../Nova.h"
#include "SoftwareRenderer.h"

namespace Nova {

// ═══════════════════════════════════════════════════════
//  PERFORMANCE TEST SYSTEM — الجلسة الثامنة
//  اختبار قدرة المعالج على معالجة البكسلات
//  يختار الجودة التلقائية (حد أدنى 20fps)
// ═══════════════════════════════════════════════════════

enum class QualityLevel {
    Q480P    = 0,  // 854  × 480
    Q720P    = 1,  // 1280 × 720
    Q1080P   = 2,  // 1920 × 1080
    Q2K_FAKE = 3,  // 2048 × 1080  (2K غير حقيقي - عرض فقط)
    Q2K_REAL = 4,  // 2560 × 1440  (2K حقيقي QHD)
    Q4K      = 5,  // 3840 × 2160
    COUNT    = 6
};

struct QualityInfo {
    const char* name;
    u32 width;
    u32 height;
    u32 pixels;
};

constexpr QualityInfo QUALITY_TABLE[(u32)QualityLevel::COUNT] = {
    { "480p",         854,  480,  854*480   },
    { "720p",        1280,  720, 1280*720   },
    { "1080p",       1920, 1080, 1920*1080  },
    { "2K (غير حقيقي)", 2048, 1080, 2048*1080 },
    { "2K (حقيقي QHD)", 2560, 1440, 2560*1440 },
    { "4K UHD",      3840, 2160, 3840*2160  },
};

struct BenchmarkResult {
    QualityLevel quality;
    f32 fps;
    f32 frameTimeMs;
    u32 pixelsPerSecond;
    bool aboveThreshold;  // > 20fps
};

class PerformanceTest {
public:
    static constexpr f32 MIN_FPS       = 20.0f;
    static constexpr u32 WARMUP_FRAMES = 3;
    static constexpr u32 TEST_FRAMES   = 10;

    // ── تشغيل الاختبار الكامل ──
    void runFullBenchmark(SoftwareRenderer& renderer,
                          std::function<void(const BenchmarkResult&)> onResult)
    {
        _results.clear();
        _bestQuality = QualityLevel::Q480P;
        _running = true;

        for(u32 q = 0; q < (u32)QualityLevel::COUNT; q++) {
            QualityLevel ql = (QualityLevel)q;
            BenchmarkResult res = _testQuality(renderer, ql);
            _results.push_back(res);

            if(onResult) onResult(res);

            // إذا FPS تحت 20 توقف هنا
            if(!res.aboveThreshold) {
                break;
            }
            _bestQuality = ql;
        }

        _running = false;
        _benchmarkDone = true;
    }

    // ── اختبار جودة واحدة ──
    BenchmarkResult testSingleQuality(SoftwareRenderer& renderer, QualityLevel ql) {
        return _testQuality(renderer, ql);
    }

    // ── الحصول على أفضل جودة مدعومة ──
    QualityLevel getBestQuality() const { return _bestQuality; }
    bool isDone() const { return _benchmarkDone; }

    // ── نتائج كاملة ──
    const std::vector<BenchmarkResult>& getResults() const { return _results; }

    // ── توصية الجودة ──
    static const char* getQualityName(QualityLevel q) {
        return QUALITY_TABLE[(u32)q].name;
    }

    // ── تقرير نصي كامل ──
    std::string generateReport() const {
        std::string report = "═══ تقرير أداء NOVA Engine ═══\n\n";
        for(const auto& r : _results) {
            const QualityInfo& qi = QUALITY_TABLE[(u32)r.quality];
            char line[256];
            snprintf(line, sizeof(line),
                "%-20s │ %dx%d │ %5.1f fps │ %.2f ms │ %s\n",
                qi.name, qi.width, qi.height,
                r.fps, r.frameTimeMs,
                r.aboveThreshold ? "✓ مدعوم" : "✗ بطيء جداً"
            );
            report += line;
        }
        report += "\n═══ أفضل جودة مدعومة: ";
        report += QUALITY_TABLE[(u32)_bestQuality].name;
        report += " ═══\n";
        return report;
    }

private:
    std::vector<BenchmarkResult> _results;
    QualityLevel _bestQuality = QualityLevel::Q480P;
    bool _running       = false;
    bool _benchmarkDone = false;

    BenchmarkResult _testQuality(SoftwareRenderer& renderer, QualityLevel ql) {
        const QualityInfo& qi = QUALITY_TABLE[(u32)ql];

        // تغيير الدقة
        renderer.resize(qi.width, qi.height);

        // Warmup frames
        for(u32 i = 0; i < WARMUP_FRAMES; i++) {
            _renderTestFrame(renderer);
        }

        // قياس الوقت
        f32 totalTime = 0.0f;
        for(u32 i = 0; i < TEST_FRAMES; i++) {
            u64 start = Timer::now();
            _renderTestFrame(renderer);
            totalTime += Timer::elapsed(start);
        }

        f32 avgFrameTime = totalTime / TEST_FRAMES;
        f32 fps = avgFrameTime > 0 ? 1.0f / avgFrameTime : 0.0f;

        BenchmarkResult res;
        res.quality        = ql;
        res.fps            = fps;
        res.frameTimeMs    = avgFrameTime * 1000.0f;
        res.pixelsPerSecond= (u32)((f32)qi.pixels * fps);
        res.aboveThreshold = fps >= MIN_FPS;
        return res;
    }

    void _renderTestFrame(SoftwareRenderer& renderer) {
        renderer.beginFrame();

        // اختبار معالجة بكسل كاملة مع معادلات RGB
        renderer.getProcessor().processAllPixels(
            [](u32 x, u32 y, f32 u, f32 v,
               const Vec3& wp, const Vec3& n,
               const Vec4& col, f32 depth, void* ud) -> Pixel
            {
                // معادلة R: (47 × 3) = 141 → clamp → 141
                // معادلة G: (62 × 2) = 124 → clamp → 124
                // معادلة B: (89 × 1) = 089 → clamp → 089
                // النتيجة: 141124089

                i32 R = (i32)(47 * (1 + (u32)(u * 9) % 9));
                i32 G = (i32)(62 * (1 + (u32)(v * 9) % 9));
                i32 B = (i32)(89 * (1 + (u32)((u+v)*4.5f) % 9));

                // Wave pattern للاختبار
                f32 wave = sinf(u * 20.0f) * cosf(v * 20.0f);
                R = (i32)(R * (0.5f + wave * 0.5f));
                G = (i32)(G * (0.5f + cosf(u*15+v*10) * 0.5f));
                B = (i32)(B * (0.5f + sinf((u+v)*12) * 0.5f));

                return Pixel::fromEquationResult(
                    (u32)Nova::clampi(R, 0, 999),
                    (u32)Nova::clampi(G, 0, 999),
                    (u32)Nova::clampi(B, 0, 999)
                );
            }
        );

        renderer.endFrame();
    }
};

// ═══════════════════════════════════════════════════════
//  QUALITY MANAGER — يدير الجودة التلقائية في اللعبة
// ═══════════════════════════════════════════════════════
class QualityManager {
public:
    void initialize(SoftwareRenderer& renderer) {
        // تشغيل الاختبار عند أول تشغيل
        _test.runFullBenchmark(renderer, [this](const BenchmarkResult& r) {
            _onBenchmarkResult(r);
        });
        _applyBestQuality(renderer);
    }

    QualityLevel getCurrentQuality() const { return _current; }

    void setQuality(SoftwareRenderer& renderer, QualityLevel ql) {
        _current = ql;
        const QualityInfo& qi = QUALITY_TABLE[(u32)ql];
        renderer.resize(qi.width, qi.height);
    }

    // يسمح للمستخدم باختيار يدوي فقط من الجودات المدعومة
    bool isQualitySupported(QualityLevel ql) const {
        return (u32)ql <= (u32)_test.getBestQuality();
    }

    const PerformanceTest& getTest() const { return _test; }

private:
    PerformanceTest _test;
    QualityLevel    _current = QualityLevel::Q480P;

    void _onBenchmarkResult(const BenchmarkResult& r) {
        // Log result
        const QualityInfo& qi = QUALITY_TABLE[(u32)r.quality];
        Logger::Info("Benchmark %s: %.1f fps (%s)",
            qi.name, r.fps,
            r.aboveThreshold ? "OK" : "TOO SLOW");
    }

    void _applyBestQuality(SoftwareRenderer& renderer) {
        _current = _test.getBestQuality();
        const QualityInfo& qi = QUALITY_TABLE[(u32)_current];
        renderer.resize(qi.width, qi.height);
        Logger::Info("Auto quality set to: %s (%dx%d)",
            qi.name, qi.width, qi.height);
    }
};

} // namespace Nova
