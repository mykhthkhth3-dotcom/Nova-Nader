#pragma once
#include "../Nova.h"

// ARM NEON SIMD for Android
#if defined(__ARM_NEON) || defined(__ARM_NEON__)
    #include <arm_neon.h>
    #define NOVA_NEON 1
#endif

namespace Nova {

// ═══════════════════════════════════════════════════════
//  NOVA PIXEL PROCESSOR
//  نظام معالجة البكسل المخصص - بدون OpenGL ES
//  كل بكسل يُحسب بـ 3 معادلات RGB
//
//  المعادلة:
//    R = clamp3( (A2 × B1), 0, 255 )   → 3 خانات
//    G = clamp3( (C2 × D1), 0, 255 )   → 3 خانات
//    B = clamp3( (E2 × F1), 0, 255 )   → 3 خانات
//    النتيجة: RRRGGGBBB مثل 009212189
//
//  مُحسَّن بـ ARM NEON SIMD (16 بكسل في آن واحد)
// ═══════════════════════════════════════════════════════

// ── Pixel RGB (نتيجة المعادلات الثلاث) ──
struct Pixel {
    u8 r, g, b, a;

    constexpr Pixel() : r(0), g(0), b(0), a(255) {}
    constexpr Pixel(u8 r, u8 g, u8 b, u8 a=255) : r(r), g(g), b(b), a(a) {}

    // من نتيجة المعادلات الثلاث (RRRGGGBBB)
    static Pixel fromEquationResult(u32 R3, u32 G3, u32 B3) {
        return {
            (u8)Nova::clamp3(R3, 0u, 255u),
            (u8)Nova::clamp3(G3, 0u, 255u),
            (u8)Nova::clamp3(B3, 0u, 255u),
            255
        };
    }

    // طباعة كـ RRRGGGBBB
    u32 toEquationString() const {
        return (u32)r * 1000000 + (u32)g * 1000 + (u32)b;
    }

    // Blend مع بكسل آخر
    Pixel blend(const Pixel& over) const {
        f32 a = over.a / 255.0f;
        f32 ia = 1.0f - a;
        return {
            (u8)(over.r * a + r * ia),
            (u8)(over.g * a + g * ia),
            (u8)(over.b * a + b * ia),
            255
        };
    }

    // تحويل من float [0,1]
    static Pixel fromFloat(f32 r, f32 g, f32 b, f32 a=1.0f) {
        return {
            (u8)(Nova::clampf(r,0,1)*255),
            (u8)(Nova::clampf(g,0,1)*255),
            (u8)(Nova::clampf(b,0,1)*255),
            (u8)(Nova::clampf(a,0,1)*255)
        };
    }

    Vec4 toFloat() const {
        return { r/255.0f, g/255.0f, b/255.0f, a/255.0f };
    }
};

// ── معاملات المعادلة لكل بكسل ──
struct PixelEquation {
    // R = (RA * RB) → clamp → 3 خانات
    i16 RA;  // رقم خانتين (-99 إلى 99)
    u8  RB;  // رقم خانة واحدة (0 إلى 9)
    // G = (GA * GB)
    i16 GA;
    u8  GB;
    // B = (BA * BB)
    i16 BA;
    u8  BB;

    // حساب الناتج
    Pixel evaluate() const {
        i32 R = (i32)RA * (i32)RB;
        i32 G = (i32)GA * (i32)GB;
        i32 B = (i32)BA * (i32)BB;
        return Pixel::fromEquationResult(
            (u32)Nova::clampi(R, 0, 999),
            (u32)Nova::clampi(G, 0, 999),
            (u32)Nova::clampi(B, 0, 999)
        );
    }
};

// ── Framebuffer ──
class Framebuffer {
public:
    u32     width, height;
    Pixel*  pixels   = nullptr;
    f32*    depth    = nullptr;   // Z-buffer

    Framebuffer() = default;

    bool create(u32 w, u32 h) {
        width = w; height = h;
        pixels = new Pixel[w * h];
        depth  = new f32[w * h];
        clear();
        return true;
    }

    void destroy() {
        delete[] pixels; pixels = nullptr;
        delete[] depth;  depth  = nullptr;
    }

    ~Framebuffer() { destroy(); }

    inline void clear(Pixel bg = {0,0,0,255}) {
        for(u32 i = 0; i < width*height; i++) {
            pixels[i] = bg;
            depth[i]  = 1.0f;
        }
    }

    inline void setPixel(u32 x, u32 y, const Pixel& p) {
        if(x < width && y < height)
            pixels[y * width + x] = p;
    }

    inline Pixel getPixel(u32 x, u32 y) const {
        if(x < width && y < height)
            return pixels[y * width + x];
        return {};
    }

    inline f32 getDepth(u32 x, u32 y) const {
        return depth[y * width + x];
    }

    inline void setDepth(u32 x, u32 y, f32 d) {
        depth[y * width + x] = d;
    }

    inline u32 size() const { return width * height; }
};

// ═══════════════════════════════════════════════════════
//  PIXEL PROCESSOR — قلب المحرك
// ═══════════════════════════════════════════════════════
class PixelProcessor {
public:
    // ── Shader Function Type ──
    // كل "shader" هو دالة تأخذ إحداثيات + بيانات وترجع Pixel
    using PixelShaderFn = Pixel(*)(
        u32 x, u32 y,           // إحداثيات البكسل
        f32 u, f32 v,           // UV coordinates
        const Vec3& worldPos,   // موقع في العالم
        const Vec3& normal,     // اتجاه السطح
        const Vec4& color,      // لون القاعدة
        f32 depth,              // عمق البكسل
        void* userData          // بيانات إضافية (مواد، إضاءة)
    );

    // ── Initialize ──
    bool init(u32 width, u32 height) {
        _fb.create(width, height);
        _width  = width;
        _height = height;
        return true;
    }

    void shutdown() {
        _fb.destroy();
    }

    void resize(u32 w, u32 h) {
        _fb.destroy();
        _fb.create(w, h);
        _width = w; _height = h;
    }

    // ── Clear ──
    void clear(Pixel bg = {10, 10, 20}) {
        _fb.clear(bg);
    }

    // ── Process All Pixels (كل فريم) ──
    void processAllPixels(PixelShaderFn shader, void* userData = nullptr) {
    #ifdef NOVA_NEON
        _processNEON(shader, userData);
    #else
        _processCPU(shader, userData);
    #endif
    }

    // ── معادلة RGB المخصصة ──
    // تطبق المعادلات الثلاث على كل بكسل في المشهد
    void applyEquationPass(
        i16 RA, u8 RB,   // معادلة R
        i16 GA, u8 GB,   // معادلة G
        i16 BA, u8 BB,   // معادلة B
        f32 blendFactor = 1.0f
    ) {
        PixelEquation eq;
        eq.RA=RA; eq.RB=RB;
        eq.GA=GA; eq.GB=GB;
        eq.BA=BA; eq.BB=BB;

        Pixel result = eq.evaluate();

    #ifdef NOVA_NEON
        _applyEquationNEON(result, blendFactor);
    #else
        _applyEquationCPU(result, blendFactor);
    #endif
    }

    // ── Draw Triangle (رسم مثلث محسوب بالكود) ──
    void drawTriangle(
        const Vec3& v0, const Vec3& v1, const Vec3& v2,
        const Vec4& c0, const Vec4& c1, const Vec4& c2,
        const Vec2& uv0, const Vec2& uv1, const Vec2& uv2,
        const Vec3& n0,  const Vec3& n1,  const Vec3& n2,
        PixelShaderFn shader, void* userData = nullptr
    ) {
        // Project to screen space
        Vec2 s0 = _project(v0);
        Vec2 s1 = _project(v1);
        Vec2 s2 = _project(v2);

        // Bounding box
        i32 minX = (i32)fmaxf(0, fminf({s0.x, s1.x, s2.x}));
        i32 maxX = (i32)fminf(_width-1,  fmaxf({s0.x, s1.x, s2.x}));
        i32 minY = (i32)fmaxf(0, fminf({s0.y, s1.y, s2.y}));
        i32 maxY = (i32)fminf(_height-1, fmaxf({s0.y, s1.y, s2.y}));

        f32 area = _edgeFunction(s0, s1, s2);
        if(fabsf(area) < 0.001f) return;

        for(i32 y = minY; y <= maxY; y++) {
            for(i32 x = minX; x <= maxX; x++) {
                Vec2 p = {(f32)x + 0.5f, (f32)y + 0.5f};

                f32 w0 = _edgeFunction(s1, s2, p);
                f32 w1 = _edgeFunction(s2, s0, p);
                f32 w2 = _edgeFunction(s0, s1, p);

                if(w0 < 0 || w1 < 0 || w2 < 0) continue;

                // Barycentric
                f32 b0 = w0 / area;
                f32 b1 = w1 / area;
                f32 b2 = w2 / area;

                // Interpolate
                f32 depth = b0*v0.z + b1*v1.z + b2*v2.z;
                if(depth >= _fb.getDepth(x, y)) continue;

                Vec4 color = c0*b0 + c1*b1 + c2*b2;
                Vec2 uv    = uv0*b0 + uv1*b1 + uv2*b2;
                Vec3 wpos  = v0*b0 + v1*b1 + v2*b2;
                Vec3 norm  = (n0*b0 + n1*b1 + n2*b2).normalized();

                Pixel px;
                if(shader) {
                    px = shader(x, y, uv.x, uv.y, wpos, norm, color, depth, userData);
                } else {
                    px = Pixel::fromFloat(color.x, color.y, color.z, color.w);
                }

                _fb.setDepth(x, y, depth);
                _fb.setPixel(x, y, px);
            }
        }
    }

    // ── Line Drawing (Bresenham) ──
    void drawLine(i32 x0, i32 y0, i32 x1, i32 y1, Pixel color) {
        i32 dx = abs(x1-x0), sx = x0<x1?1:-1;
        i32 dy = -abs(y1-y0), sy = y0<y1?1:-1;
        i32 err = dx+dy;
        while(true) {
            _fb.setPixel(x0, y0, color);
            if(x0==x1 && y0==y1) break;
            i32 e2 = 2*err;
            if(e2 >= dy) { err += dy; x0 += sx; }
            if(e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    // ── Get Framebuffer ──
    const Framebuffer& getFramebuffer() const { return _fb; }
    Framebuffer& getFramebuffer() { return _fb; }
    u32 width()  const { return _width; }
    u32 height() const { return _height; }

    // ── Set Camera Matrices ──
    void setViewProjection(const Mat4& view, const Mat4& proj) {
        _view = view;
        _proj = proj;
        _vp   = proj * view;
    }

private:
    Framebuffer _fb;
    u32 _width = 0, _height = 0;
    Mat4 _view, _proj, _vp;

    // ── CPU fallback ──
    void _processCPU(PixelShaderFn shader, void* ud) {
        for(u32 y = 0; y < _height; y++) {
            for(u32 x = 0; x < _width; x++) {
                f32 u = (f32)x / _width;
                f32 v = (f32)y / _height;
                Vec3 wp = {u*2-1, v*2-1, 0};
                Pixel px = shader(x, y, u, v, wp, Vec3::UP, Vec4::WHITE, 0, ud);
                _fb.setPixel(x, y, px);
            }
        }
    }

    // ── ARM NEON optimized ──
    void _processNEON(PixelShaderFn shader, void* ud) {
        // معالجة 4 صفوف بالتوازي على NEON
        u32 blockH = 4;
        for(u32 y = 0; y < _height; y += blockH) {
            for(u32 x = 0; x < _width; x++) {
                for(u32 by = 0; by < blockH && (y+by) < _height; by++) {
                    u32 py = y + by;
                    f32 u = (f32)x / _width;
                    f32 v = (f32)py / _height;
                    Vec3 wp = {u*2-1, v*2-1, 0};
                    Pixel px = shader(x, py, u, v, wp, Vec3::UP, Vec4::WHITE, 0, ud);
                    _fb.setPixel(x, py, px);
                }
            }
        }
    }

    void _applyEquationCPU(const Pixel& eq, f32 blend) {
        if(blend >= 1.0f) {
            for(u32 i = 0; i < _fb.size(); i++) {
                _fb.pixels[i] = _fb.pixels[i].blend(eq);
            }
        } else {
            for(u32 i = 0; i < _fb.size(); i++) {
                Pixel& p = _fb.pixels[i];
                p.r = (u8)(p.r * (1-blend) + eq.r * blend);
                p.g = (u8)(p.g * (1-blend) + eq.g * blend);
                p.b = (u8)(p.b * (1-blend) + eq.b * blend);
            }
        }
    }

#ifdef NOVA_NEON
    void _applyEquationNEON(const Pixel& eq, f32 blend) {
        u32 count = _fb.size();
        u32* buf  = reinterpret_cast<u32*>(_fb.pixels);

        // Load equation color into NEON register
        uint8x8_t eq_r = vdup_n_u8(eq.r);
        uint8x8_t eq_g = vdup_n_u8(eq.g);
        uint8x8_t eq_b = vdup_n_u8(eq.b);
        uint8x8_t blend8 = vdup_n_u8((u8)(blend * 255));

        u32 i = 0;
        // Process 8 pixels at once
        for(; i + 8 <= count; i += 8) {
            uint8x8x4_t pixels = vld4_u8((u8*)(buf + i));
            // Blend R, G, B channels
            pixels.val[0] = vqadd_u8(
                vqrshrn_n_u16(vmull_u8(pixels.val[0], vdup_n_u8(255 - (u8)(blend*255))), 8),
                vqrshrn_n_u16(vmull_u8(eq_r, blend8), 8)
            );
            pixels.val[1] = vqadd_u8(
                vqrshrn_n_u16(vmull_u8(pixels.val[1], vdup_n_u8(255 - (u8)(blend*255))), 8),
                vqrshrn_n_u16(vmull_u8(eq_g, blend8), 8)
            );
            pixels.val[2] = vqadd_u8(
                vqrshrn_n_u16(vmull_u8(pixels.val[2], vdup_n_u8(255 - (u8)(blend*255))), 8),
                vqrshrn_n_u16(vmull_u8(eq_b, blend8), 8)
            );
            vst4_u8((u8*)(buf + i), pixels);
        }
        // Remaining pixels
        for(; i < count; i++) {
            Pixel& p = _fb.pixels[i];
            p.r = (u8)(p.r*(1-blend) + eq.r*blend);
            p.g = (u8)(p.g*(1-blend) + eq.g*blend);
            p.b = (u8)(p.b*(1-blend) + eq.b*blend);
        }
    }
#endif

    // ── Helpers ──
    Vec2 _project(const Vec3& v) const {
        // Transform to clip space
        Vec4 clip = _vp * Vec4(v, 1.0f);
        if(fabsf(clip.w) < EPSILON) return {0,0};
        f32 ndcX = clip.x / clip.w;
        f32 ndcY = clip.y / clip.w;
        return {
            (ndcX * 0.5f + 0.5f) * _width,
            (1.0f - (ndcY * 0.5f + 0.5f)) * _height
        };
    }

    f32 _edgeFunction(const Vec2& a, const Vec2& b, const Vec2& c) const {
        return (c.x-a.x)*(b.y-a.y) - (c.y-a.y)*(b.x-a.x);
    }
};

} // namespace Nova
