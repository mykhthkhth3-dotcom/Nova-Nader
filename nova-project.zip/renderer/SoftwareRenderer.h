#pragma once
#include "../Nova.h"
#include "PixelProcessor.h"
#include "Material.h"
#include "Light.h"

namespace Nova {

// ═══════════════════════════════════════════════════════
//  SOFTWARE RENDERER
//  محرك رسوميات كامل بالكود — بدون OpenGL
//  يستخدم PixelProcessor لرسم كل شيء
// ═══════════════════════════════════════════════════════

// ── Vertex ──
struct Vertex {
    Vec3 position;
    Vec3 normal;
    Vec2 uv;
    Vec4 color = Vec4::WHITE;
    Vec3 tangent;
};

// ── Mesh (مجموعة مثلثات) ──
struct Mesh {
    Vertex* vertices  = nullptr;
    u32*    indices   = nullptr;
    u32     vertCount = 0;
    u32     idxCount  = 0;

    void create(u32 verts, u32 idxs) {
        vertices  = new Vertex[verts];
        indices   = new u32[idxs];
        vertCount = verts;
        idxCount  = idxs;
    }
    void destroy() {
        delete[] vertices; vertices = nullptr;
        delete[] indices;  indices  = nullptr;
    }
    ~Mesh() { destroy(); }
};

// ── Render Object ──
struct RenderObject {
    Mesh*     mesh      = nullptr;
    Material* material  = nullptr;
    Mat4      transform = Mat4::IDENTITY;
    bool      visible   = true;
    bool      castShadow = true;
};

// ── Render Stats ──
struct RenderStats {
    u32 triangles = 0;
    u32 drawCalls = 0;
    f32 frameTime = 0.0f;
    f32 fps       = 0.0f;
    u32 width     = 0;
    u32 height    = 0;
};

class SoftwareRenderer {
public:
    // ── Init ──
    bool init(u32 width, u32 height) {
        _pp.init(width, height);
        _width  = width;
        _height = height;
        _stats.width  = width;
        _stats.height = height;
        return true;
    }

    void shutdown() { _pp.shutdown(); }

    void resize(u32 w, u32 h) {
        _pp.resize(w, h);
        _width = w; _height = h;
        _stats.width = w; _stats.height = h;
    }

    // ── Camera ──
    void setCamera(const Vec3& pos, const Vec3& target, const Vec3& up,
                   f32 fovDeg, f32 nearZ, f32 farZ)
    {
        _camPos    = pos;
        _camTarget = target;
        _camUp     = up;
        _nearZ     = nearZ;
        _farZ      = farZ;
        _fov       = fovDeg;
        _updateMatrices();
    }

    // ── Lights ──
    void clearLights() { _lightCount = 0; }
    void addLight(const Light& l) {
        if(_lightCount < MAX_LIGHTS)
            _lights[_lightCount++] = l;
    }

    // ── Draw ──
    void beginFrame() {
        _frameStart = Timer::now();
        _stats.triangles = 0;
        _stats.drawCalls = 0;
        _pp.clear({10, 12, 20});
    }

    void draw(const RenderObject& obj) {
        if(!obj.visible || !obj.mesh) return;
        _stats.drawCalls++;
        _drawMesh(*obj.mesh, obj.transform, obj.material);
    }

    void endFrame() {
        f32 ft = Timer::elapsed(_frameStart);
        _stats.frameTime = ft;
        _stats.fps = ft > 0 ? 1.0f / ft : 0.0f;
    }

    // ── Getters ──
    const Pixel* getPixelData()  const { return _pp.getFramebuffer().pixels; }
    const RenderStats& getStats() const { return _stats; }
    PixelProcessor& getProcessor() { return _pp; }

private:
    static constexpr u32 MAX_LIGHTS = 8;

    PixelProcessor _pp;
    u32  _width=0, _height=0;
    Vec3 _camPos, _camTarget, _camUp;
    f32  _nearZ=0.1f, _farZ=1000.0f, _fov=60.0f;
    Mat4 _viewMat, _projMat;
    Light _lights[MAX_LIGHTS];
    u32  _lightCount = 0;
    RenderStats _stats;
    u64  _frameStart = 0;

    void _updateMatrices() {
        _viewMat = Mat4::lookAt(_camPos, _camTarget, _camUp);
        f32 aspect = (f32)_width / (f32)_height;
        _projMat = Mat4::perspective(_fov * DEG2RAD, aspect, _nearZ, _farZ);
        _pp.setViewProjection(_viewMat, _projMat);
    }

    void _drawMesh(const Mesh& mesh, const Mat4& transform, Material* mat) {
        for(u32 i = 0; i + 2 < mesh.idxCount; i += 3) {
            u32 i0 = mesh.indices[i];
            u32 i1 = mesh.indices[i+1];
            u32 i2 = mesh.indices[i+2];

            if(i0>=mesh.vertCount || i1>=mesh.vertCount || i2>=mesh.vertCount)
                continue;

            const Vertex& va = mesh.vertices[i0];
            const Vertex& vb = mesh.vertices[i1];
            const Vertex& vc = mesh.vertices[i2];

            // Transform positions
            Vec3 wa = (transform * Vec4(va.position, 1.0f)).xyz();
            Vec3 wb = (transform * Vec4(vb.position, 1.0f)).xyz();
            Vec3 wc = (transform * Vec4(vc.position, 1.0f)).xyz();

            // Transform normals
            Mat3 normalMat = transform.toMat3().inversed().transposed();
            Vec3 na = (normalMat * va.normal).normalized();
            Vec3 nb = (normalMat * vb.normal).normalized();
            Vec3 nc = (normalMat * vc.normal).normalized();

            // Back face culling
            Vec3 edge1 = wb - wa;
            Vec3 edge2 = wc - wa;
            Vec3 faceNorm = edge1.cross(edge2);
            Vec3 toCamera = (_camPos - wa).normalized();
            if(faceNorm.dot(toCamera) < 0) continue;

            // Lighting per vertex
            Vec4 ca = _applyLighting(wa, na, va.color, mat);
            Vec4 cb = _applyLighting(wb, nb, vb.color, mat);
            Vec4 cc = _applyLighting(wc, nc, vc.color, mat);

            _pp.drawTriangle(
                wa, wb, wc,
                ca, cb, cc,
                va.uv, vb.uv, vc.uv,
                na, nb, nc,
                mat ? mat->getShader() : nullptr,
                mat
            );

            _stats.triangles++;
        }
    }

    Vec4 _applyLighting(const Vec3& pos, const Vec3& normal,
                        const Vec4& baseColor, Material* mat) const
    {
        Vec3 result = Vec3(0.05f); // Ambient

        for(u32 i = 0; i < _lightCount; i++) {
            const Light& l = _lights[i];
            Vec3 lightDir;
            f32  attenuation = 1.0f;

            if(l.type == Light::DIRECTIONAL) {
                lightDir = (-l.direction).normalized();
            } else {
                Vec3 toLight = l.position - pos;
                f32  dist    = toLight.length();
                lightDir     = toLight / dist;
                attenuation  = 1.0f / (1.0f + l.attenuation * dist * dist);
            }

            f32 diff = fmaxf(0.0f, normal.dot(lightDir));

            // Specular (Blinn-Phong)
            Vec3 viewDir = (_camPos - pos).normalized();
            Vec3 halfDir = (lightDir + viewDir).normalized();
            f32  spec    = powf(fmaxf(0.0f, normal.dot(halfDir)),
                                mat ? mat->shininess : 32.0f);

            Vec3 lc = l.color * l.intensity * attenuation;
            result  = result + baseColor.rgb() * lc * diff
                     + Vec3(spec) * lc * (mat ? mat->specularStrength : 0.5f);
        }

        return Vec4(result.clamp(0,1), baseColor.a());
    }
};

} // namespace Nova
