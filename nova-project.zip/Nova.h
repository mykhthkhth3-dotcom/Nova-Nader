#pragma once

// ═══════════════════════════════════════════════════
//  NOVA ENGINE v1.0 — Session 1: Core + Math + Memory
//  محرك ألعاب C++ احترافي لـ Android
// ═══════════════════════════════════════════════════

// ── Platform Detection ──
#if defined(__ANDROID__)
    #define NOVA_PLATFORM_ANDROID 1
    #define NOVA_PLATFORM_NAME "Android"
#elif defined(_WIN32)
    #define NOVA_PLATFORM_WINDOWS 1
    #define NOVA_PLATFORM_NAME "Windows"
#elif defined(__linux__)
    #define NOVA_PLATFORM_LINUX 1
    #define NOVA_PLATFORM_NAME "Linux"
#elif defined(__APPLE__)
    #define NOVA_PLATFORM_APPLE 1
    #define NOVA_PLATFORM_NAME "Apple"
#endif

// ── Debug ──
#ifdef NOVA_DEBUG
    #define NOVA_ASSERT(cond, msg) do { if(!(cond)) { Nova::Logger::Fatal("ASSERT: " msg); } } while(0)
    #define NOVA_LOG(msg, ...) Nova::Logger::Debug(msg, ##__VA_ARGS__)
#else
    #define NOVA_ASSERT(cond, msg) ((void)0)
    #define NOVA_LOG(msg, ...)     ((void)0)
#endif

// ── Standard Includes ──
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cmath>
#include <cassert>
#include <functional>
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <atomic>
#include <mutex>

namespace Nova {
    // ── Integer Types ──
    using u8    = uint8_t;
    using u16   = uint16_t;
    using u32   = uint32_t;
    using u64   = uint64_t;
    using i8    = int8_t;
    using i16   = int16_t;
    using i32   = int32_t;
    using i64   = int64_t;
    using f32   = float;
    using f64   = double;
    using usize = size_t;
    using isize = ptrdiff_t;
    using byte  = uint8_t;

    // ── Constants ──
    constexpr f32 PI        = 3.14159265358979323846f;
    constexpr f32 TWO_PI    = 6.28318530717958647692f;
    constexpr f32 HALF_PI   = 1.57079632679489661923f;
    constexpr f32 INV_PI    = 0.31830988618379067154f;
    constexpr f32 DEG2RAD   = PI / 180.0f;
    constexpr f32 RAD2DEG   = 180.0f / PI;
    constexpr f32 EPSILON   = 1e-6f;
    constexpr f32 INFINITY_F= 1e30f;

    // ── Math Helpers ──
    inline u32 clamp3(u32 v, u32 mn, u32 mx) { return v<mn?mn:(v>mx?mx:v); }
    inline i32 clampi(i32 v, i32 mn, i32 mx) { return v<mn?mn:(v>mx?mx:v); }
    inline f32 clampf(f32 v, f32 mn, f32 mx) { return v<mn?mn:(v>mx?mx:v); }
    inline f32 lerpf (f32 a, f32 b, f32 t)   { return a+(b-a)*t; }
    inline f32 smoothstep(f32 e0, f32 e1, f32 x) {
        f32 t = clampf((x-e0)/(e1-e0),0,1);
        return t*t*(3-2*t);
    }
}

// ── Core Includes ──
#include "math/Vec2Vec4.h"
#include "math/Vec3.h"
#include "math/Mat4.h"
#include "math/Quat.h"
#include "math/Transform.h"
#include "math/AABB.h"
#include "math/Noise.h"
#include "memory/Allocator.h"
#include "memory/PoolAllocator.h"
#include "memory/StackAllocator.h"
#include "core/Logger.h"
#include "core/Timer.h"
#include "core/FileSystem.h"
#include "core/EventSystem.h"
#include "core/JobSystem.h"
#include "core/UUID.h"
