#pragma once
#include "../Nova.h"
#include <string>
#include <vector>
#include <functional>
#include <unordered_map>
#include <queue>
#include <thread>
#include <mutex>
#include <atomic>
#include <sstream>

// Android HTTP
#ifdef NOVA_PLATFORM_ANDROID
    #include <jni.h>
#endif

namespace Nova {

// ═══════════════════════════════════════════════════════
//  NOVA AI BUILDER — الجلسة السادسة
//  نظام بناء ألعاب بالذكاء الاصطناعي
//  يدعم حتى 25 API بالتوازي + API منظم
//  كل طلب يأخذ كوداً فقط — بدون كلام زائد
// ═══════════════════════════════════════════════════════

// ── API Worker Config ──
struct AIWorkerConfig {
    std::string id;
    std::string name;
    std::string apiKey;
    std::string model        = "claude-sonnet-4-20250514";
    u32         maxTokens    = 4000;
    u32         rpm          = 10;        // طلبات في الدقيقة
    u32         priority     = 2;         // 1=low, 2=mid, 3=high
    bool        isOrchestrator = false;

    // Runtime stats
    u32  requestCount  = 0;
    u32  totalTokens   = 0;
    u32  errorCount    = 0;
    f32  avgLatency    = 0.0f;
    bool busy          = false;
    std::string currentTask;
};

// ── Build Task ──
struct BuildTask {
    std::string id;
    std::string fileName;
    std::string description;
    std::string context;       // معلومات المشروع
    std::string dependencies;  // ملفات أخرى مرتبطة
    u32         complexity = 2; // 1=low,2=mid,3=high
    u32         priority   = 2;
    bool        done       = false;
    std::string result;        // الكود الناتج
    std::string assignedTo;    // worker id
    f32         timeMs     = 0;
    bool        failed     = false;
    std::string error;
};

// ── Build Plan ──
struct BuildPlan {
    std::string projectName;
    std::string projectDesc;
    std::string projectType;
    std::string language;
    std::vector<BuildTask> tasks;
    u32  totalTasks    = 0;
    u32  doneTasks     = 0;
    u32  failedTasks   = 0;
    bool complete      = false;
};

// ── Build Stats ──
struct BuildStats {
    u32  totalRequests = 0;
    u32  totalTokens   = 0;
    u32  totalFiles    = 0;
    u32  totalLines    = 0;
    f32  elapsedSec    = 0.0f;
    f32  progressPct   = 0.0f;
    std::string phase;
    std::string lastLog;
};

// ── HTTP Response ──
struct HttpResponse {
    u32         statusCode = 0;
    std::string body;
    bool        ok         = false;
};

// ═══════════════════════════════════════════════════════
//  AI BUILDER ENGINE
// ═══════════════════════════════════════════════════════
class AIBuilder {
public:
    static constexpr u32 MAX_WORKERS    = 25;
    static constexpr u32 MAX_RETRIES    = 3;
    static constexpr f32 MIN_RPM_DELAY  = 1.0f; // ثانية كحد أدنى بين طلبين

    // ── Callbacks ──
    std::function<void(const std::string&, const std::string&)> onLog;
    std::function<void(const BuildTask&)>    onTaskComplete;
    std::function<void(const BuildStats&)>   onProgress;
    std::function<void(const BuildPlan&)>    onBuildComplete;
    std::function<void(const std::string&)>  onError;

    // HTTP provider (يُعيّن من Java/Kotlin)
    std::function<HttpResponse(
        const std::string& url,
        const std::string& apiKey,
        const std::string& body
    )> httpProvider;

    // ── Workers Management ──
    bool addWorker(const AIWorkerConfig& cfg) {
        if(_workers.size() >= MAX_WORKERS) {
            _log("ERROR", "تجاوز الحد الأقصى للـ API Workers: " + std::to_string(MAX_WORKERS));
            return false;
        }
        if(cfg.apiKey.empty() || cfg.apiKey.substr(0,3) != "sk-") {
            _log("ERROR", "مفتاح API غير صالح: " + cfg.name);
            return false;
        }
        _workers[cfg.id] = cfg;
        _log("INFO", "تم إضافة Worker: " + cfg.name + " | " + cfg.model);
        return true;
    }

    bool setOrchestrator(const AIWorkerConfig& cfg) {
        AIWorkerConfig orch = cfg;
        orch.isOrchestrator = true;
        orch.id = "orchestrator";
        _orchestratorId = "orchestrator";
        _workers[orch.id] = orch;
        _log("INFO", "تم تعيين Orchestrator: " + cfg.name);
        return true;
    }

    void removeWorker(const std::string& id) { _workers.erase(id); }
    void clearWorkers() { _workers.clear(); _orchestratorId = ""; }
    u32  getWorkerCount() const { return (u32)_workers.size(); }

    AIWorkerConfig* getWorker(const std::string& id) {
        auto it = _workers.find(id);
        return it != _workers.end() ? &it->second : nullptr;
    }

    const std::unordered_map<std::string, AIWorkerConfig>& getAllWorkers() const {
        return _workers;
    }

    // ── Build Project ──
    void buildProject(
        const std::string& name,
        const std::string& desc,
        const std::string& type,
        const std::string& lang,
        bool useMultiAPI = false
    ) {
        if(_workers.empty()) {
            _log("ERROR", "لا يوجد أي API Worker. أضف API أولاً.");
            if(onError) onError("لا يوجد أي API Worker");
            return;
        }

        _stats = {};
        _stats.phase = "تخطيط";
        _plan = {};
        _plan.projectName = name;
        _plan.projectDesc = desc;
        _plan.projectType = type;
        _plan.language    = lang;
        _cancelled = false;
        _startTime = _now();

        _log("INFO", "🚀 بدء البناء: " + name);
        _log("INFO", "📋 النوع: " + type + " | اللغة: " + lang);

        if(useMultiAPI && _workers.size() > 1 && !_orchestratorId.empty()) {
            _buildMultiAPI();
        } else {
            _buildSingleAPI();
        }
    }

    void cancel() {
        _cancelled = true;
        _log("WARN", "⛔ تم إلغاء البناء");
    }

    bool isRunning()     const { return _running; }
    const BuildStats& getStats() const { return _stats; }
    const BuildPlan&  getPlan()  const { return _plan; }

    // ── Get Output Files ──
    const std::unordered_map<std::string, std::string>& getOutputFiles() const {
        return _outputFiles;
    }

private:
    std::unordered_map<std::string, AIWorkerConfig> _workers;
    std::string _orchestratorId;
    BuildPlan   _plan;
    BuildStats  _stats;
    std::unordered_map<std::string, std::string> _outputFiles;
    std::atomic<bool> _running{false};
    std::atomic<bool> _cancelled{false};
    u64 _startTime = 0;
    std::mutex _mutex;

    // ══════════════════════════════════════
    //  SINGLE API BUILD
    // ══════════════════════════════════════
    void _buildSingleAPI() {
        _running = true;

        // اختر أول worker متاح
        std::string workerId;
        for(auto& [id, w] : _workers) {
            if(id != _orchestratorId) { workerId=id; break; }
        }
        if(workerId.empty()) workerId = _workers.begin()->first;

        AIWorkerConfig& worker = _workers[workerId];
        _log("INFO", "🤖 Worker: " + worker.name);

        // الخطوة 1: تخطيط
        _stats.phase = "تخطيط الهيكل";
        _log("INFO", "📐 الخطوة 1: تخطيط الهيكل...");
        _emitProgress();

        std::string planJson = _requestPlan(worker, _plan.projectName,
                                             _plan.projectDesc, _plan.projectType,
                                             _plan.language);
        if(_cancelled) { _running=false; return; }

        _parsePlanJson(planJson);
        _log("INFO", "📋 الخطة: " + std::to_string(_plan.tasks.size()) + " ملف");

        // الخطوة 2: بناء كل ملف
        u32 total = (u32)_plan.tasks.size();
        for(u32 i=0; i<total; i++) {
            if(_cancelled) break;
            BuildTask& task = _plan.tasks[i];

            f32 pct = 10.0f + (f32)i/total*85.0f;
            _stats.progressPct = pct;
            _stats.phase = "ملف " + std::to_string(i+1) + "/" + std::to_string(total);
            _log("INFO", "🔨 بناء: " + task.fileName);
            _emitProgress();

            // Rate limit
            f32 delay = 60.0f / worker.rpm;
            _sleep((u32)(delay * 1000));

            u64 t0 = _now();
            std::string code = _requestFile(worker, task);
            task.timeMs = (_now() - t0) / 1e6f;

            if(!code.empty()) {
                task.result = code;
                task.done   = true;
                _addOutputFile(task.fileName, code);
                _log("CODE", "✓ " + task.fileName + " (" + std::to_string(_countLines(code)) + " سطر)");
                if(onTaskComplete) onTaskComplete(task);
            } else {
                task.failed = true;
                _log("ERROR", "✗ فشل: " + task.fileName);
            }

            _plan.doneTasks++;
            _stats.totalFiles = (u32)_outputFiles.size();
            _stats.totalLines = _countTotalLines();
            _updateWorkerStats(worker, task);
        }

        _finalize();
    }

    // ══════════════════════════════════════
    //  MULTI API BUILD (Orchestrated)
    // ══════════════════════════════════════
    void _buildMultiAPI() {
        _running = true;

        // تحقق من الـ Orchestrator
        if(_orchestratorId.empty() || _workers.find(_orchestratorId)==_workers.end()) {
            _log("ERROR", "لا يوجد API منظم (Orchestrator)");
            _running = false;
            return;
        }

        AIWorkerConfig& orch = _workers[_orchestratorId];
        _log("INFO", "🎯 Orchestrator: " + orch.name);
        _log("INFO", "⚡ Workers: " + std::to_string(_workers.size()-1) + " API");

        // جمع معلومات Workers
        std::string workerInfo;
        for(auto& [id, w] : _workers) {
            if(id == _orchestratorId) continue;
            workerInfo += "- " + w.name + " (" + std::to_string(w.rpm) + " req/min, priority=" + std::to_string(w.priority) + ")\n";
        }

        // الخطوة 1: Orchestrator يضع خطة التوزيع
        _stats.phase = "Orchestrator يخطط";
        _log("ORCH", "🧠 Orchestrator يضع خطة التوزيع...");
        _emitProgress();

        std::string orchPlan = _requestOrchPlan(orch, workerInfo);
        if(_cancelled) { _running=false; return; }
        _parsePlanJson(orchPlan);

        _log("ORCH", "📋 خطة التوزيع: " + std::to_string(_plan.tasks.size()) + " مهمة");

        // الخطوة 2: توزيع المهام على Workers
        _stats.phase = "توزيع المهام";
        _log("ORCH", "⚡ توزيع المهام...");

        // بناء قائمة Workers (بدون Orchestrator)
        std::vector<std::string> workerIds;
        for(auto& [id, w] : _workers) {
            if(id != _orchestratorId) workerIds.push_back(id);
        }

        // توزيع المهام دورياً حسب الأولوية
        u32 taskIdx = 0;
        u32 total   = (u32)_plan.tasks.size();

        while(taskIdx < total && !_cancelled) {
            // ابحث عن worker غير مشغول
            for(u32 wi=0; wi<workerIds.size() && taskIdx<total && !_cancelled; wi++) {
                std::string wid = workerIds[wi];
                AIWorkerConfig& w = _workers[wid];
                if(w.busy) continue;

                BuildTask& task = _plan.tasks[taskIdx++];
                task.assignedTo = wid;
                w.busy = true;
                w.currentTask = task.fileName;

                f32 pct = 15.0f + (f32)_plan.doneTasks/total*75.0f;
                _stats.progressPct = pct;
                _stats.phase = std::to_string(_plan.doneTasks) + "/" + std::to_string(total);
                _log("INFO", "🔧 [" + w.name + "] → " + task.fileName);
                _emitProgress();

                // Rate limit per worker
                f32 delay = 60.0f / w.rpm;
                _sleep((u32)(delay * 1000));

                u64 t0 = _now();
                std::string code = _requestFile(w, task);
                task.timeMs = (_now() - t0) / 1e6f;

                w.busy = false;
                w.currentTask = "";

                if(!code.empty()) {
                    task.result = code;
                    task.done   = true;
                    _addOutputFile(task.fileName, code);
                    _log("CODE", "✓ [" + w.name + "] " + task.fileName +
                         " (" + std::to_string(_countLines(code)) + " سطر)");
                    if(onTaskComplete) onTaskComplete(task);
                } else {
                    task.failed = true;
                    _log("ERROR", "✗ [" + w.name + "] فشل: " + task.fileName);
                }

                _plan.doneTasks++;
                _stats.totalFiles = (u32)_outputFiles.size();
                _stats.totalLines = _countTotalLines();
                _updateWorkerStats(w, task);
            }
        }

        // الخطوة 3: Orchestrator يراجع ويدمج
        if(!_cancelled) {
            _stats.phase = "مراجعة Orchestrator";
            _log("ORCH", "🧩 Orchestrator يراجع النتائج...");
            std::string notes = _requestIntegrationNotes(orch);
            if(!notes.empty()) _addOutputFile("_integration_notes.md", notes);
        }

        _finalize();
    }

    // ══════════════════════════════════════
    //  API CALLS
    // ══════════════════════════════════════

    // System prompt: يطلب كوداً فقط
    std::string _codeOnlySystem() {
        return "أنت مطور C++ خبير متخصص في تطوير محركات ألعاب Android. "
               "أجب فقط بالكود المطلوب بدون أي نص إضافي أو شرح أو backticks أو markdown. "
               "الكود النظيف المباشر فقط. لا تكتب أي جملة قبل الكود أو بعده.";
    }

    std::string _plannerSystem() {
        return "أنت مهندس معمارية برمجيات خبير. أجب بـ JSON فقط بدون أي نص آخر.";
    }

    std::string _orchSystem() {
        return "أنت Orchestrator خبير في إدارة فرق التطوير. "
               "خطط وزّع المهام بدقة. أجب بـ JSON فقط.";
    }

    std::string _requestPlan(AIWorkerConfig& w,
                              const std::string& name, const std::string& desc,
                              const std::string& type, const std::string& lang)
    {
        std::string prompt =
            "خطط هيكل مشروع " + lang + " كامل:\n"
            "الاسم: " + name + "\n"
            "الوصف: " + desc + "\n"
            "النوع: " + type + "\n\n"
            "أعطني JSON بالشكل:\n"
            "{\"tasks\":["
            "{\"file\":\"main.cpp\",\"desc\":\"الملف الرئيسي\",\"priority\":1,\"complexity\":\"medium\"},"
            "...\n]}\n"
            "JSON فقط.";

        auto resp = _callAPI(w, prompt, _plannerSystem());
        return resp;
    }

    std::string _requestOrchPlan(AIWorkerConfig& w, const std::string& workerInfo) {
        std::string prompt =
            "أنت Orchestrator. وزّع مهام هذا المشروع على العمال المتاحين:\n\n"
            "المشروع: " + _plan.projectName + "\n"
            "الوصف: " + _plan.projectDesc + "\n"
            "النوع: " + _plan.projectType + "\n"
            "اللغة: " + _plan.language + "\n\n"
            "العمال:\n" + workerInfo + "\n"
            "أعطني JSON:\n"
            "{\"tasks\":["
            "{\"file\":\"Engine.cpp\",\"desc\":\"محرك رئيسي\",\"priority\":1,\"complexity\":\"high\"},"
            "...\n]}\n"
            "JSON فقط.";

        return _callAPI(w, prompt, _orchSystem());
    }

    std::string _requestFile(AIWorkerConfig& w, const BuildTask& task) {
        std::string others;
        for(auto& [fn, _] : _outputFiles) others += fn + ", ";

        std::string prompt =
            "اكتب الكود الكامل لملف: " + task.fileName + "\n\n"
            "المشروع: " + _plan.projectName + "\n"
            "الوصف: " + _plan.projectDesc + "\n"
            "نوع المشروع: " + _plan.projectType + "\n"
            "اللغة: " + _plan.language + "\n"
            "وصف هذا الملف: " + task.description + "\n"
            "التعقيد: " + task.context + "\n"
            "الملفات الأخرى في المشروع: " + others + "\n\n"
            "الكود الكامل فقط. لا شرح. لا backticks. الكود المباشر.";

        std::string code = _callAPI(w, prompt, _codeOnlySystem());
        return _extractCode(code);
    }

    std::string _requestIntegrationNotes(AIWorkerConfig& w) {
        std::string fileList;
        for(auto& [fn, code] : _outputFiles) {
            fileList += fn + ": " + std::to_string(_countLines(code)) + " سطر\n";
        }

        std::string prompt =
            "راجع الملفات التالية المبنية لمشروع " + _plan.projectName + ":\n\n"
            + fileList + "\n"
            "اكتب ملاحظات التكامل والتوصيل بين الملفات فقط.";

        return _callAPI(w, prompt, _orchSystem());
    }

    // ── Core API Call ──
    std::string _callAPI(AIWorkerConfig& w,
                          const std::string& userMsg,
                          const std::string& system,
                          u32 retry=0)
    {
        if(_cancelled || !httpProvider) return "";

        // Build JSON body
        std::string body = "{"
            "\"model\":\"" + w.model + "\","
            "\"max_tokens\":" + std::to_string(w.maxTokens) + ","
            "\"system\":\"" + _escapeJson(system) + "\","
            "\"messages\":[{\"role\":\"user\",\"content\":\"" + _escapeJson(userMsg) + "\"}]"
            "}";

        auto resp = httpProvider(
            "https://api.anthropic.com/v1/messages",
            w.apiKey,
            body
        );

        _stats.totalRequests++;
        w.requestCount++;

        if(!resp.ok) {
            w.errorCount++;
            _log("ERROR", "HTTP " + std::to_string(resp.statusCode) + " | " + w.name);

            // Retry with backoff
            if(retry < MAX_RETRIES && !_cancelled) {
                _log("WARN", "إعادة المحاولة " + std::to_string(retry+1) + "/" + std::to_string(MAX_RETRIES));
                _sleep(2000 * (retry+1));
                return _callAPI(w, userMsg, system, retry+1);
            }
            return "";
        }

        // Parse response
        std::string text = _parseAPIResponse(resp.body, w.totalTokens);
        _stats.totalTokens += w.totalTokens;
        return text;
    }

    // ── Parse API Response ──
    std::string _parseAPIResponse(const std::string& json, u32& tokensOut) {
        // Extract text content from {"content":[{"type":"text","text":"..."}]}
        std::string result;
        size_t pos = json.find("\"text\":\"");
        if(pos == std::string::npos) return "";

        pos += 8; // skip "text":"
        std::string text;
        bool escaped = false;
        while(pos < json.size()) {
            char c = json[pos++];
            if(escaped) {
                if(c=='n') text+='\n';
                else if(c=='t') text+='\t';
                else if(c=='\\') text+='\\';
                else if(c=='"') text+='"';
                else text+=c;
                escaped = false;
            } else if(c=='\\') {
                escaped = true;
            } else if(c=='"') {
                break;
            } else {
                text += c;
            }
        }

        // Extract token usage
        size_t tp = json.find("\"output_tokens\":");
        if(tp != std::string::npos) {
            tp += 16;
            std::string num;
            while(tp<json.size() && isdigit(json[tp])) num+=json[tp++];
            if(!num.empty()) tokensOut += (u32)std::stoul(num);
        }

        return text;
    }

    // ── Parse Plan JSON ──
    void _parsePlanJson(const std::string& json) {
        _plan.tasks.clear();

        // Simple JSON parser for task list
        // {"tasks":[{"file":"x.cpp","desc":"y","priority":1,"complexity":"high"},...]}
        size_t pos = json.find("\"tasks\"");
        if(pos == std::string::npos) {
            // Fallback plan
            _log("WARN", "تعذر تحليل الخطة، استخدام خطة افتراضية");
            _defaultPlan();
            return;
        }

        size_t arrStart = json.find('[', pos);
        if(arrStart == std::string::npos) { _defaultPlan(); return; }

        pos = arrStart;
        while(pos < json.size()) {
            size_t objStart = json.find('{', pos);
            if(objStart == std::string::npos) break;
            size_t objEnd = json.find('}', objStart);
            if(objEnd == std::string::npos) break;

            std::string obj = json.substr(objStart, objEnd-objStart+1);

            BuildTask task;
            task.id          = "task_" + std::to_string(_plan.tasks.size());
            task.fileName    = _extractJsonStr(obj, "file");
            task.description = _extractJsonStr(obj, "desc");
            task.context     = _extractJsonStr(obj, "complexity");

            std::string priStr = _extractJsonStr(obj, "priority");
            task.priority = priStr.empty() ? 2 : (u32)std::stoi(priStr);

            if(!task.fileName.empty()) {
                _plan.tasks.push_back(task);
            }

            pos = objEnd + 1;
        }

        if(_plan.tasks.empty()) _defaultPlan();
        _plan.totalTasks = (u32)_plan.tasks.size();
    }

    void _defaultPlan() {
        struct FileInfo { const char* file; const char* desc; };
        std::vector<FileInfo> defaults;

        if(_plan.language=="cpp"||_plan.language=="C++") {
            defaults={
                {"main.cpp","نقطة دخول التطبيق"},
                {"Game.h","كلاس اللعبة الرئيسية"},
                {"Game.cpp","تطبيق اللعبة"},
                {"Player.h","كلاس اللاعب"},
                {"Player.cpp","تطبيق اللاعب"},
                {"CMakeLists.txt","إعدادات البناء"},
            };
        } else if(_plan.language=="kotlin"||_plan.language=="java") {
            defaults={
                {"MainActivity.kt","النشاط الرئيسي"},
                {"GameView.kt","عرض اللعبة"},
                {"GameEngine.kt","محرك اللعبة"},
            };
        } else {
            defaults={
                {"index.html","الصفحة الرئيسية"},
                {"style.css","التصميم"},
                {"app.js","المنطق"},
            };
        }

        for(auto& f:defaults) {
            BuildTask t;
            t.id=f.file; t.fileName=f.file; t.description=f.desc; t.priority=2;
            _plan.tasks.push_back(t);
        }
        _plan.totalTasks=(u32)_plan.tasks.size();
    }

    // ── Finalize ──
    void _finalize() {
        _stats.elapsedSec  = (_now()-_startTime)/1e9f;
        _stats.progressPct = _cancelled ? 0.0f : 100.0f;
        _stats.phase       = _cancelled ? "ملغى" : "مكتمل";
        _stats.totalFiles  = (u32)_outputFiles.size();
        _stats.totalLines  = _countTotalLines();
        _running = false;
        _plan.complete = !_cancelled;

        if(!_cancelled) {
            _log("SUCCESS", "✅ اكتمل البناء!");
            _log("SUCCESS",
                "📊 الملفات: " + std::to_string(_stats.totalFiles) +
                " | الأسطر: " + std::to_string(_stats.totalLines) +
                " | الطلبات: " + std::to_string(_stats.totalRequests) +
                " | التوكنات: " + std::to_string(_stats.totalTokens));
        }

        _emitProgress();
        if(onBuildComplete) onBuildComplete(_plan);
    }

    // ── Helpers ──
    void _addOutputFile(const std::string& name, const std::string& code) {
        std::lock_guard<std::mutex> lock(_mutex);
        _outputFiles[name] = code;
    }

    std::string _extractCode(const std::string& text) {
        // حذف الـ backticks إذا وُجدت
        std::string s = text;
        size_t start = s.find("```");
        if(start != std::string::npos) {
            size_t nl = s.find('\n', start);
            if(nl != std::string::npos) s = s.substr(nl+1);
            size_t end = s.rfind("```");
            if(end != std::string::npos) s = s.substr(0, end);
        }
        // حذف المسافات الزائدة
        while(!s.empty() && (s.front()=='\n'||s.front()=='\r'||s.front()==' ')) s.erase(s.begin());
        while(!s.empty() && (s.back()=='\n'||s.back()=='\r'||s.back()==' ')) s.pop_back();
        return s;
    }

    std::string _extractJsonStr(const std::string& json, const std::string& key) {
        size_t p = json.find("\""+key+"\"");
        if(p==std::string::npos) return "";
        p=json.find(':',p); if(p==std::string::npos) return "";
        p++; while(p<json.size()&&(json[p]==' '||json[p]=='\t')) p++;
        if(p>=json.size()) return "";
        if(json[p]=='"') {
            p++;
            std::string val;
            while(p<json.size()&&json[p]!='"') { val+=json[p++]; }
            return val;
        }
        // number
        std::string val;
        while(p<json.size()&&json[p]!=','&&json[p]!='}'&&json[p]!=']') val+=json[p++];
        return val;
    }

    std::string _escapeJson(const std::string& s) {
        std::string r;
        for(char c:s) {
            if(c=='"')  r+="\\\"";
            else if(c=='\\') r+="\\\\";
            else if(c=='\n') r+="\\n";
            else if(c=='\r') r+="\\r";
            else if(c=='\t') r+="\\t";
            else r+=c;
        }
        return r;
    }

    u32 _countLines(const std::string& s) {
        return (u32)std::count(s.begin(),s.end(),'\n')+1;
    }

    u32 _countTotalLines() {
        u32 n=0;
        for(auto& [f,c]:_outputFiles) n+=_countLines(c);
        return n;
    }

    void _updateWorkerStats(AIWorkerConfig& w, const BuildTask& t) {
        w.avgLatency = (w.avgLatency*(w.requestCount-1)+t.timeMs)/w.requestCount;
    }

    void _log(const std::string& level, const std::string& msg) {
        _stats.lastLog = "["+level+"] "+msg;
        if(onLog) onLog(level, msg);
    }

    void _emitProgress() {
        _stats.elapsedSec = (_now()-_startTime)/1e9f;
        if(onProgress) onProgress(_stats);
    }

    u64 _now() {
#ifdef NOVA_PLATFORM_ANDROID
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC,&ts);
        return (u64)ts.tv_sec*1000000000ULL+ts.tv_nsec;
#else
        return 0;
#endif
    }

    void _sleep(u32 ms) {
#ifdef NOVA_PLATFORM_ANDROID
        struct timespec ts={0,(long)ms*1000000L};
        nanosleep(&ts,nullptr);
#endif
    }
};

} // namespace Nova
