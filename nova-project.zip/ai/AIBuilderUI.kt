package com.nova.engine.ai

import android.content.Context
import android.graphics.*
import android.view.*
import android.widget.*
import androidx.core.content.ContextCompat

// ═══════════════════════════════════════════════════════
//  AI BUILDER UI — واجهة المستخدم داخل التطبيق
//  شاشة بناء المشاريع بالذكاء الاصطناعي
// ═══════════════════════════════════════════════════════

class AIBuilderScreen(context: Context) : ScrollView(context) {

    private val vm = AIBuilderViewModel()
    private val log = mutableListOf<String>()

    // ── Colors ──
    private val cBg      = Color.parseColor("#04000f")
    private val cSurface = Color.parseColor("#12102a")
    private val cAccent  = Color.parseColor("#7c5cfc")
    private val cAccent2 = Color.parseColor("#00ffe0")
    private val cText    = Color.parseColor("#e8e0ff")
    private val cDim     = Color.parseColor("#9890c0")
    private val cGreen   = Color.parseColor("#00e676")
    private val cGold    = Color.parseColor("#ffb830")
    private val cRed     = Color.parseColor("#ff3860")

    // ── UI Elements ──
    private lateinit var tvTitle: TextView
    private lateinit var etProjectName: EditText
    private lateinit var etProjectDesc: EditText
    private lateinit var spinnerType: Spinner
    private lateinit var spinnerLang: Spinner
    private lateinit var cbMultiAPI: CheckBox

    // API Section
    private lateinit var etApiKey: EditText
    private lateinit var etApiName: EditText
    private lateinit var etModel: EditText
    private lateinit var etRpm: EditText
    private lateinit var etTokens: EditText
    private lateinit var llWorkerList: LinearLayout
    private lateinit var tvWorkerCount: TextView

    // Orchestrator
    private lateinit var etOrchKey: EditText
    private lateinit var etOrchName: EditText
    private lateinit var llOrchSection: LinearLayout

    // Build
    private lateinit var btnBuild: Button
    private lateinit var btnCancel: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvPhase: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvLog: TextView
    private lateinit var llProgress: LinearLayout

    // Output
    private lateinit var llOutput: LinearLayout
    private lateinit var tvOutputFiles: TextView

    init {
        setBackgroundColor(cBg)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        addView(root)
        _buildUI(root)
        _wireCallbacks()
    }

    private fun _buildUI(root: LinearLayout) {
        // ── Title ──
        tvTitle = TextView(context).apply {
            text = "NOVA AI Builder"
            setTextColor(cAccent)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(4))
        }
        root.addView(tvTitle)

        _addSubtitle(root, "بناء مشاريع كاملة بالذكاء الاصطناعي")
        _addDivider(root)

        // ── Project Config ──
        _addSectionTitle(root, "⚙ إعداد المشروع")

        etProjectName = _addEditText(root, "اسم المشروع", "مثال: لعبة الطائرات")
        etProjectDesc = _addEditTextMulti(root, "وصف المشروع", "صف المشروع بالتفصيل...")

        spinnerType = _addSpinner(root, "نوع المشروع",
            arrayOf("game", "app", "engine", "tool", "custom"))
        spinnerLang = _addSpinner(root, "اللغة / الإطار",
            arrayOf("cpp", "kotlin", "java", "html+js", "python"))

        _addDivider(root)

        // ── API Mode ──
        _addSectionTitle(root, "🔑 إعداد الـ API")

        cbMultiAPI = CheckBox(context).apply {
            text = "⚡ تفعيل APIs متعددة (حتى 25)"
            setTextColor(cText)
            setOnCheckedChangeListener { _, checked ->
                llOrchSection.visibility = if(checked) VISIBLE else GONE
            }
        }
        root.addView(cbMultiAPI)

        // Single API
        _addSubtitle(root, "Worker API")
        etApiName = _addEditText(root, "اسم الـ API", "مثال: API الرئيسي")
        etApiKey  = _addPasswordField(root, "مفتاح الـ API (sk-...)")
        etModel   = _addEditText(root, "النموذج", "claude-sonnet-4-20250514")
        etRpm     = _addEditText(root, "طلبات/دقيقة", "10")
        etTokens  = _addEditText(root, "توكنات/طلب", "4000")

        val btnAddWorker = _makeButton("+ إضافة Worker", cAccent)
        btnAddWorker.setOnClickListener { _addWorker() }
        root.addView(btnAddWorker)

        tvWorkerCount = TextView(context).apply {
            setTextColor(cDim)
            textSize = 12f
            text = "Workers: 0 / 25"
            setPadding(0, dp(4), 0, 0)
        }
        root.addView(tvWorkerCount)

        llWorkerList = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        root.addView(llWorkerList)

        // Orchestrator section
        llOrchSection = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = GONE
        }
        _addSubtitle(llOrchSection, "🎯 API المنظم (Orchestrator)")
        etOrchName = _addEditText(llOrchSection, "اسم الـ Orchestrator", "API المنظم")
        etOrchKey  = _addPasswordField(llOrchSection, "مفتاح الـ Orchestrator")
        val btnSetOrch = _makeButton("✓ تعيين كـ Orchestrator", Color.parseColor("#ff8c00"))
        btnSetOrch.setOnClickListener { _setOrchestrator() }
        llOrchSection.addView(btnSetOrch)
        root.addView(llOrchSection)

        _addDivider(root)

        // ── Build Button ──
        btnBuild = _makeButton("🚀 ابدأ البناء", cAccent).apply {
            textSize = 17f
            setPadding(0, dp(16), 0, dp(16))
        }
        btnBuild.setOnClickListener { _startBuild() }
        root.addView(btnBuild)

        // ── Progress ──
        llProgress = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = GONE
            setBackgroundColor(cSurface)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        tvPhase = TextView(context).apply {
            setTextColor(cAccent2)
            textSize = 13f
            text = "جارٍ البناء..."
        }
        llProgress.addView(tvPhase)

        progressBar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressDrawable.setColorFilter(cAccent, PorterDuff.Mode.SRC_IN)
        }
        llProgress.addView(progressBar)

        tvStats = TextView(context).apply {
            setTextColor(cDim)
            textSize = 11f
            fontFeatureSettings = "mono"
        }
        llProgress.addView(tvStats)

        tvLog = TextView(context).apply {
            setTextColor(Color.parseColor("#a0ff80"))
            textSize = 10f
            fontFeatureSettings = "mono"
            setBackgroundColor(Color.parseColor("#050505"))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            maxLines = 20
        }
        llProgress.addView(tvLog)

        btnCancel = _makeButton("⛔ إيقاف البناء", cRed)
        btnCancel.setOnClickListener { vm.cancelBuild() }
        llProgress.addView(btnCancel)

        root.addView(llProgress)

        // ── Output ──
        llOutput = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = GONE
        }
        _addSectionTitle(llOutput, "📦 الملفات المُنشأة")
        tvOutputFiles = TextView(context).apply {
            setTextColor(cText)
            textSize = 12f
        }
        llOutput.addView(tvOutputFiles)
        root.addView(llOutput)
    }

    private fun _wireCallbacks() {
        vm.onStatusUpdate = { status ->
            post {
                progressBar.progress = status.progress.toInt()
                tvPhase.text = "⚡ ${status.phase}"
                tvStats.text =
                    "ملفات: ${status.totalFiles} | أسطر: ${status.totalLines} | " +
                    "طلبات: ${status.totalRequests} | توكنات: ${status.totalTokens} | " +
                    "الوقت: ${"%.1f".format(status.elapsedSec)}ث"
                if(status.lastLog.isNotEmpty()) {
                    log.add(status.lastLog)
                    if(log.size > 50) log.removeAt(0)
                    tvLog.text = log.takeLast(15).joinToString("\n")
                }
            }
        }

        vm.onComplete = { files ->
            post {
                llProgress.visibility = GONE
                llOutput.visibility = VISIBLE
                btnBuild.isEnabled = true

                val sb = StringBuilder()
                for((name, code) in files) {
                    val lines = code.count{it=='\n'}+1
                    sb.append("📄 $name ($lines سطر)\n")
                }
                tvOutputFiles.text = sb.toString()

                // Save files
                val path = vm.saveOutputFiles(context, "nova_project")
                _addLog("💾 تم الحفظ في: $path")
            }
        }
    }

    // ── Actions ──
    private fun _addWorker() {
        val name   = etApiName.text.toString().trim()
        val key    = etApiKey.text.toString().trim()
        val model  = etModel.text.toString().trim().ifEmpty { "claude-sonnet-4-20250514" }
        val rpm    = etRpm.text.toString().toIntOrNull() ?: 10
        val tokens = etTokens.text.toString().toIntOrNull() ?: 4000

        if(name.isEmpty()) { _showToast("أدخل اسم الـ API"); return }
        if(!key.startsWith("sk-")) { _showToast("مفتاح API غير صالح"); return }
        if(vm.getWorkers().size >= 25) { _showToast("الحد الأقصى 25 API"); return }

        val cfg = AIBuilderViewModel.WorkerConfig(
            id="worker_${System.currentTimeMillis()}",
            name=name, apiKey=key, model=model, maxTokens=tokens, rpm=rpm
        )
        vm.addWorker(cfg)
        _renderWorkerList()
        _clearWorkerFields()
        _showToast("✓ تم إضافة: $name")
    }

    private fun _setOrchestrator() {
        val name = etOrchName.text.toString().trim()
        val key  = etOrchKey.text.toString().trim()
        if(name.isEmpty() || !key.startsWith("sk-")) {
            _showToast("أدخل بيانات الـ Orchestrator"); return
        }
        val cfg = AIBuilderViewModel.WorkerConfig(
            id="orchestrator", name=name, apiKey=key,
            model="claude-sonnet-4-20250514", maxTokens=6000, rpm=5
        )
        vm.setOrchestrator(cfg)
        _showToast("✓ تم تعيين Orchestrator: $name")
    }

    private fun _startBuild() {
        val name = etProjectName.text.toString().trim()
        val desc = etProjectDesc.text.toString().trim()
        if(name.isEmpty()) { _showToast("أدخل اسم المشروع"); return }
        if(desc.isEmpty()) { _showToast("أدخل وصف المشروع"); return }
        if(vm.getWorkers().isEmpty()) { _showToast("أضف API Worker أولاً"); return }

        log.clear()
        tvLog.text = ""
        llProgress.visibility = VISIBLE
        llOutput.visibility = GONE
        btnBuild.isEnabled = false

        val cfg = AIBuilderViewModel.BuildConfig(
            projectName = name,
            description = desc,
            projectType = spinnerType.selectedItem?.toString() ?: "game",
            language    = spinnerLang.selectedItem?.toString() ?: "cpp",
            useMultiAPI = cbMultiAPI.isChecked && vm.getOrchestrator() != null
        )
        vm.startBuild(cfg)
    }

    private fun _renderWorkerList() {
        llWorkerList.removeAllViews()
        tvWorkerCount.text = "Workers: ${vm.getWorkers().size} / 25"
        for(w in vm.getWorkers()) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(cSurface)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            val tv = TextView(context).apply {
                text = "🔑 ${w.name} | ${w.model} | ${w.rpm}r/m"
                setTextColor(cText)
                textSize = 12f
                weight = 1f
            }
            val btnDel = Button(context).apply {
                text = "✕"
                setTextColor(cRed)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    vm.removeWorker(w.id)
                    _renderWorkerList()
                }
            }
            row.addView(tv)
            row.addView(btnDel)
            llWorkerList.addView(row)
        }
    }

    private fun _clearWorkerFields() {
        etApiName.setText("")
        etApiKey.setText("")
    }

    private fun _addLog(msg: String) {
        log.add(msg)
        tvLog.text = log.takeLast(15).joinToString("\n")
    }

    private fun _showToast(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    // ── UI Helpers ──
    private fun _addSectionTitle(parent: ViewGroup, title: String) {
        parent.addView(TextView(context).apply {
            text = title
            setTextColor(cAccent2)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(14), 0, dp(6))
        })
    }

    private fun _addSubtitle(parent: ViewGroup, title: String) {
        parent.addView(TextView(context).apply {
            text = title
            setTextColor(cDim)
            textSize = 11f
            setPadding(0, dp(4), 0, dp(4))
        })
    }

    private fun _addDivider(parent: ViewGroup) {
        parent.addView(View(context).apply {
            setBackgroundColor(Color.parseColor("#1a1835"))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(1)).apply {
                topMargin = dp(10); bottomMargin = dp(10)
            }
        })
    }

    private fun _addEditText(parent: ViewGroup, hint: String, default: String=""): EditText {
        val et = EditText(context).apply {
            this.hint = hint
            setText(default)
            setTextColor(cText)
            setHintTextColor(cDim)
            setBackgroundColor(Color.parseColor("#0d0a20"))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        parent.addView(et)
        return et
    }

    private fun _addEditTextMulti(parent: ViewGroup, hint: String, default: String=""): EditText {
        val et = _addEditText(parent, hint, default)
        et.minLines = 3
        et.gravity = Gravity.TOP
        return et
    }

    private fun _addPasswordField(parent: ViewGroup, hint: String): EditText {
        val et = _addEditText(parent, hint)
        et.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        return et
    }

    private fun _addSpinner(parent: ViewGroup, label: String, items: Array<String>): Spinner {
        parent.addView(TextView(context).apply {
            text = label; setTextColor(cDim); textSize=11f
            setPadding(0,dp(4),0,dp(2))
        })
        val sp = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, items).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setBackgroundColor(Color.parseColor("#0d0a20"))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        parent.addView(sp)
        return sp
    }

    private fun _makeButton(text: String, color: Int): Button {
        return Button(context).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val View.weight get() = (layoutParams as? LinearLayout.LayoutParams)?.weight ?: 0f
    private fun View.setWeight(w: Float) {
        layoutParams = (layoutParams as? LinearLayout.LayoutParams)?.also { it.weight=w }
    }
    private val MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP_CONTENT = LinearLayout.LayoutParams.WRAP_CONTENT
}
