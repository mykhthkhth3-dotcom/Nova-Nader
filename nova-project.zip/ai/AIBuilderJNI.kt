package com.nova.engine.ai

import android.content.Context
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

// ═══════════════════════════════════════════════════════
//  AI BUILDER JNI BRIDGE
//  يربط AIBuilder.h بـ Android + OkHttp
// ═══════════════════════════════════════════════════════

object AIBuilderBridge {

    // ── JNI Functions ──
    external fun nativeInit()
    external fun nativeAddWorker(id: String, name: String, apiKey: String,
                                  model: String, maxTokens: Int, rpm: Int, priority: Int): Boolean
    external fun nativeSetOrchestrator(id: String, name: String, apiKey: String,
                                        model: String, maxTokens: Int, rpm: Int): Boolean
    external fun nativeRemoveWorker(id: String)
    external fun nativeClearWorkers()
    external fun nativeGetWorkerCount(): Int
    external fun nativeBuild(name: String, desc: String, type: String,
                              lang: String, multiApi: Boolean)
    external fun nativeCancel()
    external fun nativeIsRunning(): Boolean
    external fun nativeGetOutputFiles(): String  // JSON map
    external fun nativeGetStats(): String        // JSON stats

    init { System.loadLibrary("nova-engine") }

    // HTTP client (OkHttp)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // ── HTTP Provider (يُستدعى من C++) ──
    @JvmStatic
    fun httpRequest(url: String, apiKey: String, body: String): String {
        return try {
            val req = Request.Builder()
                .url(url)
                .post(body.toRequestBody("application/json".toMediaType()))
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .addHeader("anthropic-dangerous-direct-browser-access", "true")
                .build()

            val resp = client.newCall(req).execute()
            val code = resp.code
            val resBody = resp.body?.string() ?: ""
            // Format: "STATUS_CODE\n" + body
            "$code\n$resBody"
        } catch (e: Exception) {
            "0\n{\"error\":\"${e.message}\"}"
        }
    }
}

// ═══════════════════════════════════════════════════════
//  AI BUILDER VIEW MODEL
//  واجهة المستخدم للـ Builder داخل التطبيق
// ═══════════════════════════════════════════════════════
class AIBuilderViewModel {

    data class WorkerConfig(
        val id: String,
        val name: String,
        val apiKey: String,
        val model: String = "claude-sonnet-4-20250514",
        val maxTokens: Int = 4000,
        val rpm: Int = 10,
        val priority: Int = 2
    )

    data class BuildConfig(
        val projectName: String,
        val description: String,
        val projectType: String,  // game, app, engine
        val language: String,     // cpp, kotlin, html
        val useMultiAPI: Boolean = false
    )

    data class BuildStatus(
        val phase: String = "",
        val progress: Float = 0f,
        val totalFiles: Int = 0,
        val totalLines: Int = 0,
        val totalRequests: Int = 0,
        val totalTokens: Int = 0,
        val elapsedSec: Float = 0f,
        val lastLog: String = ""
    )

    private val _workers = mutableListOf<WorkerConfig>()
    private var _orchestrator: WorkerConfig? = null
    private val _logs = mutableListOf<String>()
    private val _outputFiles = mutableMapOf<String, String>()

    var onStatusUpdate: ((BuildStatus) -> Unit)? = null
    var onLog: ((String, String) -> Unit)? = null
    var onComplete: ((Map<String, String>) -> Unit)? = null

    // ── Workers ──
    fun addWorker(cfg: WorkerConfig): Boolean {
        if(_workers.size >= 25) return false
        _workers.add(cfg)
        return AIBuilderBridge.nativeAddWorker(
            cfg.id, cfg.name, cfg.apiKey, cfg.model,
            cfg.maxTokens, cfg.rpm, cfg.priority
        )
    }

    fun setOrchestrator(cfg: WorkerConfig): Boolean {
        _orchestrator = cfg
        return AIBuilderBridge.nativeSetOrchestrator(
            cfg.id, cfg.name, cfg.apiKey, cfg.model,
            cfg.maxTokens, cfg.rpm
        )
    }

    fun removeWorker(id: String) {
        _workers.removeAll { it.id == id }
        AIBuilderBridge.nativeRemoveWorker(id)
    }

    fun getWorkers(): List<WorkerConfig> = _workers.toList()
    fun getOrchestrator(): WorkerConfig? = _orchestrator

    // ── Build ──
    fun startBuild(config: BuildConfig) {
        if(AIBuilderBridge.nativeIsRunning()) return
        _logs.clear()
        _outputFiles.clear()

        // Start polling status
        CoroutineScope(Dispatchers.IO).launch {
            AIBuilderBridge.nativeBuild(
                config.projectName, config.description,
                config.projectType, config.language,
                config.useMultiAPI
            )
        }

        // Poll status
        CoroutineScope(Dispatchers.Main).launch {
            while(AIBuilderBridge.nativeIsRunning()) {
                delay(500)
                _updateStatus()
            }
            _updateStatus()
            _loadOutputFiles()
        }
    }

    fun cancelBuild() = AIBuilderBridge.nativeCancel()
    fun isRunning() = AIBuilderBridge.nativeIsRunning()

    // ── Output ──
    fun getOutputFiles() = _outputFiles.toMap()

    fun saveOutputFiles(context: Context, projectName: String): String {
        val dir = File(context.filesDir, "nova_builds/$projectName")
        dir.mkdirs()
        var saved = 0
        for((name, code) in _outputFiles) {
            val file = File(dir, name)
            file.parentFile?.mkdirs()
            file.writeText(code)
            saved++
        }
        return dir.absolutePath
    }

    // ── Private ──
    private fun _updateStatus() {
        val statsJson = AIBuilderBridge.nativeGetStats()
        try {
            val j = JSONObject(statsJson)
            val status = BuildStatus(
                phase        = j.optString("phase"),
                progress     = j.optDouble("progress", 0.0).toFloat(),
                totalFiles   = j.optInt("totalFiles"),
                totalLines   = j.optInt("totalLines"),
                totalRequests= j.optInt("totalRequests"),
                totalTokens  = j.optInt("totalTokens"),
                elapsedSec   = j.optDouble("elapsedSec", 0.0).toFloat(),
                lastLog      = j.optString("lastLog")
            )
            onStatusUpdate?.invoke(status)
        } catch(e: Exception) { }
    }

    private fun _loadOutputFiles() {
        val json = AIBuilderBridge.nativeGetOutputFiles()
        try {
            val j = JSONObject(json)
            j.keys().forEach { key ->
                _outputFiles[key] = j.getString(key)
            }
            onComplete?.invoke(_outputFiles)
        } catch(e: Exception) { }
    }
}
