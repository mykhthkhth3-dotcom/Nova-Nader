#pragma once
#include "../Nova.h"
#include "../renderer/SoftwareRenderer.h"
#include "../math/Noise.h"

namespace Nova {

// ═══════════════════════════════════════════════════════
//  PROCEDURAL GEOMETRY — الجلسة الثالثة
//  كل الأشكال ثلاثية الأبعاد تُبنى بالكود فقط
//  لا ملفات خارجية — رياضيات بحتة
// ═══════════════════════════════════════════════════════

class ProceduralGeometry {
public:

    // ══════════════════════════════════════
    //  1. الأشكال الأساسية
    // ══════════════════════════════════════

    // ── كرة (Sphere) ──
    static Mesh* createSphere(f32 radius=1.0f, u32 rings=32, u32 segments=32) {
        u32 vCount = (rings+1) * (segments+1);
        u32 iCount = rings * segments * 6;
        auto* mesh = new Mesh();
        mesh->create(vCount, iCount);

        u32 vi=0, ii=0;
        for(u32 r=0; r<=rings; r++) {
            f32 phi = PI * r / rings;
            for(u32 s=0; s<=segments; s++) {
                f32 theta = TWO_PI * s / segments;
                f32 x = sinf(phi) * cosf(theta);
                f32 y = cosf(phi);
                f32 z = sinf(phi) * sinf(theta);
                mesh->vertices[vi].position = {x*radius, y*radius, z*radius};
                mesh->vertices[vi].normal   = {x, y, z};
                mesh->vertices[vi].uv       = {(f32)s/segments, (f32)r/rings};
                mesh->vertices[vi].color    = Vec4::WHITE;
                vi++;
            }
        }
        for(u32 r=0; r<rings; r++) {
            for(u32 s=0; s<segments; s++) {
                u32 a = r*(segments+1)+s;
                u32 b = a+segments+1;
                mesh->indices[ii++]=a;   mesh->indices[ii++]=b;   mesh->indices[ii++]=a+1;
                mesh->indices[ii++]=b;   mesh->indices[ii++]=b+1; mesh->indices[ii++]=a+1;
            }
        }
        return mesh;
    }

    // ── مكعب (Box) ──
    static Mesh* createBox(Vec3 size={1,1,1}) {
        auto* mesh = new Mesh();
        mesh->create(24, 36);
        Vec3 h = size * 0.5f;

        // 6 وجوه × 4 رؤوس
        struct Face { Vec3 normal; Vec3 positions[4]; Vec2 uvs[4]; };
        Face faces[6] = {
            // +X
            {{1,0,0}, {{h.x,-h.y,-h.z},{h.x,-h.y,h.z},{h.x,h.y,h.z},{h.x,h.y,-h.z}},
             {{0,1},{1,1},{1,0},{0,0}}},
            // -X
            {{-1,0,0}, {{-h.x,-h.y,h.z},{-h.x,-h.y,-h.z},{-h.x,h.y,-h.z},{-h.x,h.y,h.z}},
             {{0,1},{1,1},{1,0},{0,0}}},
            // +Y
            {{0,1,0}, {{-h.x,h.y,-h.z},{h.x,h.y,-h.z},{h.x,h.y,h.z},{-h.x,h.y,h.z}},
             {{0,0},{1,0},{1,1},{0,1}}},
            // -Y
            {{0,-1,0}, {{-h.x,-h.y,h.z},{h.x,-h.y,h.z},{h.x,-h.y,-h.z},{-h.x,-h.y,-h.z}},
             {{0,0},{1,0},{1,1},{0,1}}},
            // +Z
            {{0,0,1}, {{h.x,-h.y,h.z},{-h.x,-h.y,h.z},{-h.x,h.y,h.z},{h.x,h.y,h.z}},
             {{0,1},{1,1},{1,0},{0,0}}},
            // -Z
            {{0,0,-1}, {{-h.x,-h.y,-h.z},{h.x,-h.y,-h.z},{h.x,h.y,-h.z},{-h.x,h.y,-h.z}},
             {{0,1},{1,1},{1,0},{0,0}}},
        };

        for(u32 f=0; f<6; f++) {
            for(u32 v=0; v<4; v++) {
                mesh->vertices[f*4+v].position = faces[f].positions[v];
                mesh->vertices[f*4+v].normal   = faces[f].normal;
                mesh->vertices[f*4+v].uv       = faces[f].uvs[v];
                mesh->vertices[f*4+v].color    = Vec4::WHITE;
            }
            u32 b=f*4;
            mesh->indices[f*6+0]=b;   mesh->indices[f*6+1]=b+1; mesh->indices[f*6+2]=b+2;
            mesh->indices[f*6+3]=b;   mesh->indices[f*6+4]=b+2; mesh->indices[f*6+5]=b+3;
        }
        return mesh;
    }

    // ── أسطوانة (Cylinder) ──
    static Mesh* createCylinder(f32 radiusTop=0.5f, f32 radiusBottom=0.5f,
                                 f32 height=1.0f, u32 segments=32)
    {
        u32 vCount = (segments+1)*2 + segments*2;
        u32 iCount = segments*6 + (segments-2)*3*2;
        auto* mesh = new Mesh();
        mesh->create(vCount, iCount);

        u32 vi=0, ii=0;
        f32 h = height * 0.5f;

        // جانب الأسطوانة
        for(u32 s=0; s<=segments; s++) {
            f32 theta = TWO_PI * s / segments;
            f32 cx = cosf(theta), cz = sinf(theta);
            Vec3 n = Vec3(cx, 0, cz).normalized();

            mesh->vertices[vi].position = {cx*radiusBottom, -h, cz*radiusBottom};
            mesh->vertices[vi].normal = n;
            mesh->vertices[vi].uv = {(f32)s/segments, 1.0f};
            vi++;

            mesh->vertices[vi].position = {cx*radiusTop, h, cz*radiusTop};
            mesh->vertices[vi].normal = n;
            mesh->vertices[vi].uv = {(f32)s/segments, 0.0f};
            vi++;
        }

        for(u32 s=0; s<segments; s++) {
            u32 b = s*2;
            mesh->indices[ii++]=b;   mesh->indices[ii++]=b+2; mesh->indices[ii++]=b+1;
            mesh->indices[ii++]=b+1; mesh->indices[ii++]=b+2; mesh->indices[ii++]=b+3;
        }

        // قاع وقمة
        u32 capBase = vi;
        for(u32 s=0; s<segments; s++) {
            f32 theta = TWO_PI * s / segments;
            mesh->vertices[vi].position = {cosf(theta)*radiusBottom, -h, sinf(theta)*radiusBottom};
            mesh->vertices[vi].normal   = {0,-1,0};
            mesh->vertices[vi].uv       = {cosf(theta)*0.5f+0.5f, sinf(theta)*0.5f+0.5f};
            vi++;
        }
        for(u32 s=1; s+1<segments; s++) {
            mesh->indices[ii++]=capBase; mesh->indices[ii++]=capBase+s+1; mesh->indices[ii++]=capBase+s;
        }

        u32 topBase = vi;
        for(u32 s=0; s<segments; s++) {
            f32 theta = TWO_PI * s / segments;
            mesh->vertices[vi].position = {cosf(theta)*radiusTop, h, sinf(theta)*radiusTop};
            mesh->vertices[vi].normal   = {0,1,0};
            mesh->vertices[vi].uv       = {cosf(theta)*0.5f+0.5f, sinf(theta)*0.5f+0.5f};
            vi++;
        }
        for(u32 s=1; s+1<segments; s++) {
            mesh->indices[ii++]=topBase; mesh->indices[ii++]=topBase+s; mesh->indices[ii++]=topBase+s+1;
        }

        return mesh;
    }

    // ── مخروط (Cone) ──
    static Mesh* createCone(f32 radius=0.5f, f32 height=1.0f, u32 segments=32) {
        return createCylinder(0.001f, radius, height, segments);
    }

    // ── كبسولة (Capsule) ──
    static Mesh* createCapsule(f32 radius=0.5f, f32 height=1.0f, u32 segments=16) {
        u32 rings = segments/2;
        u32 vCount = (rings+1)*(segments+1)*2 + (segments+1)*2;
        u32 iCount = rings*segments*6*2 + segments*6;
        auto* mesh = new Mesh();
        mesh->create(vCount*2, iCount*2); // تقدير زائد

        u32 vi=0, ii=0;
        f32 h = height * 0.5f;

        // نصف كرة علوية
        for(u32 r=0; r<=rings; r++) {
            f32 phi = HALF_PI * r / rings;
            for(u32 s=0; s<=segments; s++) {
                f32 theta = TWO_PI * s / segments;
                f32 x = sinf(phi)*cosf(theta);
                f32 y = cosf(phi);
                f32 z = sinf(phi)*sinf(theta);
                mesh->vertices[vi].position = {x*radius, y*radius+h, z*radius};
                mesh->vertices[vi].normal   = {x,y,z};
                mesh->vertices[vi].uv       = {(f32)s/segments, (f32)r/(rings*2)};
                vi++;
            }
        }
        // نصف كرة سفلية
        for(u32 r=0; r<=rings; r++) {
            f32 phi = HALF_PI + HALF_PI * r / rings;
            for(u32 s=0; s<=segments; s++) {
                f32 theta = TWO_PI * s / segments;
                f32 x = sinf(phi)*cosf(theta);
                f32 y = cosf(phi);
                f32 z = sinf(phi)*sinf(theta);
                mesh->vertices[vi].position = {x*radius, y*radius-h, z*radius};
                mesh->vertices[vi].normal   = {x,y,z};
                mesh->vertices[vi].uv       = {(f32)s/segments, 0.5f+(f32)r/(rings*2)};
                vi++;
            }
        }

        u32 totalRings = (rings+1)*2;
        for(u32 r=0; r+1<totalRings; r++) {
            for(u32 s=0; s<segments; s++) {
                u32 a=r*(segments+1)+s, b=a+segments+1;
                if(ii+5 < iCount*2) {
                    mesh->indices[ii++]=a;   mesh->indices[ii++]=b;   mesh->indices[ii++]=a+1;
                    mesh->indices[ii++]=b;   mesh->indices[ii++]=b+1; mesh->indices[ii++]=a+1;
                }
            }
        }
        mesh->idxCount = ii;
        mesh->vertCount = vi;
        return mesh;
    }

    // ══════════════════════════════════════
    //  2. الأشكال الرياضية المعقدة
    // ══════════════════════════════════════

    // ── Torus Knot ──
    static Mesh* createTorusKnot(i32 p=3, i32 q=5, f32 R=1.4f, f32 r=0.3f,
                                   u32 uSeg=256, u32 vSeg=20)
    {
        u32 vCount = (uSeg+1)*(vSeg+1);
        u32 iCount = uSeg*vSeg*6;
        auto* mesh = new Mesh();
        mesh->create(vCount, iCount);

        u32 vi=0, ii=0;

        for(u32 i=0; i<=uSeg; i++) {
            f32 u = (f32)i/uSeg * TWO_PI;

            // Torus knot curve
            f32 r1 = R + r*cosf(q*u/p);
            Vec3 center = { r1*cosf(u), r1*sinf(u), r*sinf(q*u/p) };

            // Tangent
            f32 du = -sinf(u)*(R+r*cosf(q*u/p)) - r*(f32)q/(f32)p*sinf(q*u/p)*cosf(u);
            f32 dv =  cosf(u)*(R+r*cosf(q*u/p)) - r*(f32)q/(f32)p*sinf(q*u/p)*sinf(u);
            f32 dw =  r*(f32)q/(f32)p*cosf(q*u/p);
            Vec3 T = Vec3(du,dv,dw).normalized();

            // Normal & Binormal frame
            Vec3 N = Vec3(-sinf(u), cosf(u), 0).normalized();
            Vec3 B = T.cross(N).normalized();
            N = B.cross(T);

            for(u32 j=0; j<=vSeg; j++) {
                f32 v = (f32)j/vSeg * TWO_PI;
                Vec3 pos = center + (N*cosf(v) + B*sinf(v))*r*0.35f;
                mesh->vertices[vi].position = pos;
                mesh->vertices[vi].normal   = (N*cosf(v)+B*sinf(v)).normalized();
                mesh->vertices[vi].uv       = {(f32)i/uSeg, (f32)j/vSeg};
                mesh->vertices[vi].color    = Vec4(
                    0.5f+0.5f*cosf(u), 0.5f+0.5f*sinf(u*0.7f), 0.8f, 1.0f);
                vi++;
            }
        }

        for(u32 i=0; i<uSeg; i++) for(u32 j=0; j<vSeg; j++) {
            u32 a=i*(vSeg+1)+j, b=a+vSeg+1;
            mesh->indices[ii++]=a;   mesh->indices[ii++]=b;   mesh->indices[ii++]=a+1;
            mesh->indices[ii++]=b;   mesh->indices[ii++]=b+1; mesh->indices[ii++]=a+1;
        }
        return mesh;
    }

    // ── Torus (حلقة) ──
    static Mesh* createTorus(f32 R=1.0f, f32 r=0.3f, u32 uSeg=48, u32 vSeg=24) {
        u32 vCount=(uSeg+1)*(vSeg+1), iCount=uSeg*vSeg*6;
        auto* mesh=new Mesh(); mesh->create(vCount,iCount);
        u32 vi=0,ii=0;
        for(u32 i=0;i<=uSeg;i++) {
            f32 u=TWO_PI*i/uSeg;
            for(u32 j=0;j<=vSeg;j++) {
                f32 v=TWO_PI*j/vSeg;
                f32 x=(R+r*cosf(v))*cosf(u);
                f32 y=r*sinf(v);
                f32 z=(R+r*cosf(v))*sinf(u);
                Vec3 n={(cosf(v)*cosf(u)),(sinf(v)),(cosf(v)*sinf(u))};
                mesh->vertices[vi]={{x,y,z},n,{(f32)i/uSeg,(f32)j/vSeg}};
                vi++;
            }
        }
        for(u32 i=0;i<uSeg;i++) for(u32 j=0;j<vSeg;j++) {
            u32 a=i*(vSeg+1)+j,b=a+vSeg+1;
            mesh->indices[ii++]=a; mesh->indices[ii++]=b; mesh->indices[ii++]=a+1;
            mesh->indices[ii++]=b; mesh->indices[ii++]=b+1;mesh->indices[ii++]=a+1;
        }
        return mesh;
    }

    // ── Parametric Surface ──
    static Mesh* createParametric(
        std::function<Vec3(f32 u, f32 v)> fn,
        u32 uSeg=64, u32 vSeg=64,
        std::function<Vec4(f32,f32)> colorFn=nullptr)
    {
        u32 vCount=(uSeg+1)*(vSeg+1), iCount=uSeg*vSeg*6;
        auto* mesh=new Mesh(); mesh->create(vCount,iCount);
        u32 vi=0,ii=0;

        for(u32 i=0;i<=uSeg;i++) {
            f32 u=(f32)i/uSeg;
            for(u32 j=0;j<=vSeg;j++) {
                f32 v=(f32)j/vSeg;
                Vec3 pos=fn(u,v);

                // حساب النورمال بالفرق المحدود
                Vec3 du=fn(u+0.001f,v)-fn(u-0.001f,v);
                Vec3 dv2=fn(u,v+0.001f)-fn(u,v-0.001f);
                Vec3 n=du.cross(dv2).normalized();

                Vec4 col = colorFn ? colorFn(u,v) : Vec4::WHITE;
                mesh->vertices[vi]={pos,n,{u,v},col};
                vi++;
            }
        }
        for(u32 i=0;i<uSeg;i++) for(u32 j=0;j<vSeg;j++) {
            u32 a=i*(vSeg+1)+j,b=a+vSeg+1;
            mesh->indices[ii++]=a; mesh->indices[ii++]=b; mesh->indices[ii++]=a+1;
            mesh->indices[ii++]=b; mesh->indices[ii++]=b+1;mesh->indices[ii++]=a+1;
        }
        return mesh;
    }

    // ── Klein Bottle ──
    static Mesh* createKleinBottle(u32 uSeg=80, u32 vSeg=40) {
        return createParametric([](f32 u, f32 v) -> Vec3 {
            f32 a = u * TWO_PI;
            f32 b = v * TWO_PI;
            f32 x,y,z;
            if(a < PI) {
                x = 3*cosf(a)*(1+sinf(a)) + 2*(1-cosf(a)/2)*cosf(a)*cosf(b);
                z = -8*sinf(a) - 2*(1-cosf(a)/2)*sinf(a)*cosf(b);
            } else {
                x = 3*cosf(a)*(1+sinf(a)) + 2*(1-cosf(a)/2)*cosf(b+PI);
                z = -8*sinf(a);
            }
            y = -2*(1-cosf(a)/2)*sinf(b);
            return {x*0.1f, y*0.1f, z*0.1f};
        }, uSeg, vSeg);
    }

    // ── Möbius Strip ──
    static Mesh* createMobiusStrip(f32 R=1.0f, f32 w=0.4f, u32 uSeg=128, u32 vSeg=16) {
        return createParametric([R,w](f32 u, f32 v) -> Vec3 {
            f32 a = u * TWO_PI;
            f32 t = (v-0.5f)*w;
            f32 x = (R + t*cosf(a/2)) * cosf(a);
            f32 y = (R + t*cosf(a/2)) * sinf(a);
            f32 z = t * sinf(a/2);
            return {x,y,z};
        }, uSeg, vSeg);
    }

    // ══════════════════════════════════════
    //  3. الطائرات والمركبات (بالكود)
    // ══════════════════════════════════════

    // ── F-22 Raptor (مبسط بالكود) ──
    static Mesh* createF22Body() {
        // جسم الطائرة = مجموعة أشكال parametric مدمجة
        return createParametric([](f32 u, f32 v) -> Vec3 {
            // طول الجسم على المحور Z
            f32 len  = 19.0f;
            f32 z    = (u - 0.5f) * len;

            // شكل المقطع العرضي (يتغير على طول الجسم)
            f32 t    = u;
            // عرض الجسم - يضيق عند المقدمة والمؤخرة
            f32 w    = sinf(t * PI) * 1.8f * (1.0f - 0.3f*fabsf(t-0.5f)*2);
            // ارتفاع الجسم
            f32 h    = sinf(t * PI) * 0.7f;

            f32 theta = v * TWO_PI;
            // مقطع بيضاوي مع تسطيح أسفلي
            f32 x = cosf(theta) * w;
            f32 y = sinf(theta) * h * (theta < PI ? 1.0f : 0.6f);

            return {x, y, z};
        }, 80, 32, [](f32 u, f32 v) -> Vec4 {
            // ألوان الطائرة الشبحية
            f32 dark = 0.15f + u * 0.1f;
            return {dark, dark+0.02f, dark+0.05f, 1.0f};
        });
    }

    // ── جناح الطائرة ──
    static Mesh* createWing(f32 span=5.0f, f32 chord=2.0f, f32 sweep=35.0f) {
        f32 sweepRad = sweep * DEG2RAD;
        return createParametric([span, chord, sweepRad](f32 u, f32 v) -> Vec3 {
            f32 y = u * span;
            f32 sweepOffset = tanf(sweepRad) * y;
            f32 chordLocal  = chord * (1.0f - u * 0.7f); // تتناقص نحو الطرف

            // NACA 0012 airfoil profile
            f32 xc = v;
            f32 t  = 0.12f; // سُمك 12%
            f32 yt = 5*t*(0.2969f*sqrtf(xc) - 0.1260f*xc
                        - 0.3516f*xc*xc + 0.2843f*xc*xc*xc
                        - 0.1015f*xc*xc*xc*xc);

            // وجه علوي وسفلي
            f32 x = xc * chordLocal - sweepOffset;
            f32 z = (v < 0.5f ? yt : -yt) * chordLocal;

            return {x, y, z};
        }, 32, 32);
    }

    // ══════════════════════════════════════
    //  4. التضاريس والبيئة
    // ══════════════════════════════════════

    // ── Terrain بالـ Noise ──
    static Mesh* createTerrain(f32 size=100.0f, u32 res=128,
                                f32 maxHeight=20.0f, u64 seed=42)
    {
        Noise noise(seed);
        return createParametric([&](f32 u, f32 v) -> Vec3 {
            f32 x = (u-0.5f)*size;
            f32 z = (v-0.5f)*size;

            // Fractal noise متعدد الأوكتاف
            f32 h = 0;
            f32 amp=1, freq=1, total=0;
            for(int oct=0; oct<6; oct++) {
                h += noise.fbm(x*freq*0.02f, z*freq*0.02f) * amp;
                total += amp;
                amp   *= 0.5f;
                freq  *= 2.0f;
            }
            h = (h/total) * maxHeight;

            return {x, h, z};
        }, res, res, [](f32 u, f32 v) -> Vec4 {
            // لون حسب الارتفاع (تقريبي)
            return {0.2f+u*0.1f, 0.35f+v*0.1f, 0.15f, 1.0f};
        });
    }

    // ── سحابة إجرائية ──
    static Mesh* createCloud(f32 size=5.0f, u32 puffs=8, u64 seed=0) {
        // نبني السحابة من مجموعة كرات صغيرة مدمجة (Meta-balls تقريبية)
        u32 totalV = puffs * 200;
        u32 totalI = puffs * 600;
        auto* mesh = new Mesh();
        mesh->create(totalV, totalI);

        srand((u32)seed);
        u32 vi=0, ii=0;

        for(u32 p=0; p<puffs; p++) {
            f32 px = ((f32)rand()/RAND_MAX - 0.5f) * size;
            f32 py = ((f32)rand()/RAND_MAX - 0.2f) * size * 0.3f;
            f32 pz = ((f32)rand()/RAND_MAX - 0.5f) * size;
            f32 pr = size * 0.2f + ((f32)rand()/RAND_MAX) * size * 0.2f;

            // Mini-sphere per puff
            u32 rings=8, segs=10;
            u32 baseV = vi;
            for(u32 r=0;r<=rings;r++) {
                f32 phi=PI*r/rings;
                for(u32 s=0;s<=segs;s++) {
                    f32 theta=TWO_PI*s/segs;
                    f32 x=sinf(phi)*cosf(theta);
                    f32 y=cosf(phi);
                    f32 z2=sinf(phi)*sinf(theta);
                    if(vi<totalV) {
                        mesh->vertices[vi].position={px+x*pr,py+y*pr*0.6f,pz+z2*pr};
                        mesh->vertices[vi].normal={x,y,z2};
                        mesh->vertices[vi].uv={(f32)s/segs,(f32)r/rings};
                        mesh->vertices[vi].color={1,1,1,0.7f};
                        vi++;
                    }
                }
            }
            for(u32 r=0;r<rings;r++) for(u32 s=0;s<segs;s++) {
                u32 a=baseV+r*(segs+1)+s, b=a+segs+1;
                if(ii+5<totalI) {
                    mesh->indices[ii++]=a; mesh->indices[ii++]=b; mesh->indices[ii++]=a+1;
                    mesh->indices[ii++]=b; mesh->indices[ii++]=b+1;mesh->indices[ii++]=a+1;
                }
            }
        }
        mesh->vertCount=vi; mesh->idxCount=ii;
        return mesh;
    }

    // ══════════════════════════════════════
    //  5. تأثيرات الجسيمات (Particles)
    // ══════════════════════════════════════
    static Mesh* createParticleBillboard(u32 count=1000, f32 spread=5.0f) {
        auto* mesh = new Mesh();
        mesh->create(count*4, count*6);

        srand(12345);
        for(u32 i=0; i<count; i++) {
            f32 x=((f32)rand()/RAND_MAX-0.5f)*spread*2;
            f32 y=((f32)rand()/RAND_MAX)*spread;
            f32 z=((f32)rand()/RAND_MAX-0.5f)*spread*2;
            f32 s=0.02f+((f32)rand()/RAND_MAX)*0.08f;

            u32 b=i*4;
            mesh->vertices[b+0]={{x-s,y-s,z},{0,0,1},{0,0}};
            mesh->vertices[b+1]={{x+s,y-s,z},{0,0,1},{1,0}};
            mesh->vertices[b+2]={{x+s,y+s,z},{0,0,1},{1,1}};
            mesh->vertices[b+3]={{x-s,y+s,z},{0,0,1},{0,1}};

            mesh->indices[i*6+0]=b;   mesh->indices[i*6+1]=b+1; mesh->indices[i*6+2]=b+2;
            mesh->indices[i*6+3]=b;   mesh->indices[i*6+4]=b+2; mesh->indices[i*6+5]=b+3;
        }
        return mesh;
    }

    // ── حساب النورمالز تلقائياً ──
    static void recalculateNormals(Mesh& mesh) {
        for(u32 v=0; v<mesh.vertCount; v++)
            mesh.vertices[v].normal = Vec3::ZERO;

        for(u32 i=0; i+2<mesh.idxCount; i+=3) {
            u32 i0=mesh.indices[i],i1=mesh.indices[i+1],i2=mesh.indices[i+2];
            Vec3 e1=mesh.vertices[i1].position-mesh.vertices[i0].position;
            Vec3 e2=mesh.vertices[i2].position-mesh.vertices[i0].position;
            Vec3 n=e1.cross(e2);
            mesh.vertices[i0].normal+=n;
            mesh.vertices[i1].normal+=n;
            mesh.vertices[i2].normal+=n;
        }
        for(u32 v=0; v<mesh.vertCount; v++)
            mesh.vertices[v].normal=mesh.vertices[v].normal.normalized();
    }

    // ── دمج مجموعة أشكال ──
    static Mesh* mergeMeshes(Mesh** meshes, u32 count) {
        u32 totalV=0, totalI=0;
        for(u32 i=0;i<count;i++){totalV+=meshes[i]->vertCount;totalI+=meshes[i]->idxCount;}
        auto* out=new Mesh(); out->create(totalV,totalI);
        u32 vo=0,io=0,vbase=0;
        for(u32 m=0;m<count;m++){
            for(u32 v=0;v<meshes[m]->vertCount;v++) out->vertices[vo++]=meshes[m]->vertices[v];
            for(u32 i=0;i<meshes[m]->idxCount;i++) out->indices[io++]=meshes[m]->indices[i]+vbase;
            vbase+=meshes[m]->vertCount;
        }
        return out;
    }
};

} // namespace Nova
