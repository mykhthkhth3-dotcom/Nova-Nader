#pragma once
#include "../Nova.h"
#include "../math/Transform.h"
#include "../renderer/SoftwareRenderer.h"
#include "../geometry/ProceduralGeometry.h"
#include <vector>
#include <string>
#include <functional>

namespace Nova {

// ═══════════════════════════════════════════════════════
//  SCENE GRAPH — شجرة المشهد ثلاثي الأبعاد
//  كل كائن له أب وأبناء + مكونات قابلة للإضافة
// ═══════════════════════════════════════════════════════

class SceneNode;
using NodePtr = SceneNode*;

// ── Component Base ──
struct Component {
    SceneNode* owner = nullptr;
    bool enabled = true;
    virtual void onStart() {}
    virtual void onUpdate(f32 dt) {}
    virtual void onDestroy() {}
    virtual ~Component() = default;
};

// ── Mesh Renderer Component ──
struct MeshRenderer : Component {
    Mesh*     mesh     = nullptr;
    Material* material = nullptr;
    bool      visible  = true;
    bool      ownsMesh = false;

    ~MeshRenderer() { if(ownsMesh && mesh) { mesh->destroy(); delete mesh; } }
};

// ── Camera Component ──
struct CameraComponent : Component {
    f32  fov    = 60.0f;
    f32  near   = 0.1f;
    f32  far    = 5000.0f;
    bool active = false;

    void apply(SoftwareRenderer& r, const Transform& t) {
        Vec3 pos    = t.position;
        Vec3 target = pos + t.forward();
        Vec3 up     = t.up();
        r.setCamera(pos, target, up, fov, near, far);
    }
};

// ── Script Component (سكريبت مخصص) ──
struct ScriptComponent : Component {
    std::function<void(SceneNode*, f32)> updateFn;
    std::function<void(SceneNode*)>      startFn;

    void onStart()            override { if(startFn)  startFn(owner); }
    void onUpdate(f32 dt)     override { if(updateFn) updateFn(owner, dt); }
};

// ═══════════════════════════════════════════════════════
//  SCENE NODE
// ═══════════════════════════════════════════════════════
class SceneNode {
public:
    std::string  name;
    Transform    localTransform;
    bool         active = true;
    u32          id;
    u32          layer  = 0;

    SceneNode(const std::string& nm="Node") : name(nm) {
        static u32 s_id=0; id=++s_id;
    }

    ~SceneNode() {
        for(auto* c : _components) delete c;
        for(auto* child : _children) delete child;
    }

    // ── Hierarchy ──
    SceneNode* addChild(const std::string& nm="Node") {
        auto* child = new SceneNode(nm);
        child->_parent = this;
        _children.push_back(child);
        return child;
    }

    void removeChild(SceneNode* child) {
        for(u32 i=0;i<_children.size();i++) {
            if(_children[i]==child){ _children.erase(_children.begin()+i); break; }
        }
    }

    SceneNode* getParent() const { return _parent; }
    const std::vector<SceneNode*>& getChildren() const { return _children; }

    SceneNode* findChild(const std::string& nm) {
        for(auto* c:_children) if(c->name==nm) return c;
        for(auto* c:_children) { auto* r=c->findChild(nm); if(r) return r; }
        return nullptr;
    }

    // ── World Transform ──
    Transform getWorldTransform() const {
        if(!_parent) return localTransform;
        return _parent->getWorldTransform() * localTransform;
    }

    Mat4 getWorldMatrix() const { return getWorldTransform().toMatrix(); }
    Vec3 getWorldPosition() const { return getWorldTransform().position; }

    // ── Components ──
    template<typename T, typename... Args>
    T* addComponent(Args&&... args) {
        auto* c = new T(std::forward<Args>(args)...);
        c->owner = this;
        _components.push_back(c);
        c->onStart();
        return c;
    }

    template<typename T>
    T* getComponent() {
        for(auto* c:_components) {
            auto* t=dynamic_cast<T*>(c);
            if(t) return t;
        }
        return nullptr;
    }

    template<typename T>
    bool hasComponent() { return getComponent<T>() != nullptr; }

    // ── Update ──
    void update(f32 dt) {
        if(!active) return;
        for(auto* c:_components) if(c->enabled) c->onUpdate(dt);
        for(auto* child:_children) child->update(dt);
    }

    // ── Render ──
    void render(SoftwareRenderer& r) {
        if(!active) return;
        auto* mr = getComponent<MeshRenderer>();
        if(mr && mr->visible && mr->mesh) {
            RenderObject ro;
            ro.mesh      = mr->mesh;
            ro.material  = mr->material;
            ro.transform = getWorldMatrix();
            r.draw(ro);
        }
        for(auto* child:_children) child->render(r);
    }

    // ── Shortcuts ──
    void setPosition(const Vec3& p) { localTransform.position=p; }
    void setRotation(const Quat& q) { localTransform.rotation=q; }
    void setScale   (const Vec3& s) { localTransform.scale=s; }
    void setScale   (f32 s)         { localTransform.scale={s,s,s}; }
    Vec3 getPosition() const { return localTransform.position; }
    Quat getRotation() const { return localTransform.rotation; }
    Vec3 getScale()    const { return localTransform.scale; }

    void rotate(const Vec3& axis, f32 angle) {
        localTransform.rotation = localTransform.rotation * Quat::fromAxisAngle(axis, angle);
        localTransform.rotation = localTransform.rotation.normalized();
    }

    void translate(const Vec3& delta) { localTransform.position += delta; }

private:
    SceneNode* _parent = nullptr;
    std::vector<SceneNode*>  _children;
    std::vector<Component*>  _components;
};

// ═══════════════════════════════════════════════════════
//  SCENE — المشهد الكامل
// ═══════════════════════════════════════════════════════
class Scene {
public:
    std::string name = "Scene";

    Scene() { _root = new SceneNode("Root"); }
    ~Scene() { delete _root; }

    SceneNode* getRoot() { return _root; }

    SceneNode* createNode(const std::string& nm="Node", SceneNode* parent=nullptr) {
        if(!parent) parent=_root;
        return parent->addChild(nm);
    }

    // ── Active Camera ──
    void setActiveCamera(SceneNode* camNode) { _activeCamera=camNode; }

    void applyCamera(SoftwareRenderer& r) {
        if(!_activeCamera) return;
        auto* cam=_activeCamera->getComponent<CameraComponent>();
        if(cam) cam->apply(r, _activeCamera->getWorldTransform());
    }

    // ── Update + Render ──
    void update(f32 dt) { _root->update(dt); }

    void render(SoftwareRenderer& r) {
        applyCamera(r);
        r.beginFrame();
        _root->render(r);
        r.endFrame();
    }

    // ── Find ──
    SceneNode* findNode(const std::string& nm) { return _root->findChild(nm); }

    // ── Lights ──
    void addLight(const Light& l) {
        _lights.push_back(l);
    }
    void applyLights(SoftwareRenderer& r) {
        r.clearLights();
        for(auto& l:_lights) r.addLight(l);
    }

    // ── Factory helpers ──
    SceneNode* createMeshNode(const std::string& nm, Mesh* mesh,
                               Material* mat=nullptr, SceneNode* parent=nullptr)
    {
        auto* node = createNode(nm, parent);
        auto* mr   = node->addComponent<MeshRenderer>();
        mr->mesh     = mesh;
        mr->material = mat;
        mr->ownsMesh = true;
        return node;
    }

    SceneNode* createCameraNode(const std::string& nm="Camera",
                                 f32 fov=60, f32 near=0.1f, f32 far=5000)
    {
        auto* node = createNode(nm);
        auto* cam  = node->addComponent<CameraComponent>();
        cam->fov=fov; cam->near=near; cam->far=far;
        setActiveCamera(node);
        return node;
    }

private:
    SceneNode*          _root          = nullptr;
    SceneNode*          _activeCamera  = nullptr;
    std::vector<Light>  _lights;
};

} // namespace Nova
