#pragma once
#include "../Nova.h"
#include "../math/Vec3.h"
#include "../math/Quat.h"
#include "../math/Transform.h"
#include "../math/AABB.h"
#include <vector>
#include <functional>

namespace Nova {

// ═══════════════════════════════════════════════════════
//  NOVA PHYSICS ENGINE — الجلسة الرابعة
//  محرك فيزياء كامل بالكود
//  Rigid Body + Collision + Constraints + Raycasting
// ═══════════════════════════════════════════════════════

// ── Collision Shapes ──
enum class ShapeType { SPHERE, BOX, CAPSULE, PLANE, MESH };

struct CollisionShape {
    ShapeType type;
    union {
        struct { f32 radius; } sphere;
        struct { Vec3 halfExtents; } box;
        struct { f32 radius; f32 height; } capsule;
        struct { Vec3 normal; f32 dist; } plane;
    };
    Vec3 localOffset = Vec3::ZERO;

    static CollisionShape makeSphere(f32 r) {
        CollisionShape s; s.type=ShapeType::SPHERE; s.sphere.radius=r; return s;
    }
    static CollisionShape makeBox(Vec3 half) {
        CollisionShape s; s.type=ShapeType::BOX; s.box.halfExtents=half; return s;
    }
    static CollisionShape makeCapsule(f32 r, f32 h) {
        CollisionShape s; s.type=ShapeType::CAPSULE;
        s.capsule.radius=r; s.capsule.height=h; return s;
    }
    static CollisionShape makePlane(Vec3 n={0,1,0}, f32 d=0) {
        CollisionShape s; s.type=ShapeType::PLANE;
        s.plane.normal=n; s.plane.dist=d; return s;
    }
};

// ── Contact Point ──
struct Contact {
    Vec3  point;
    Vec3  normal;
    f32   depth;
    u32   bodyA, bodyB;
    f32   restitution = 0.3f;
    f32   friction    = 0.5f;
};

// ── Rigid Body ──
struct RigidBody {
    u32        id;
    bool       isStatic   = false;
    bool       isTrigger  = false;
    bool       active     = true;
    bool       useGravity = true;
    bool       isSleeping = false;

    // Transform
    Vec3 position    = Vec3::ZERO;
    Quat rotation    = Quat::IDENTITY;

    // Linear
    Vec3 velocity    = Vec3::ZERO;
    Vec3 force       = Vec3::ZERO;
    f32  mass        = 1.0f;
    f32  invMass     = 1.0f;
    f32  linearDamp  = 0.01f;

    // Angular
    Vec3 angularVelocity = Vec3::ZERO;
    Vec3 torque          = Vec3::ZERO;
    Vec3 inertiaTensor   = {1,1,1};   // diagonal
    f32  angularDamp     = 0.05f;

    // Material
    f32  restitution = 0.3f;
    f32  friction    = 0.5f;

    // Shape
    CollisionShape shape = CollisionShape::makeSphere(0.5f);
    AABB           aabb;

    // Sleep
    f32  sleepTimer  = 0.0f;
    f32  sleepThresh = 0.01f;

    // User data
    void* userData   = nullptr;

    void setMass(f32 m) {
        mass = m;
        invMass = (m > EPSILON && !isStatic) ? 1.0f/m : 0.0f;
    }

    void applyForce(const Vec3& f) { force += f; }
    void applyForceAt(const Vec3& f, const Vec3& point) {
        force  += f;
        torque += (point - position).cross(f);
    }
    void applyImpulse(const Vec3& imp) { velocity += imp * invMass; }
    void applyTorqueImpulse(const Vec3& t) { angularVelocity += t; }

    void clearForces() { force = Vec3::ZERO; torque = Vec3::ZERO; }

    void updateAABB() {
        switch(shape.type) {
            case ShapeType::SPHERE: {
                f32 r=shape.sphere.radius;
                aabb={position-Vec3(r), position+Vec3(r)};
                break;
            }
            case ShapeType::BOX: {
                Vec3 h=shape.box.halfExtents;
                aabb={position-h, position+h};
                break;
            }
            case ShapeType::CAPSULE: {
                f32 r=shape.capsule.radius;
                f32 h=shape.capsule.height*0.5f;
                aabb={position-Vec3(r,h+r,r), position+Vec3(r,h+r,r)};
                break;
            }
            default:
                aabb={position-Vec3(1), position+Vec3(1)};
        }
    }
};

// ── Raycast Result ──
struct RayHit {
    bool  hit      = false;
    Vec3  point    = Vec3::ZERO;
    Vec3  normal   = Vec3::UP;
    f32   distance = 0.0f;
    u32   bodyId   = 0;
};

// ── Constraint (Joint) ──
struct Constraint {
    enum Type { DISTANCE, HINGE, BALL_SOCKET };
    Type type;
    u32  bodyA, bodyB;
    Vec3 anchorA, anchorB;
    f32  minDist=0, maxDist=1;
    f32  stiffness=0.5f;
};

// ═══════════════════════════════════════════════════════
//  PHYSICS WORLD
// ═══════════════════════════════════════════════════════
class PhysicsWorld {
public:
    Vec3  gravity      = {0.0f, -9.81f, 0.0f};
    f32   fixedStep    = 1.0f / 60.0f;
    u32   maxSubSteps  = 4;
    bool  debugDraw    = false;

    using CollisionCallback = std::function<void(RigidBody&, RigidBody&, const Contact&)>;
    using TriggerCallback   = std::function<void(RigidBody&, RigidBody&)>;

    CollisionCallback onCollision;
    TriggerCallback   onTriggerEnter;
    TriggerCallback   onTriggerExit;

    // ── Body Management ──
    RigidBody* createBody(const CollisionShape& shape, bool isStatic=false) {
        auto* b = new RigidBody();
        b->id       = _nextId++;
        b->shape    = shape;
        b->isStatic = isStatic;
        if(isStatic) b->invMass = 0;
        b->updateAABB();
        _bodies.push_back(b);
        return b;
    }

    void destroyBody(RigidBody* b) {
        for(u32 i=0;i<_bodies.size();i++) {
            if(_bodies[i]==b){ _bodies.erase(_bodies.begin()+i); delete b; return; }
        }
    }

    RigidBody* createSphere(Vec3 pos, f32 r=0.5f, f32 mass=1.0f) {
        auto* b=createBody(CollisionShape::makeSphere(r));
        b->position=pos; b->setMass(mass); return b;
    }

    RigidBody* createBox(Vec3 pos, Vec3 half={0.5f,0.5f,0.5f}, f32 mass=1.0f) {
        auto* b=createBody(CollisionShape::makeBox(half));
        b->position=pos; b->setMass(mass); return b;
    }

    RigidBody* createStaticPlane(Vec3 normal={0,1,0}, f32 dist=0) {
        auto* b=createBody(CollisionShape::makePlane(normal,dist), true);
        b->position=normal*(-dist); return b;
    }

    void addConstraint(const Constraint& c) { _constraints.push_back(c); }

    // ── Step ──
    void step(f32 dt) {
        f32 remaining = dt;
        u32 steps = 0;
        while(remaining > EPSILON && steps < maxSubSteps) {
            f32 substep = fminf(remaining, fixedStep);
            _stepInternal(substep);
            remaining -= substep;
            steps++;
        }
    }

    // ── Raycast ──
    RayHit raycast(const Vec3& origin, const Vec3& dir, f32 maxDist=1000.0f) {
        RayHit best; best.distance = maxDist;
        Vec3 d = dir.normalized();

        for(auto* b : _bodies) {
            if(!b->active) continue;
            RayHit hit = _raycastBody(origin, d, *b);
            if(hit.hit && hit.distance < best.distance) {
                best = hit;
                best.bodyId = b->id;
            }
        }
        return best;
    }

    // ── Overlap ──
    std::vector<RigidBody*> overlapSphere(const Vec3& center, f32 radius) {
        std::vector<RigidBody*> result;
        AABB query = AABB::fromCenterSize(center, Vec3(radius*2));
        for(auto* b:_bodies) {
            if(b->aabb.intersects(query)) {
                f32 dist=(b->position-center).length();
                if(dist < radius + _getBodyRadius(*b))
                    result.push_back(b);
            }
        }
        return result;
    }

    const std::vector<RigidBody*>& getBodies() const { return _bodies; }

    void clear() {
        for(auto* b:_bodies) delete b;
        _bodies.clear();
        _constraints.clear();
    }

    ~PhysicsWorld() { clear(); }

private:
    std::vector<RigidBody*>  _bodies;
    std::vector<Constraint>  _constraints;
    std::vector<Contact>     _contacts;
    u32 _nextId = 1;
    f32 _accumulator = 0.0f;

    void _stepInternal(f32 dt) {
        // 1. Integrate forces
        for(auto* b:_bodies) {
            if(b->isStatic || !b->active || b->isSleeping) continue;
            _integrate(*b, dt);
        }

        // 2. Broad phase (AABB)
        _contacts.clear();
        for(u32 i=0;i<_bodies.size();i++) {
            for(u32 j=i+1;j<_bodies.size();j++) {
                auto* a=_bodies[i]; auto* b=_bodies[j];
                if(!a->active||!b->active) continue;
                if(a->isStatic&&b->isStatic) continue;
                a->updateAABB(); b->updateAABB();
                if(!a->aabb.intersects(b->aabb)) continue;

                // Narrow phase
                Contact c;
                if(_narrowPhase(*a,*b,c)) {
                    c.bodyA=a->id; c.bodyB=b->id;
                    _contacts.push_back(c);

                    if(a->isTrigger||b->isTrigger) {
                        if(onTriggerEnter) onTriggerEnter(*a,*b);
                    } else {
                        _resolveContact(*a,*b,c);
                        if(onCollision) onCollision(*a,*b,c);
                    }
                }
            }
        }

        // 3. Constraints
        for(auto& con:_constraints) _solveConstraint(con, dt);

        // 4. Sleep check
        for(auto* b:_bodies) {
            if(b->isStatic||!b->active) continue;
            f32 energy=b->velocity.lengthSq()+b->angularVelocity.lengthSq();
            if(energy < b->sleepThresh*b->sleepThresh) {
                b->sleepTimer+=dt;
                if(b->sleepTimer>1.0f) b->isSleeping=true;
            } else {
                b->sleepTimer=0; b->isSleeping=false;
            }
        }
    }

    void _integrate(RigidBody& b, f32 dt) {
        // Linear
        Vec3 accel = b.force * b.invMass;
        if(b.useGravity) accel = accel + gravity;
        b.velocity = b.velocity + accel * dt;
        b.velocity = b.velocity * (1.0f - b.linearDamp * dt);
        b.position = b.position + b.velocity * dt;

        // Angular
        Vec3 angAccel = {
            b.torque.x / b.inertiaTensor.x,
            b.torque.y / b.inertiaTensor.y,
            b.torque.z / b.inertiaTensor.z
        };
        b.angularVelocity = b.angularVelocity + angAccel * dt;
        b.angularVelocity = b.angularVelocity * (1.0f - b.angularDamp * dt);

        if(b.angularVelocity.lengthSq() > EPSILON) {
            f32 angle = b.angularVelocity.length() * dt;
            Quat dq   = Quat::fromAxisAngle(b.angularVelocity.normalized(), angle);
            b.rotation = (b.rotation * dq).normalized();
        }

        b.clearForces();
        b.updateAABB();
    }

    bool _narrowPhase(RigidBody& a, RigidBody& b, Contact& c) {
        if(a.shape.type==ShapeType::SPHERE && b.shape.type==ShapeType::SPHERE)
            return _sphereSphere(a,b,c);
        if(a.shape.type==ShapeType::SPHERE && b.shape.type==ShapeType::BOX)
            return _sphereBox(a,b,c);
        if(a.shape.type==ShapeType::BOX && b.shape.type==ShapeType::SPHERE)
            return _sphereBox(b,a,c);
        if(a.shape.type==ShapeType::SPHERE && b.shape.type==ShapeType::PLANE)
            return _spherePlane(a,b,c);
        if(a.shape.type==ShapeType::PLANE && b.shape.type==ShapeType::SPHERE)
            return _spherePlane(b,a,c);
        if(a.shape.type==ShapeType::BOX && b.shape.type==ShapeType::BOX)
            return _boxBox(a,b,c);
        return false;
    }

    bool _sphereSphere(RigidBody& a, RigidBody& b, Contact& c) {
        Vec3 diff = b.position - a.position;
        f32  dist = diff.length();
        f32  sum  = a.shape.sphere.radius + b.shape.sphere.radius;
        if(dist >= sum) return false;
        c.normal = dist>EPSILON ? diff/dist : Vec3::UP;
        c.depth  = sum - dist;
        c.point  = a.position + c.normal*(a.shape.sphere.radius - c.depth*0.5f);
        c.restitution = (a.restitution+b.restitution)*0.5f;
        c.friction    = (a.friction+b.friction)*0.5f;
        return true;
    }

    bool _sphereBox(RigidBody& sphere, RigidBody& box, Contact& c) {
        Vec3 closest = sphere.position;
        Vec3 h = box.shape.box.halfExtents;
        Vec3 bp= box.position;
        closest.x=fmaxf(bp.x-h.x, fminf(closest.x, bp.x+h.x));
        closest.y=fmaxf(bp.y-h.y, fminf(closest.y, bp.y+h.y));
        closest.z=fmaxf(bp.z-h.z, fminf(closest.z, bp.z+h.z));
        Vec3 diff=sphere.position-closest;
        f32 dist=diff.length();
        f32 r=sphere.shape.sphere.radius;
        if(dist>=r) return false;
        c.normal=dist>EPSILON?diff/dist:Vec3::UP;
        c.depth=r-dist;
        c.point=closest;
        c.restitution=(sphere.restitution+box.restitution)*0.5f;
        c.friction=(sphere.friction+box.friction)*0.5f;
        return true;
    }

    bool _spherePlane(RigidBody& sphere, RigidBody& plane, Contact& c) {
        Vec3 n=plane.shape.plane.normal;
        f32  d=plane.shape.plane.dist;
        f32  dist=sphere.position.dot(n)-d;
        f32  r=sphere.shape.sphere.radius;
        if(dist>=r) return false;
        c.normal=n; c.depth=r-dist;
        c.point=sphere.position-n*r;
        c.restitution=(sphere.restitution+plane.restitution)*0.5f;
        c.friction=(sphere.friction+plane.friction)*0.5f;
        return true;
    }

    bool _boxBox(RigidBody& a, RigidBody& b, Contact& c) {
        Vec3 diff=b.position-a.position;
        Vec3 overlap={
            a.shape.box.halfExtents.x+b.shape.box.halfExtents.x-fabsf(diff.x),
            a.shape.box.halfExtents.y+b.shape.box.halfExtents.y-fabsf(diff.y),
            a.shape.box.halfExtents.z+b.shape.box.halfExtents.z-fabsf(diff.z)
        };
        if(overlap.x<0||overlap.y<0||overlap.z<0) return false;
        if(overlap.x<overlap.y&&overlap.x<overlap.z) {
            c.normal={diff.x>0?1.0f:-1.0f,0,0}; c.depth=overlap.x;
        } else if(overlap.y<overlap.z) {
            c.normal={0,diff.y>0?1.0f:-1.0f,0}; c.depth=overlap.y;
        } else {
            c.normal={0,0,diff.z>0?1.0f:-1.0f}; c.depth=overlap.z;
        }
        c.point=a.position+c.normal*a.shape.box.halfExtents.x;
        c.restitution=(a.restitution+b.restitution)*0.5f;
        c.friction=(a.friction+b.friction)*0.5f;
        return true;
    }

    void _resolveContact(RigidBody& a, RigidBody& b, const Contact& c) {
        Vec3 rv = b.velocity - a.velocity;
        f32  vn = rv.dot(c.normal);
        if(vn > 0) return;

        // Impulse
        f32 e   = c.restitution;
        f32 j   = -(1+e)*vn / (a.invMass+b.invMass);
        Vec3 imp = c.normal * j;
        if(!a.isStatic) a.velocity = a.velocity - imp*a.invMass;
        if(!b.isStatic) b.velocity = b.velocity + imp*b.invMass;

        // Friction
        Vec3 t = (rv - c.normal*vn).normalized();
        f32  jt= -rv.dot(t)/(a.invMass+b.invMass);
        Vec3 fi = fabsf(jt)<j*c.friction ? t*jt : t*(-j*c.friction);
        if(!a.isStatic) a.velocity = a.velocity - fi*a.invMass;
        if(!b.isStatic) b.velocity = b.velocity + fi*b.invMass;

        // Positional correction
        f32  pct  = 0.2f;
        f32  slop = 0.01f;
        Vec3 corr = c.normal*(fmaxf(c.depth-slop,0)/(a.invMass+b.invMass)*pct);
        if(!a.isStatic) a.position = a.position - corr*a.invMass;
        if(!b.isStatic) b.position = b.position + corr*b.invMass;
    }

    void _solveConstraint(const Constraint& con, f32 dt) {
        RigidBody* a=nullptr, *b=nullptr;
        for(auto* bd:_bodies){
            if(bd->id==con.bodyA) a=bd;
            if(bd->id==con.bodyB) b=bd;
        }
        if(!a||!b) return;

        if(con.type==Constraint::DISTANCE) {
            Vec3 diff=b->position-a->position;
            f32  dist=diff.length();
            f32  err =dist-con.maxDist;
            if(fabsf(err)<EPSILON) return;
            Vec3 n=diff/dist;
            Vec3 impulse=n*(err*con.stiffness*0.5f);
            if(!a->isStatic) a->velocity=a->velocity+impulse*a->invMass;
            if(!b->isStatic) b->velocity=b->velocity-impulse*b->invMass;
        }
    }

    RayHit _raycastBody(const Vec3& o, const Vec3& d, const RigidBody& b) {
        RayHit hit;
        if(b.shape.type==ShapeType::SPHERE) {
            Vec3 oc=o-b.position;
            f32 a2=d.dot(d), bv=2*oc.dot(d), c2=oc.dot(oc)-b.shape.sphere.radius*b.shape.sphere.radius;
            f32 disc=bv*bv-4*a2*c2;
            if(disc<0) return hit;
            f32 t=(-bv-sqrtf(disc))/(2*a2);
            if(t<0) return hit;
            hit.hit=true; hit.distance=t;
            hit.point=o+d*t;
            hit.normal=(hit.point-b.position).normalized();
        } else if(b.shape.type==ShapeType::BOX||b.shape.type==ShapeType::PLANE) {
            f32 tmin, tmax;
            if(b.aabb.intersectsRay(o,d,tmin,tmax)){
                hit.hit=true; hit.distance=tmin;
                hit.point=o+d*tmin;
                hit.normal=Vec3::UP;
            }
        }
        return hit;
    }

    f32 _getBodyRadius(const RigidBody& b) {
        switch(b.shape.type){
            case ShapeType::SPHERE: return b.shape.sphere.radius;
            case ShapeType::BOX: return b.shape.box.halfExtents.length();
            case ShapeType::CAPSULE: return b.shape.capsule.radius+b.shape.capsule.height*0.5f;
            default: return 1.0f;
        }
    }
};

} // namespace Nova
