#pragma once
#include "../Nova.h"
#include "Vec3.h"
#include "Mat4.h"

namespace Nova {

// ═══════════════════════════════════════════════
//  AABB — Axis-Aligned Bounding Box
//  للكشف عن التقاطع والـ Culling
// ═══════════════════════════════════════════════

struct AABB {
    Vec3 min = { 1e30f,  1e30f,  1e30f};
    Vec3 max = {-1e30f, -1e30f, -1e30f};

    AABB() = default;
    AABB(const Vec3& mn, const Vec3& mx) : min(mn), max(mx) {}

    static AABB fromCenterSize(const Vec3& center, const Vec3& size) {
        Vec3 h = size * 0.5f;
        return {center - h, center + h};
    }

    Vec3 center()  const { return (min+max)*0.5f; }
    Vec3 size()    const { return max-min; }
    Vec3 extents() const { return size()*0.5f; }
    f32  volume()  const { Vec3 s=size(); return s.x*s.y*s.z; }

    bool contains(const Vec3& p) const {
        return p.x>=min.x && p.x<=max.x &&
               p.y>=min.y && p.y<=max.y &&
               p.z>=min.z && p.z<=max.z;
    }

    bool intersects(const AABB& o) const {
        return min.x<=o.max.x && max.x>=o.min.x &&
               min.y<=o.max.y && max.y>=o.min.y &&
               min.z<=o.max.z && max.z>=o.min.z;
    }

    bool intersectsRay(const Vec3& origin, const Vec3& dir, f32& tmin, f32& tmax) const {
        Vec3 inv = {1.0f/dir.x, 1.0f/dir.y, 1.0f/dir.z};
        Vec3 t0 = (min - origin) * inv;
        Vec3 t1 = (max - origin) * inv;
        Vec3 tsmall = {fminf(t0.x,t1.x), fminf(t0.y,t1.y), fminf(t0.z,t1.z)};
        Vec3 tbig   = {fmaxf(t0.x,t1.x), fmaxf(t0.y,t1.y), fmaxf(t0.z,t1.z)};
        tmin = fmaxf(tsmall.maxComponent(), 0.0f);
        tmax = tbig.minComponent();
        return tmin <= tmax;
    }

    void expand(const Vec3& p) {
        min = {fminf(min.x,p.x), fminf(min.y,p.y), fminf(min.z,p.z)};
        max = {fmaxf(max.x,p.x), fmaxf(max.y,p.y), fmaxf(max.z,p.z)};
    }

    void expand(const AABB& o) { expand(o.min); expand(o.max); }

    AABB transformed(const Mat4& m) const {
        Vec3 corners[8] = {
            {min.x,min.y,min.z},{max.x,min.y,min.z},
            {min.x,max.y,min.z},{max.x,max.y,min.z},
            {min.x,min.y,max.z},{max.x,min.y,max.z},
            {min.x,max.y,max.z},{max.x,max.y,max.z}
        };
        AABB r;
        for(auto& c:corners) r.expand(m.transformPoint(c));
        return r;
    }

    static AABB fromMesh(const Mesh& mesh) {
        AABB r;
        for(u32 i=0;i<mesh.vertCount;i++) r.expand(mesh.vertices[i].position);
        return r;
    }
};

// ═══════════════════════════════════════════════
//  FRUSTUM — لاستبعاد الكائنات خارج الكاميرا
// ═══════════════════════════════════════════════
struct Plane {
    Vec3 normal;
    f32  distance;

    f32 distanceTo(const Vec3& p) const {
        return normal.dot(p) + distance;
    }
};

struct Frustum {
    Plane planes[6]; // Left, Right, Bottom, Top, Near, Far

    static Frustum fromMatrix(const Mat4& vp) {
        Frustum f;
        // Gribb/Hartmann method
        // Left
        f.planes[0].normal = {vp(3,0)+vp(0,0), vp(3,1)+vp(0,1), vp(3,2)+vp(0,2)};
        f.planes[0].distance = vp(3,3)+vp(0,3);
        // Right
        f.planes[1].normal = {vp(3,0)-vp(0,0), vp(3,1)-vp(0,1), vp(3,2)-vp(0,2)};
        f.planes[1].distance = vp(3,3)-vp(0,3);
        // Bottom
        f.planes[2].normal = {vp(3,0)+vp(1,0), vp(3,1)+vp(1,1), vp(3,2)+vp(1,2)};
        f.planes[2].distance = vp(3,3)+vp(1,3);
        // Top
        f.planes[3].normal = {vp(3,0)-vp(1,0), vp(3,1)-vp(1,1), vp(3,2)-vp(1,2)};
        f.planes[3].distance = vp(3,3)-vp(1,3);
        // Near
        f.planes[4].normal = {vp(3,0)+vp(2,0), vp(3,1)+vp(2,1), vp(3,2)+vp(2,2)};
        f.planes[4].distance = vp(3,3)+vp(2,3);
        // Far
        f.planes[5].normal = {vp(3,0)-vp(2,0), vp(3,1)-vp(2,1), vp(3,2)-vp(2,2)};
        f.planes[5].distance = vp(3,3)-vp(2,3);

        for(auto& p:f.planes) {
            f32 l=p.normal.length();
            p.normal=p.normal/l; p.distance/=l;
        }
        return f;
    }

    bool containsPoint(const Vec3& p) const {
        for(auto& pl:planes) if(pl.distanceTo(p)<0) return false;
        return true;
    }

    bool containsAABB(const AABB& box) const {
        for(auto& pl:planes) {
            Vec3 pv = {
                pl.normal.x>0?box.max.x:box.min.x,
                pl.normal.y>0?box.max.y:box.min.y,
                pl.normal.z>0?box.max.z:box.min.z
            };
            if(pl.distanceTo(pv)<0) return false;
        }
        return true;
    }
};

} // namespace Nova
