#pragma once
#include "../Nova.h"
#include "Vec3.h"
#include "Quat.h"
#include "Mat4.h"

namespace Nova {

// ═══════════════════════════════════════════════
//  Transform — موقع + دوران + حجم
// ═══════════════════════════════════════════════

struct Transform {
    Vec3 position = Vec3::ZERO;
    Quat rotation = Quat::IDENTITY;
    Vec3 scale    = Vec3::ONE;

    // ── Matrix ──
    Mat4 toMatrix() const {
        Mat4 T = Mat4::translation(position);
        Mat4 R = rotation.toMat4();
        Mat4 S = Mat4::scale(scale);
        return T * R * S;
    }

    // ── Directions ──
    Vec3 forward() const { return rotation.forward(); }
    Vec3 right()   const { return rotation.right(); }
    Vec3 up()      const { return rotation.up(); }

    // ── Look At ──
    void lookAt(const Vec3& target, const Vec3& up=Vec3::UP) {
        Vec3 dir = (target - position).normalized();
        if(dir.lengthSq() < EPSILON) return;
        Vec3 right = dir.cross(up).normalized();
        Vec3 u2    = right.cross(dir);
        Mat4 m; m.m[0]=right.x;m.m[1]=right.y;m.m[2]=right.z;
        m.m[4]=u2.x;m.m[5]=u2.y;m.m[6]=u2.z;
        m.m[8]=-dir.x;m.m[9]=-dir.y;m.m[10]=-dir.z;m.m[15]=1;
        rotation = Quat::fromMat4(m);
    }

    // ── Lerp ──
    static Transform lerp(const Transform& a, const Transform& b, f32 t) {
        Transform r;
        r.position = a.position.lerp(b.position, t);
        r.rotation = Quat::slerp(a.rotation, b.rotation, t);
        r.scale    = a.scale.lerp(b.scale, t);
        return r;
    }

    // ── Combine ──
    Transform operator*(const Transform& child) const {
        Transform r;
        r.scale    = Vec3{scale.x*child.scale.x, scale.y*child.scale.y, scale.z*child.scale.z};
        r.rotation = rotation * child.rotation;
        r.position = position + rotation * (scale * child.position);
        return r;
    }

    Vec3 transformPoint(const Vec3& p) const {
        return position + rotation * (scale * p);
    }

    Vec3 transformDir(const Vec3& d) const {
        return rotation * d;
    }
};

} // namespace Nova
