#pragma once
#include "../Nova.h"

namespace Nova {

// ── Vec2 ──
struct Vec2 {
    f32 x=0, y=0;
    constexpr Vec2(){}
    constexpr Vec2(f32 v):x(v),y(v){}
    constexpr Vec2(f32 x,f32 y):x(x),y(y){}

    static const Vec2 ZERO, ONE;

    Vec2 operator+(const Vec2& o) const { return {x+o.x,y+o.y}; }
    Vec2 operator-(const Vec2& o) const { return {x-o.x,y-o.y}; }
    Vec2 operator*(f32 s)         const { return {x*s,y*s}; }
    Vec2 operator/(f32 s)         const { return {x/s,y/s}; }
    Vec2 operator-()              const { return {-x,-y}; }
    Vec2& operator+=(const Vec2& o){ x+=o.x;y+=o.y; return *this; }
    Vec2& operator-=(const Vec2& o){ x-=o.x;y-=o.y; return *this; }
    Vec2& operator*=(f32 s){ x*=s;y*=s; return *this; }
    bool  operator==(const Vec2& o) const { return fabsf(x-o.x)<1e-6f&&fabsf(y-o.y)<1e-6f; }

    f32  dot(const Vec2& o)  const { return x*o.x+y*o.y; }
    f32  cross(const Vec2& o)const { return x*o.y-y*o.x; }
    f32  length()            const { return sqrtf(x*x+y*y); }
    f32  lengthSq()          const { return x*x+y*y; }
    f32  distance(const Vec2& o) const { return (*this-o).length(); }
    Vec2 normalized() const { f32 l=length(); return l>1e-6f?(*this/l):ZERO; }
    Vec2 lerp(const Vec2& to,f32 t) const { return {x+(to.x-x)*t,y+(to.y-y)*t}; }
    Vec2 perp()   const { return {-y,x}; }
    f32  angle()  const { return atan2f(y,x); }
    Vec2 rotated(f32 a) const { f32 c=cosf(a),s=sinf(a); return {x*c-y*s,x*s+y*c}; }
    Vec2 limit(f32 maxLen) const {
        f32 l=length(); return l>maxLen?(*this*(maxLen/l)):*this;
    }
};
inline const Vec2 Vec2::ZERO={0,0};
inline const Vec2 Vec2::ONE ={1,1};

// ── Vec4 ──
struct alignas(16) Vec4 {
    f32 x=0,y=0,z=0,w=0;
    constexpr Vec4(){}
    constexpr Vec4(f32 v):x(v),y(v),z(v),w(v){}
    constexpr Vec4(f32 x,f32 y,f32 z,f32 w=1.f):x(x),y(y),z(z),w(w){}

    static const Vec4 ZERO,ONE,WHITE,BLACK,RED,GREEN,BLUE,TRANSPARENT;

    Vec4 operator+(const Vec4& o) const { return {x+o.x,y+o.y,z+o.z,w+o.w}; }
    Vec4 operator-(const Vec4& o) const { return {x-o.x,y-o.y,z-o.z,w-o.w}; }
    Vec4 operator*(const Vec4& o) const { return {x*o.x,y*o.y,z*o.z,w*o.w}; }
    Vec4 operator*(f32 s)         const { return {x*s,y*s,z*s,w*s}; }
    Vec4 operator-()              const { return {-x,-y,-z,-w}; }
    Vec4& operator+=(const Vec4& o){ x+=o.x;y+=o.y;z+=o.z;w+=o.w; return *this; }
    Vec4& operator*=(f32 s){ x*=s;y*=s;z*=s;w*=s; return *this; }
    f32& operator[](int i)       { return (&x)[i]; }
    f32  operator[](int i) const { return (&x)[i]; }

    f32  dot(const Vec4& o) const { return x*o.x+y*o.y+z*o.z+w*o.w; }
    f32  length()           const { return sqrtf(x*x+y*y+z*z+w*w); }
    Vec4 normalized()       const { f32 l=length(); return l>1e-6f?(*this*(1.f/l)):ZERO; }
    Vec4 lerp(const Vec4& to,f32 t) const {
        return {x+(to.x-x)*t,y+(to.y-y)*t,z+(to.z-z)*t,w+(to.w-w)*t};
    }
    f32  r() const { return x; }
    f32  g() const { return y; }
    f32  b() const { return z; }
    f32  a() const { return w; }

    // Include Vec3 header before using this
    // Vec3 rgb() const { return {x,y,z}; }

    Vec4 withAlpha(f32 a) const { return {x,y,z,a}; }

    static Vec4 fromHex(u32 hex) {
        return {((hex>>16)&0xFF)/255.f,((hex>>8)&0xFF)/255.f,
                ((hex)&0xFF)/255.f,((hex>>24)&0xFF)/255.f};
    }
    u32 toHex() const {
        return ((u32)(w*255)<<24)|((u32)(x*255)<<16)|((u32)(y*255)<<8)|(u32)(z*255);
    }
};
inline const Vec4 Vec4::ZERO        = {0,0,0,0};
inline const Vec4 Vec4::ONE         = {1,1,1,1};
inline const Vec4 Vec4::WHITE       = {1,1,1,1};
inline const Vec4 Vec4::BLACK       = {0,0,0,1};
inline const Vec4 Vec4::RED         = {1,0,0,1};
inline const Vec4 Vec4::GREEN       = {0,1,0,1};
inline const Vec4 Vec4::BLUE        = {0,0,1,1};
inline const Vec4 Vec4::TRANSPARENT = {0,0,0,0};

} // namespace Nova
