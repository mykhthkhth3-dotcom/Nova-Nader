#pragma once
#include "../Nova.h"
#include "Vec3.h"
#include "Mat4.h"

namespace Nova {

// ══════════════════════════════════
//  Quaternion
// ══════════════════════════════════
struct Quat {
    f32 x=0,y=0,z=0,w=1;
    constexpr Quat(){}
    constexpr Quat(f32 x,f32 y,f32 z,f32 w):x(x),y(y),z(z),w(w){}
    static const Quat IDENTITY;

    static Quat fromAxisAngle(const Vec3& axis,f32 angle){
        f32 s=sinf(angle*.5f); Vec3 n=axis.normalized();
        return {n.x*s,n.y*s,n.z*s,cosf(angle*.5f)};
    }
    static Quat fromEuler(f32 pitch,f32 yaw,f32 roll){
        f32 cp=cosf(pitch*.5f),sp=sinf(pitch*.5f);
        f32 cy=cosf(yaw*.5f),sy=sinf(yaw*.5f);
        f32 cr=cosf(roll*.5f),sr=sinf(roll*.5f);
        return {sr*cp*cy-cr*sp*sy,cr*sp*cy+sr*cp*sy,cr*cp*sy-sr*sp*cy,cr*cp*cy+sr*sp*sy};
    }
    Quat operator*(const Quat& o) const {
        return {w*o.x+x*o.w+y*o.z-z*o.y,
                w*o.y-x*o.z+y*o.w+z*o.x,
                w*o.z+x*o.y-y*o.x+z*o.w,
                w*o.w-x*o.x-y*o.y-z*o.z};
    }
    Vec3 operator*(const Vec3& v) const {
        Vec3 qv={x,y,z};
        Vec3 uv=qv.cross(v), uuv=qv.cross(uv);
        return v+(uv*w+uuv)*2.f;
    }
    Quat operator*(f32 s) const { return {x*s,y*s,z*s,w*s}; }
    Quat operator+(const Quat& o) const { return {x+o.x,y+o.y,z+o.z,w+o.w}; }
    Quat operator-(const Quat& o) const { return {x-o.x,y-o.y,z-o.z,w-o.w}; }
    f32  length()     const { return sqrtf(x*x+y*y+z*z+w*w); }
    Quat normalized() const { f32 l=length(); return l>EPSILON?(*this*(1.f/l)):IDENTITY; }
    Quat conjugate()  const { return {-x,-y,-z,w}; }
    Quat inverse()    const { return conjugate().normalized(); }
    static Quat slerp(const Quat& a,const Quat& b,f32 t){
        f32 dot=a.x*b.x+a.y*b.y+a.z*b.z+a.w*b.w;
        Quat bb=b; if(dot<0){dot=-dot;bb=bb*(-1);}
        if(dot>0.9995f) return (a+(bb-a)*t).normalized();
        f32 th=acosf(dot),s0=cosf(th*t)-dot*sinf(th*t)/sinf(th),s1=sinf(th*t)/sinf(th);
        return (a*s0+bb*s1).normalized();
    }
    Mat4 toMat4() const {
        Mat4 m; f32 xx=x*x,yy=y*y,zz=z*z,xy=x*y,xz=x*z,yz=y*z,wx=w*x,wy=w*y,wz=w*z;
        m.m[0]=1-2*(yy+zz);m.m[4]=2*(xy-wz);m.m[8]=2*(xz+wy);
        m.m[1]=2*(xy+wz);m.m[5]=1-2*(xx+zz);m.m[9]=2*(yz-wx);
        m.m[2]=2*(xz-wy);m.m[6]=2*(yz+wx);m.m[10]=1-2*(xx+yy);m.m[15]=1;
        return m;
    }
    Vec3 forward() const { return *this*Vec3::FORWARD; }
    Vec3 right()   const { return *this*Vec3::RIGHT; }
    Vec3 up()      const { return *this*Vec3::UP; }
};
inline const Quat Quat::IDENTITY={0,0,0,1};

// ══════════════════════════════════
//  Transform
// ══════════════════════════════════
struct Transform {
    Vec3 position=Vec3::ZERO;
    Quat rotation=Quat::IDENTITY;
    Vec3 scale   =Vec3::ONE;

    Mat4 toMatrix() const {
        return Mat4::translation(position)*rotation.toMat4()*Mat4::scale(scale);
    }
    Vec3 forward() const { return rotation.forward(); }
    Vec3 right()   const { return rotation.right(); }
    Vec3 up()      const { return rotation.up(); }
    void lookAt(const Vec3& target,const Vec3& up=Vec3::UP){
        Vec3 dir=(target-position).normalized();
        if(dir.lengthSq()<EPSILON) return;
        Vec3 r=dir.cross(up).normalized(), u=r.cross(dir);
        Mat4 m; m.m[0]=r.x;m.m[1]=r.y;m.m[2]=r.z;
        m.m[4]=u.x;m.m[5]=u.y;m.m[6]=u.z;
        m.m[8]=-dir.x;m.m[9]=-dir.y;m.m[10]=-dir.z;m.m[15]=1;
        rotation=Quat::fromAxisAngle(Vec3::UP,0); // placeholder
    }
    static Transform lerp(const Transform& a,const Transform& b,f32 t){
        Transform r;
        r.position=a.position.lerp(b.position,t);
        r.rotation=Quat::slerp(a.rotation,b.rotation,t);
        r.scale=a.scale.lerp(b.scale,t);
        return r;
    }
    Transform operator*(const Transform& child) const {
        Transform r;
        r.scale={scale.x*child.scale.x,scale.y*child.scale.y,scale.z*child.scale.z};
        r.rotation=rotation*child.rotation;
        r.position=position+rotation*(scale*child.position);
        return r;
    }
    Vec3 transformPoint(const Vec3& p) const { return position+rotation*(scale*p); }
    Vec3 transformDir(const Vec3& d)   const { return rotation*d; }
};

// ══════════════════════════════════
//  AABB
// ══════════════════════════════════
struct AABB {
    Vec3 min={ 1e30f, 1e30f, 1e30f};
    Vec3 max={-1e30f,-1e30f,-1e30f};
    AABB()=default;
    AABB(const Vec3& mn,const Vec3& mx):min(mn),max(mx){}
    static AABB fromCenterSize(const Vec3& c,const Vec3& s){
        Vec3 h=s*0.5f; return {c-h,c+h};
    }
    Vec3 center()  const { return (min+max)*0.5f; }
    Vec3 size()    const { return max-min; }
    Vec3 extents() const { return size()*0.5f; }
    bool contains(const Vec3& p) const {
        return p.x>=min.x&&p.x<=max.x&&p.y>=min.y&&p.y<=max.y&&p.z>=min.z&&p.z<=max.z;
    }
    bool intersects(const AABB& o) const {
        return min.x<=o.max.x&&max.x>=o.min.x&&min.y<=o.max.y&&
               max.y>=o.min.y&&min.z<=o.max.z&&max.z>=o.min.z;
    }
    bool intersectsRay(const Vec3& o,const Vec3& d,f32& tmin,f32& tmax) const {
        Vec3 inv={1.f/d.x,1.f/d.y,1.f/d.z};
        Vec3 t0=(min-o)*inv, t1=(max-o)*inv;
        Vec3 ts={fminf(t0.x,t1.x),fminf(t0.y,t1.y),fminf(t0.z,t1.z)};
        Vec3 tb={fmaxf(t0.x,t1.x),fmaxf(t0.y,t1.y),fmaxf(t0.z,t1.z)};
        tmin=fmaxf(ts.maxComponent(),0.f); tmax=tb.minComponent();
        return tmin<=tmax;
    }
    void expand(const Vec3& p){
        min={fminf(min.x,p.x),fminf(min.y,p.y),fminf(min.z,p.z)};
        max={fmaxf(max.x,p.x),fmaxf(max.y,p.y),fmaxf(max.z,p.z)};
    }
    void expand(const AABB& o){ expand(o.min);expand(o.max); }
};

// ══════════════════════════════════
//  Noise
// ══════════════════════════════════
class Noise {
public:
    explicit Noise(u64 seed=0){ _seed(seed); }
    f32 perlin(f32 x,f32 y) const {
        i32 xi=((i32)floorf(x))&255, yi=((i32)floorf(y))&255;
        f32 xf=x-floorf(x), yf=y-floorf(y);
        f32 u=_fade(xf), v=_fade(yf);
        i32 aa=_p[_p[xi]+yi],ab=_p[_p[xi]+yi+1],ba=_p[_p[xi+1]+yi],bb=_p[_p[xi+1]+yi+1];
        return _lerp(v,_lerp(u,_grad(aa,xf,yf),_grad(ba,xf-1,yf)),
                       _lerp(u,_grad(ab,xf,yf-1),_grad(bb,xf-1,yf-1)))*0.5f+0.5f;
    }
    f32 fbm(f32 x,f32 y,u32 octaves=6,f32 lac=2.f,f32 gain=0.5f) const {
        f32 val=0,amp=0.5f,freq=1.f,max=0;
        for(u32 i=0;i<octaves;i++){
            val+=perlin(x*freq,y*freq)*amp; max+=amp; amp*=gain; freq*=lac;
        }
        return val/max;
    }
    f32 ridged(f32 x,f32 y,u32 oct=6) const {
        f32 val=0,amp=0.5f,freq=1.f;
        for(u32 i=0;i<oct;i++){
            f32 n=perlin(x*freq,y*freq); n=1.f-fabsf(n*2-1); n*=n;
            val+=n*amp; amp*=0.5f; freq*=2.f;
        }
        return val;
    }
private:
    u8 _p[512];
    void _seed(u64 seed){
        for(u32 i=0;i<256;i++) _p[i]=(u8)i;
        u64 s=seed^0x9e3779b97f4a7c15ULL;
        for(i32 i=255;i>0;i--){
            s=s*6364136223846793005ULL+1442695040888963407ULL;
            u32 j=(u32)(s>>33)%(i+1);
            u8 tmp=_p[i];_p[i]=_p[j];_p[j]=tmp;
        }
        for(u32 i=0;i<256;i++) _p[256+i]=_p[i];
    }
    static f32 _fade(f32 t){ return t*t*t*(t*(t*6-15)+10); }
    static f32 _lerp(f32 t,f32 a,f32 b){ return a+(b-a)*t; }
    static f32 _grad(i32 hash,f32 x,f32 y){
        switch(hash&3){case 0:return x+y;case 1:return -x+y;case 2:return x-y;default:return -x-y;}
    }
};

} // namespace Nova
