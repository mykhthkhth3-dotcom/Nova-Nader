#pragma once
#include "../Nova.h"

namespace Nova {

struct alignas(16) Vec3 {
    f32 x, y, z, _pad = 0;

    constexpr Vec3() : x(0), y(0), z(0), _pad(0) {}
    constexpr Vec3(f32 v) : x(v), y(v), z(v), _pad(0) {}
    constexpr Vec3(f32 x, f32 y, f32 z) : x(x), y(y), z(z), _pad(0) {}

    static const Vec3 ZERO, ONE, UP, DOWN, LEFT, RIGHT, FORWARD, BACK;

    Vec3 operator+(const Vec3& o) const { return {x+o.x,y+o.y,z+o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x-o.x,y-o.y,z-o.z}; }
    Vec3 operator*(const Vec3& o) const { return {x*o.x,y*o.y,z*o.z}; }
    Vec3 operator*(f32 s)         const { return {x*s,y*s,z*s}; }
    Vec3 operator/(f32 s)         const { f32 i=1.f/s; return {x*i,y*i,z*i}; }
    Vec3 operator-()              const { return {-x,-y,-z}; }
    Vec3& operator+=(const Vec3& o) { x+=o.x;y+=o.y;z+=o.z; return *this; }
    Vec3& operator-=(const Vec3& o) { x-=o.x;y-=o.y;z-=o.z; return *this; }
    Vec3& operator*=(f32 s) { x*=s;y*=s;z*=s; return *this; }
    Vec3& operator/=(f32 s) { f32 i=1.f/s; x*=i;y*=i;z*=i; return *this; }
    bool  operator==(const Vec3& o) const { return fabsf(x-o.x)<EPSILON&&fabsf(y-o.y)<EPSILON&&fabsf(z-o.z)<EPSILON; }
    bool  operator!=(const Vec3& o) const { return !(*this==o); }
    f32&  operator[](int i)       { return (&x)[i]; }
    f32   operator[](int i) const { return (&x)[i]; }

    f32  dot(const Vec3& o)   const { return x*o.x+y*o.y+z*o.z; }
    f32  length()             const { return sqrtf(x*x+y*y+z*z); }
    f32  lengthSq()           const { return x*x+y*y+z*z; }
    f32  distance(const Vec3& o)   const { return (*this-o).length(); }
    f32  distanceSq(const Vec3& o) const { return (*this-o).lengthSq(); }

    Vec3 cross(const Vec3& o) const {
        return {y*o.z-z*o.y, z*o.x-x*o.z, x*o.y-y*o.x};
    }
    Vec3 normalized() const {
        f32 l=length(); return l<EPSILON?ZERO:(*this/l);
    }
    Vec3& normalize() {
        f32 l=length(); if(l>EPSILON) *this/=l; return *this;
    }
    Vec3 lerp(const Vec3& to, f32 t) const {
        return {x+(to.x-x)*t,y+(to.y-y)*t,z+(to.z-z)*t};
    }
    Vec3 reflect(const Vec3& n)  const { return *this-n*(2.f*dot(n)); }
    Vec3 project(const Vec3& on) const { return on*(dot(on)/on.lengthSq()); }
    Vec3 abs()   const { return {fabsf(x),fabsf(y),fabsf(z)}; }
    Vec3 clamp(f32 mn, f32 mx) const {
        return {fmaxf(mn,fminf(mx,x)),fmaxf(mn,fminf(mx,y)),fmaxf(mn,fminf(mx,z))};
    }
    f32 maxComponent() const { return fmaxf(x,fmaxf(y,z)); }
    f32 minComponent() const { return fminf(x,fminf(y,z)); }
    bool isZero()   const { return lengthSq()<EPSILON*EPSILON; }
    bool isFinite() const { return std::isfinite(x)&&std::isfinite(y)&&std::isfinite(z); }
    f32 angleTo(const Vec3& o) const {
        f32 d=normalized().dot(o.normalized());
        return acosf(fmaxf(-1.f,fminf(1.f,d)));
    }
    f32 r() const { return x; }
    f32 g() const { return y; }
    f32 b() const { return z; }
};

inline Vec3 operator*(f32 s, const Vec3& v) { return v*s; }

inline const Vec3 Vec3::ZERO    = {0,0,0};
inline const Vec3 Vec3::ONE     = {1,1,1};
inline const Vec3 Vec3::UP      = {0,1,0};
inline const Vec3 Vec3::DOWN    = {0,-1,0};
inline const Vec3 Vec3::LEFT    = {-1,0,0};
inline const Vec3 Vec3::RIGHT   = {1,0,0};
inline const Vec3 Vec3::FORWARD = {0,0,-1};
inline const Vec3 Vec3::BACK    = {0,0,1};

} // namespace Nova
