#pragma once
#include "../Nova.h"
#include "Vec3.h"
#include "Vec2Vec4.h"

namespace Nova {

struct alignas(16) Mat4 {
    f32 m[16] = {};

    static const Mat4 IDENTITY;
    static const Mat4 ZERO_MAT;

    Mat4() { *this = IDENTITY; }

    f32& operator()(int r,int c)       { return m[c*4+r]; }
    f32  operator()(int r,int c) const { return m[c*4+r]; }

    Mat4 operator*(const Mat4& b) const {
        Mat4 r; r.m[0]=r.m[5]=r.m[10]=r.m[15]=0;
        for(int i=0;i<4;i++) for(int j=0;j<4;j++){
            float s=0; for(int k=0;k<4;k++) s+=(*this)(i,k)*b(k,j);
            r(i,j)=s;
        }
        return r;
    }
    Mat4& operator*=(const Mat4& o){ *this=*this*o; return *this; }

    Vec4 operator*(const Vec4& v) const {
        return {m[0]*v.x+m[4]*v.y+m[8]*v.z+m[12]*v.w,
                m[1]*v.x+m[5]*v.y+m[9]*v.z+m[13]*v.w,
                m[2]*v.x+m[6]*v.y+m[10]*v.z+m[14]*v.w,
                m[3]*v.x+m[7]*v.y+m[11]*v.z+m[15]*v.w};
    }

    static Mat4 translation(const Vec3& t) {
        Mat4 r; r.m[12]=t.x;r.m[13]=t.y;r.m[14]=t.z; return r;
    }
    static Mat4 scale(const Vec3& s) {
        Mat4 r; r.m[0]=s.x;r.m[5]=s.y;r.m[10]=s.z; return r;
    }
    static Mat4 rotationX(f32 a) {
        Mat4 r; f32 c=cosf(a),s=sinf(a);
        r.m[5]=c;r.m[6]=s;r.m[9]=-s;r.m[10]=c; return r;
    }
    static Mat4 rotationY(f32 a) {
        Mat4 r; f32 c=cosf(a),s=sinf(a);
        r.m[0]=c;r.m[2]=-s;r.m[8]=s;r.m[10]=c; return r;
    }
    static Mat4 rotationZ(f32 a) {
        Mat4 r; f32 c=cosf(a),s=sinf(a);
        r.m[0]=c;r.m[1]=s;r.m[4]=-s;r.m[5]=c; return r;
    }
    static Mat4 lookAt(const Vec3& eye,const Vec3& center,const Vec3& up) {
        Vec3 f=(center-eye).normalized();
        Vec3 s=f.cross(up).normalized();
        Vec3 u=s.cross(f);
        Mat4 r;
        r.m[0]=s.x;r.m[4]=s.y;r.m[8]=s.z;r.m[12]=-s.dot(eye);
        r.m[1]=u.x;r.m[5]=u.y;r.m[9]=u.z;r.m[13]=-u.dot(eye);
        r.m[2]=-f.x;r.m[6]=-f.y;r.m[10]=-f.z;r.m[14]=f.dot(eye);
        r.m[3]=r.m[7]=r.m[11]=0;r.m[15]=1; return r;
    }
    static Mat4 perspective(f32 fov,f32 aspect,f32 near,f32 far) {
        f32 t=tanf(fov*0.5f); Mat4 r;
        r.m[0]=1.f/(aspect*t);r.m[5]=1.f/t;
        r.m[10]=-(far+near)/(far-near);r.m[11]=-1.f;
        r.m[14]=-(2.f*far*near)/(far-near);r.m[15]=0; return r;
    }
    static Mat4 orthographic(f32 l,f32 r2,f32 b,f32 t,f32 n,f32 f) {
        Mat4 res;
        res.m[0]=2/(r2-l);res.m[5]=2/(t-b);res.m[10]=-2/(f-n);
        res.m[12]=-(r2+l)/(r2-l);res.m[13]=-(t+b)/(t-b);res.m[14]=-(f+n)/(f-n);
        return res;
    }

    Mat4 transposed() const {
        Mat4 r; for(int i=0;i<4;i++) for(int j=0;j<4;j++) r(i,j)=(*this)(j,i);
        return r;
    }
    Vec3 transformPoint(const Vec3& p) const {
        Vec4 v=*this*Vec4(p.x,p.y,p.z,1.f);
        return {v.x/v.w,v.y/v.w,v.z/v.w};
    }
    Vec3 transformDir(const Vec3& d) const {
        Vec4 v=*this*Vec4(d.x,d.y,d.z,0.f);
        return {v.x,v.y,v.z};
    }
    Vec3 getTranslation() const { return {m[12],m[13],m[14]}; }
};

inline const Mat4 Mat4::IDENTITY = [](){
    Mat4 m; m.m[0]=m.m[5]=m.m[10]=m.m[15]=1.f; return m;
}();
inline const Mat4 Mat4::ZERO_MAT = [](){
    Mat4 m; memset(m.m,0,sizeof(m.m)); return m;
}();

} // namespace Nova
