#pragma once
#include "../Nova.h"

namespace Nova {

// ═══════════════════════════════════════════════
//  NOISE — ضوضاء إجرائية للتضاريس والأشكال
//  Perlin + Simplex + FBM + Voronoi
// ═══════════════════════════════════════════════

class Noise {
public:
    explicit Noise(u64 seed = 0) { _seed(seed); }

    // ── Perlin Noise 2D ──
    f32 perlin(f32 x, f32 y) const {
        i32 xi = (i32)floorf(x) & 255;
        i32 yi = (i32)floorf(y) & 255;
        f32 xf = x - floorf(x);
        f32 yf = y - floorf(y);
        f32 u  = _fade(xf);
        f32 v  = _fade(yf);

        i32 aa = _p[_p[xi]+yi];
        i32 ab = _p[_p[xi]+yi+1];
        i32 ba = _p[_p[xi+1]+yi];
        i32 bb = _p[_p[xi+1]+yi+1];

        return _lerp(v,
            _lerp(u, _grad(aa,xf,yf),     _grad(ba,xf-1,yf)),
            _lerp(u, _grad(ab,xf,yf-1),   _grad(bb,xf-1,yf-1))
        ) * 0.5f + 0.5f;
    }

    // ── Perlin 3D ──
    f32 perlin3(f32 x, f32 y, f32 z) const {
        i32 xi=((i32)floorf(x))&255, yi=((i32)floorf(y))&255, zi=((i32)floorf(z))&255;
        f32 xf=x-floorf(x), yf=y-floorf(y), zf=z-floorf(z);
        f32 u=_fade(xf), v=_fade(yf), w=_fade(zf);

        i32 aaa=_p[_p[_p[xi]+yi]+zi];
        i32 aba=_p[_p[_p[xi]+yi+1]+zi];
        i32 aab=_p[_p[_p[xi]+yi]+zi+1];
        i32 abb=_p[_p[_p[xi]+yi+1]+zi+1];
        i32 baa=_p[_p[_p[xi+1]+yi]+zi];
        i32 bba=_p[_p[_p[xi+1]+yi+1]+zi];
        i32 bab=_p[_p[_p[xi+1]+yi]+zi+1];
        i32 bbb=_p[_p[_p[xi+1]+yi+1]+zi+1];

        return _lerp(w,
            _lerp(v,
                _lerp(u,_grad3(aaa,xf,yf,zf),  _grad3(baa,xf-1,yf,zf)),
                _lerp(u,_grad3(aba,xf,yf-1,zf), _grad3(bba,xf-1,yf-1,zf))),
            _lerp(v,
                _lerp(u,_grad3(aab,xf,yf,zf-1), _grad3(bab,xf-1,yf,zf-1)),
                _lerp(u,_grad3(abb,xf,yf-1,zf-1),_grad3(bbb,xf-1,yf-1,zf-1)))
        ) * 0.5f + 0.5f;
    }

    // ── Fractal Brownian Motion ──
    f32 fbm(f32 x, f32 y, u32 octaves=6, f32 lacunarity=2.0f, f32 gain=0.5f) const {
        f32 val=0, amp=0.5f, freq=1.0f, max=0;
        for(u32 i=0; i<octaves; i++) {
            val += perlin(x*freq, y*freq) * amp;
            max += amp;
            amp  *= gain;
            freq *= lacunarity;
        }
        return val / max;
    }

    // ── Ridged Noise (للجبال الحادة) ──
    f32 ridged(f32 x, f32 y, u32 octaves=6) const {
        f32 val=0, amp=0.5f, freq=1.0f;
        for(u32 i=0; i<octaves; i++) {
            f32 n = perlin(x*freq, y*freq);
            n = 1.0f - fabsf(n*2-1);
            n *= n;
            val += n * amp;
            amp  *= 0.5f;
            freq *= 2.0f;
        }
        return val;
    }

    // ── Voronoi (للخلايا) ──
    f32 voronoi(f32 x, f32 y) const {
        i32 xi=(i32)floorf(x), yi=(i32)floorf(y);
        f32 minDist = 1e10f;
        for(i32 dy=-1; dy<=1; dy++) for(i32 dx=-1; dx<=1; dx++) {
            i32 cx=xi+dx, cy=yi+dy;
            f32 px = cx + _hash2f(cx, cy);
            f32 py = cy + _hash2f(cy, cx);
            f32 d  = sqrtf((x-px)*(x-px)+(y-py)*(y-py));
            minDist = fminf(minDist, d);
        }
        return minDist;
    }

    // ── Domain Warp ──
    f32 warp(f32 x, f32 y) const {
        f32 qx = fbm(x,       y,       4);
        f32 qy = fbm(x+5.2f,  y+1.3f,  4);
        return fbm(x+4*qx, y+4*qy, 6);
    }

private:
    u8 _p[512];

    void _seed(u64 seed) {
        for(u32 i=0;i<256;i++) _p[i]=(u8)i;
        // Fisher-Yates shuffle بـ seed
        u64 s=seed^0x9e3779b97f4a7c15ULL;
        for(i32 i=255;i>0;i--) {
            s=s*6364136223846793005ULL+1442695040888963407ULL;
            u32 j=(u32)(s>>33)%(i+1);
            u8 tmp=_p[i]; _p[i]=_p[j]; _p[j]=tmp;
        }
        for(u32 i=0;i<256;i++) _p[256+i]=_p[i];
    }

    static f32 _fade(f32 t) { return t*t*t*(t*(t*6-15)+10); }
    static f32 _lerp(f32 t, f32 a, f32 b) { return a+(b-a)*t; }

    static f32 _grad(i32 hash, f32 x, f32 y) {
        switch(hash&3) {
            case 0: return  x+y;
            case 1: return -x+y;
            case 2: return  x-y;
            case 3: return -x-y;
        }
        return 0;
    }

    static f32 _grad3(i32 hash, f32 x, f32 y, f32 z) {
        i32 h=hash&15;
        f32 u=h<8?x:y, v=h<4?y:(h==12||h==14?x:z);
        return ((h&1)?-u:u)+((h&2)?-v:v);
    }

    f32 _hash2f(i32 x, i32 y) const {
        u32 h=(u32)(x*127+y*311);
        h^=h>>16; h*=0x45d9f3b; h^=h>>16;
        return (f32)(h&0xFFFF)/65536.0f;
    }
};

// ── Helper math functions (للـ Nova namespace) ──
inline u32 clamp3(u32 v, u32 mn, u32 mx) { return v<mn?mn:(v>mx?mx:v); }
inline i32 clampi(i32 v, i32 mn, i32 mx) { return v<mn?mn:(v>mx?mx:v); }
inline f32 clampf(f32 v, f32 mn, f32 mx) { return v<mn?mn:(v>mx?mx:v); }

} // namespace Nova
