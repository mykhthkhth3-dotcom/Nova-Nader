#pragma once
#include "../Nova.h"

namespace Nova {

// ══════════════════════════════════
//  BASE ALLOCATOR
// ══════════════════════════════════
class Allocator {
public:
    virtual ~Allocator() = default;
    virtual void* alloc(usize size, usize align=16) = 0;
    virtual void  free(void* ptr) = 0;
    virtual void  reset() {}
    usize getTotalAllocated() const { return _totalAllocated; }
    usize getAllocationCount() const { return _allocationCount; }
protected:
    usize _totalAllocated  = 0;
    usize _allocationCount = 0;
};

// ══════════════════════════════════
//  LINEAR ALLOCATOR (Arena)
//  الأسرع — يحذف الكل دفعة واحدة
// ══════════════════════════════════
class LinearAllocator : public Allocator {
public:
    explicit LinearAllocator(usize capacity) {
        _buf = new byte[capacity];
        _cap = capacity;
        _cur = 0;
    }
    ~LinearAllocator() { delete[] _buf; }

    void* alloc(usize size, usize align=16) override {
        usize aligned = (_cur + align-1) & ~(align-1);
        if(aligned + size > _cap) return nullptr;
        void* ptr = _buf + aligned;
        _cur = aligned + size;
        _totalAllocated += size;
        _allocationCount++;
        return ptr;
    }
    void free(void*) override {} // لا يفعل شيئاً
    void reset() override { _cur=0; _totalAllocated=0; _allocationCount=0; }
    usize getUsed()      const { return _cur; }
    usize getCapacity()  const { return _cap; }
    f32   getUsagePct()  const { return (f32)_cur/_cap*100.f; }

private:
    byte*  _buf = nullptr;
    usize  _cap = 0;
    usize  _cur = 0;
};

// ══════════════════════════════════
//  POOL ALLOCATOR
//  لكائنات بحجم ثابت — O(1) alloc/free
// ══════════════════════════════════
class PoolAllocator : public Allocator {
public:
    PoolAllocator(usize objectSize, u32 count) {
        _objSize = (objectSize < sizeof(void*)) ? sizeof(void*) : objectSize;
        _count   = count;
        _buf     = new byte[_objSize * count];
        _head    = nullptr;
        // بناء قائمة الكتل الحرة
        for(u32 i=0;i<count;i++){
            void** slot = reinterpret_cast<void**>(_buf + i*_objSize);
            *slot = _head;
            _head = slot;
        }
    }
    ~PoolAllocator() { delete[] _buf; }

    void* alloc(usize, usize=16) override {
        if(!_head) return nullptr;
        void* ptr = _head;
        _head = *reinterpret_cast<void**>(_head);
        _totalAllocated += _objSize;
        _allocationCount++;
        return ptr;
    }
    void free(void* ptr) override {
        if(!ptr) return;
        *reinterpret_cast<void**>(ptr) = _head;
        _head = ptr;
        _totalAllocated -= _objSize;
        _allocationCount--;
    }
    void reset() override {
        _head=nullptr;
        for(u32 i=0;i<_count;i++){
            void** slot=reinterpret_cast<void**>(_buf+i*_objSize);
            *slot=_head; _head=slot;
        }
        _totalAllocated=0; _allocationCount=0;
    }
    u32   getCapacity() const { return _count; }
    u32   getUsed()     const { return (u32)_allocationCount; }

private:
    byte*  _buf     = nullptr;
    void*  _head    = nullptr;
    usize  _objSize = 0;
    u32    _count   = 0;
};

// ══════════════════════════════════
//  STACK ALLOCATOR
//  يدعم تحرير LIFO فقط
// ══════════════════════════════════
class StackAllocator : public Allocator {
public:
    explicit StackAllocator(usize capacity) {
        _buf = new byte[capacity];
        _cap = capacity;
        _top = 0;
    }
    ~StackAllocator() { delete[] _buf; }

    using Marker = usize;

    void* alloc(usize size, usize align=16) override {
        usize aligned = (_top+align-1)&~(align-1);
        if(aligned+size > _cap) return nullptr;
        void* ptr = _buf+aligned;
        _top = aligned+size;
        _totalAllocated+=size; _allocationCount++;
        return ptr;
    }
    void free(void*) override {} // استخدم freeToMarker

    Marker getMarker() const { return _top; }
    void freeToMarker(Marker m) { _top = m; }
    void reset() override { _top=0; _totalAllocated=0; _allocationCount=0; }

private:
    byte*  _buf = nullptr;
    usize  _cap = 0;
    usize  _top = 0;
};

} // namespace Nova
