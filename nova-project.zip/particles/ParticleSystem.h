#pragma once
#include "../Nova.h"
#include "../math/Vec3.h"
#include "../math/Vec4.h"
#include "../renderer/PixelProcessor.h"
#include <vector>
#include <functional>

namespace Nova {

// ═══════════════════════════════════════════════════════
//  PARTICLE SYSTEM — نظام جسيمات كامل
//  انفجارات، دخان، نار، مطر، ثلج، نجوم
//  كل شيء يُحسب بالكود على الـ CPU
// ═══════════════════════════════════════════════════════

struct Particle {
    Vec3  position;
    Vec3  velocity;
    Vec3  acceleration;
    Vec4  color;
    Vec4  colorEnd;
    f32   size;
    f32   sizeEnd;
    f32   life;       // 0→1 (1=born, 0=dead)
    f32   maxLife;
    f32   rotation;
    f32   rotSpeed;
    bool  alive = false;
};

struct ParticleEmitter {
    // ── Emission ──
    Vec3  position     = Vec3::ZERO;
    Vec3  direction    = Vec3::UP;
    f32   spread       = 0.5f;      // cone angle radians
    f32   emitRate     = 50.0f;     // particles/second
    u32   burstCount   = 0;         // 0=continuous
    bool  looping      = true;
    bool  active       = true;

    // ── Initial Particle ──
    f32   speedMin     = 2.0f;
    f32   speedMax     = 5.0f;
    f32   lifeMin      = 0.5f;
    f32   lifeMax      = 2.0f;
    f32   sizeMin      = 0.05f;
    f32   sizeMax      = 0.15f;
    Vec4  colorStart   = {1.0f, 0.5f, 0.1f, 1.0f};
    Vec4  colorEnd     = {0.2f, 0.0f, 0.0f, 0.0f};
    Vec3  gravity      = {0, -2.0f, 0};
    f32   drag         = 0.1f;

    // ── Custom update per particle ──
    std::function<void(Particle&, f32)> customUpdate;

private:
    f32 _emitAccum = 0.0f;

public:
    void tick(f32 dt, std::vector<Particle>& pool) {
        if(!active) return;
        if(burstCount > 0) {
            _emitBurst(burstCount, pool);
            burstCount = 0;
        } else if(looping) {
            _emitAccum += emitRate * dt;
            while(_emitAccum >= 1.0f) {
                _emitOne(pool);
                _emitAccum -= 1.0f;
            }
        }
    }

    void burst(u32 count) { burstCount = count; }

private:
    void _emitBurst(u32 n, std::vector<Particle>& pool) {
        for(u32 i=0;i<n;i++) _emitOne(pool);
    }

    void _emitOne(std::vector<Particle>& pool) {
        // Find dead slot
        for(auto& p : pool) {
            if(!p.alive) { _init(p); return; }
        }
        // Pool full — skip
    }

    void _init(Particle& p) {
        p.alive    = true;
        p.position = position;
        p.maxLife  = lifeMin + (f32)rand()/RAND_MAX*(lifeMax-lifeMin);
        p.life     = 1.0f;
        p.size     = sizeMin + (f32)rand()/RAND_MAX*(sizeMax-sizeMin);
        p.sizeEnd  = p.size * 0.1f;
        p.color    = colorStart;
        p.colorEnd = colorEnd;
        p.rotation = (f32)rand()/RAND_MAX * TWO_PI;
        p.rotSpeed = ((f32)rand()/RAND_MAX - 0.5f) * 4.0f;

        // Direction with spread
        Vec3 dir = direction.normalized();
        Vec3 right = dir.cross(Vec3::UP);
        if(right.lengthSq() < EPSILON) right = dir.cross(Vec3::RIGHT);
        right = right.normalized();
        Vec3 up2 = dir.cross(right);

        f32 theta = (f32)rand()/RAND_MAX * TWO_PI;
        f32 r     = (f32)rand()/RAND_MAX * spread;
        Vec3 spd  = (dir + right*cosf(theta)*r + up2*sinf(theta)*r).normalized();
        f32 speed = speedMin + (f32)rand()/RAND_MAX*(speedMax-speedMin);
        p.velocity     = spd * speed;
        p.acceleration = gravity;
    }
};

// ═══════════════════════════════════════════════════════
//  PARTICLE SYSTEM
// ═══════════════════════════════════════════════════════
class ParticleSystem {
public:
    explicit ParticleSystem(u32 maxParticles=10000) {
        _particles.resize(maxParticles);
    }

    // ── Add Emitter ──
    ParticleEmitter* addEmitter() {
        _emitters.push_back(new ParticleEmitter());
        return _emitters.back();
    }

    // ── Presets ──
    ParticleEmitter* createExplosion(const Vec3& pos, f32 scale=1.0f) {
        auto* e = addEmitter();
        e->position   = pos;
        e->direction  = Vec3::UP;
        e->spread     = PI;
        e->speedMin   = 3.0f*scale;
        e->speedMax   = 10.0f*scale;
        e->lifeMin    = 0.3f;
        e->lifeMax    = 1.2f;
        e->sizeMin    = 0.1f*scale;
        e->sizeMax    = 0.4f*scale;
        e->colorStart = {1.0f, 0.6f, 0.1f, 1.0f};
        e->colorEnd   = {0.3f, 0.0f, 0.0f, 0.0f};
        e->gravity    = {0,-5,0};
        e->looping    = false;
        e->burst(150);
        return e;
    }

    ParticleEmitter* createFire(const Vec3& pos) {
        auto* e = addEmitter();
        e->position   = pos;
        e->direction  = Vec3::UP;
        e->spread     = 0.3f;
        e->speedMin   = 1.5f;
        e->speedMax   = 3.5f;
        e->lifeMin    = 0.4f;
        e->lifeMax    = 0.9f;
        e->sizeMin    = 0.08f;
        e->sizeMax    = 0.20f;
        e->colorStart = {1.0f, 0.7f, 0.1f, 1.0f};
        e->colorEnd   = {0.6f, 0.1f, 0.0f, 0.0f};
        e->gravity    = {0, 0.5f, 0};
        e->emitRate   = 80.0f;
        e->drag       = 0.2f;
        return e;
    }

    ParticleEmitter* createSmoke(const Vec3& pos) {
        auto* e = addEmitter();
        e->position   = pos;
        e->direction  = Vec3::UP;
        e->spread     = 0.4f;
        e->speedMin   = 0.5f;
        e->speedMax   = 1.5f;
        e->lifeMin    = 1.5f;
        e->lifeMax    = 3.0f;
        e->sizeMin    = 0.15f;
        e->sizeMax    = 0.5f;
        e->colorStart = {0.4f, 0.4f, 0.4f, 0.6f};
        e->colorEnd   = {0.6f, 0.6f, 0.6f, 0.0f};
        e->gravity    = {0, 0.2f, 0};
        e->emitRate   = 20.0f;
        e->drag       = 0.5f;
        return e;
    }

    ParticleEmitter* createRain(const Vec3& center, f32 radius=20.0f) {
        auto* e = addEmitter();
        e->position   = center + Vec3(0, 30, 0);
        e->direction  = {0,-1,0};
        e->spread     = 0.1f;
        e->speedMin   = 12.0f;
        e->speedMax   = 18.0f;
        e->lifeMin    = 1.5f;
        e->lifeMax    = 2.5f;
        e->sizeMin    = 0.01f;
        e->sizeMax    = 0.02f;
        e->colorStart = {0.6f, 0.7f, 1.0f, 0.8f};
        e->colorEnd   = {0.6f, 0.7f, 1.0f, 0.0f};
        e->gravity    = {0,-15,0};
        e->emitRate   = 300.0f;
        return e;
    }

    ParticleEmitter* createEngine(const Vec3& pos, const Vec3& dir) {
        auto* e = addEmitter();
        e->position   = pos;
        e->direction  = -dir;
        e->spread     = 0.15f;
        e->speedMin   = 8.0f;
        e->speedMax   = 15.0f;
        e->lifeMin    = 0.2f;
        e->lifeMax    = 0.5f;
        e->sizeMin    = 0.05f;
        e->sizeMax    = 0.12f;
        e->colorStart = {0.8f, 0.9f, 1.0f, 1.0f};
        e->colorEnd   = {0.2f, 0.4f, 1.0f, 0.0f};
        e->gravity    = Vec3::ZERO;
        e->emitRate   = 150.0f;
        return e;
    }

    // ── Update ──
    void update(f32 dt) {
        // Update emitters
        for(auto* e:_emitters) e->tick(dt, _particles);

        // Update particles
        _aliveCount = 0;
        for(auto& p:_particles) {
            if(!p.alive) continue;
            p.life -= dt / p.maxLife;
            if(p.life <= 0) { p.alive=false; continue; }
            _aliveCount++;

            f32 t = 1.0f - p.life; // 0=new, 1=old

            // Physics
            p.velocity     = p.velocity + p.acceleration * dt;
            p.velocity     = p.velocity * (1.0f - p.drag);  // No drag member but use default
            p.position     = p.position + p.velocity * dt;
            p.rotation    += p.rotSpeed * dt;

            // Interpolate
            p.color = p.color.lerp(p.colorEnd, t*dt*3.0f);
            p.size  = p.size + (p.sizeEnd - p.size) * t * dt * 3.0f;

            // Custom
            for(auto* e:_emitters) if(e->customUpdate) e->customUpdate(p, dt);
        }
    }

    // ── Render (به PixelProcessor) ──
    void render(Framebuffer& fb, const Mat4& viewProj) {
        for(auto& p:_particles) {
            if(!p.alive) continue;

            // Project to screen
            Vec4 clip = viewProj * Vec4(p.position, 1.0f);
            if(clip.w < 0.001f) continue;

            f32 ndcX = clip.x / clip.w;
            f32 ndcY = clip.y / clip.w;
            i32 sx   = (i32)((ndcX*0.5f+0.5f) * fb.width);
            i32 sy   = (i32)((1-(ndcY*0.5f+0.5f)) * fb.height);

            // Size in pixels (perspective)
            f32 dist  = clip.w;
            i32 pxSize= (i32)(p.size / dist * fb.height * 1.5f);
            if(pxSize < 1) pxSize=1;

            Pixel px = Pixel::fromFloat(p.color.x, p.color.y, p.color.z, p.color.w);

            // Draw circle
            for(i32 dy=-pxSize; dy<=pxSize; dy++) {
                for(i32 dx=-pxSize; dx<=pxSize; dx++) {
                    if(dx*dx+dy*dy > pxSize*pxSize) continue;
                    i32 fx=sx+dx, fy=sy+dy;
                    if(fx>=0&&fx<(i32)fb.width&&fy>=0&&fy<(i32)fb.height) {
                        // Alpha blend
                        Pixel& dest = fb.pixels[fy*fb.width+fx];
                        f32 a=p.color.w;
                        dest.r=(u8)(dest.r*(1-a)+px.r*a);
                        dest.g=(u8)(dest.g*(1-a)+px.g*a);
                        dest.b=(u8)(dest.b*(1-a)+px.b*a);
                    }
                }
            }
        }
    }

    u32 getAliveCount() const { return _aliveCount; }
    u32 getCapacity()   const { return (u32)_particles.size(); }

    void removeEmitter(ParticleEmitter* e) {
        for(u32 i=0;i<_emitters.size();i++) {
            if(_emitters[i]==e){ delete _emitters[i]; _emitters.erase(_emitters.begin()+i); return; }
        }
    }

    ~ParticleSystem() { for(auto* e:_emitters) delete e; }

private:
    std::vector<Particle>        _particles;
    std::vector<ParticleEmitter*>_emitters;
    u32 _aliveCount = 0;
};

} // namespace Nova
