#pragma once
#include "../Nova.h"
#include "../math/Vec3.h"
#include <vector>
#include <string>
#include <functional>

// Android audio
#ifdef NOVA_PLATFORM_ANDROID
    #include <SLES/OpenSLES.h>
    #include <SLES/OpenSLES_Android.h>
#endif

namespace Nova {

// ═══════════════════════════════════════════════════════
//  NOVA AUDIO ENGINE — الجلسة الخامسة
//  محرك صوت كامل: 3D + Doppler + Reverb + Mixing
//  يعمل على Android عبر OpenSL ES
// ═══════════════════════════════════════════════════════

// ── PCM Sound Buffer ──
struct SoundBuffer {
    u32    id       = 0;
    i16*   data     = nullptr;
    u32    samples  = 0;
    u32    channels = 1;
    u32    sampleRate = 44100;
    f32    duration = 0.0f;

    void destroy() { delete[] data; data=nullptr; samples=0; }
    ~SoundBuffer() { destroy(); }

    // Generate sine wave (للاختبار)
    static SoundBuffer* generateSine(f32 freq=440.0f, f32 dur=1.0f,
                                      u32 sr=44100, f32 amp=0.5f) {
        auto* b = new SoundBuffer();
        b->sampleRate = sr;
        b->channels   = 1;
        b->samples    = (u32)(dur * sr);
        b->duration   = dur;
        b->data       = new i16[b->samples];
        for(u32 i=0;i<b->samples;i++) {
            f32 t = (f32)i / sr;
            b->data[i] = (i16)(sinf(TWO_PI*freq*t) * amp * 32767);
        }
        return b;
    }

    // Generate engine rumble
    static SoundBuffer* generateEngine(f32 rpm=3000.0f, f32 dur=2.0f, u32 sr=44100) {
        auto* b = new SoundBuffer();
        b->sampleRate = sr; b->channels=1;
        b->samples    = (u32)(dur*sr);
        b->duration   = dur;
        b->data       = new i16[b->samples];
        f32 baseFreq  = rpm / 60.0f * 2.0f;
        for(u32 i=0;i<b->samples;i++) {
            f32 t = (f32)i/sr;
            f32 s = 0;
            // Harmonics
            s += sinf(TWO_PI*baseFreq*t)       * 0.5f;
            s += sinf(TWO_PI*baseFreq*2.0f*t)  * 0.3f;
            s += sinf(TWO_PI*baseFreq*3.0f*t)  * 0.15f;
            s += sinf(TWO_PI*baseFreq*4.0f*t)  * 0.05f;
            // Noise for roughness
            s += ((f32)rand()/RAND_MAX*2-1)*0.1f;
            b->data[i] = (i16)(s * 0.4f * 32767);
        }
        return b;
    }

    // Generate explosion
    static SoundBuffer* generateExplosion(f32 dur=1.5f, u32 sr=44100) {
        auto* b = new SoundBuffer();
        b->sampleRate=sr; b->channels=1;
        b->samples=(u32)(dur*sr); b->duration=dur;
        b->data=new i16[b->samples];
        for(u32 i=0;i<b->samples;i++) {
            f32 t=1.0f-(f32)i/b->samples;
            f32 env=expf(-t*3.0f+3.0f)*t;
            f32 noise=((f32)rand()/RAND_MAX*2-1);
            f32 boom=sinf(TWO_PI*60.0f*(f32)i/sr)*expf(-(f32)i/sr*8);
            b->data[i]=(i16)((noise*0.6f+boom*0.4f)*env*32767);
        }
        return b;
    }

    // Generate gunshot
    static SoundBuffer* generateGunshot(u32 sr=44100) {
        auto* b=new SoundBuffer();
        b->sampleRate=sr; b->channels=1;
        b->samples=sr/4; b->duration=0.25f;
        b->data=new i16[b->samples];
        for(u32 i=0;i<b->samples;i++){
            f32 t=(f32)i/b->samples;
            f32 env=expf(-t*20);
            f32 s=((f32)rand()/RAND_MAX*2-1)*env;
            s+=sinf(TWO_PI*200*(f32)i/sr)*expf(-t*30)*0.5f;
            b->data[i]=(i16)(s*32767);
        }
        return b;
    }

    // Generate missile whoosh
    static SoundBuffer* generateWhoosh(f32 dur=2.0f, u32 sr=44100) {
        auto* b=new SoundBuffer();
        b->sampleRate=sr; b->channels=1;
        b->samples=(u32)(dur*sr); b->duration=dur;
        b->data=new i16[b->samples];
        for(u32 i=0;i<b->samples;i++){
            f32 t=(f32)i/b->samples;
            f32 freq=800.0f*(1.0f-t*0.7f);
            f32 env=sinf(t*PI)*0.8f+0.2f;
            f32 s=sinf(TWO_PI*freq*(f32)i/sr)*env;
            s+=((f32)rand()/RAND_MAX*2-1)*0.2f*env;
            b->data[i]=(i16)(s*0.6f*32767);
        }
        return b;
    }
};

// ── Audio Source (صوت في الفضاء) ──
struct AudioSource {
    u32         id       = 0;
    SoundBuffer* buffer  = nullptr;
    Vec3        position = Vec3::ZERO;
    Vec3        velocity = Vec3::ZERO;
    f32         volume   = 1.0f;
    f32         pitch    = 1.0f;
    f32         minDist  = 1.0f;
    f32         maxDist  = 100.0f;
    bool        looping  = false;
    bool        playing  = false;
    bool        is3D     = true;
    bool        paused   = false;

    // Playback state
    u32         cursor   = 0;
    f32         dopplerShift = 1.0f;

    // Rolloff
    enum Rolloff { LINEAR, INVERSE, EXPONENTIAL };
    Rolloff rolloff = INVERSE;

    f32 calcAttenuation(f32 dist) const {
        if(dist <= minDist) return 1.0f;
        if(dist >= maxDist) return 0.0f;
        switch(rolloff){
            case LINEAR:     return 1.0f-(dist-minDist)/(maxDist-minDist);
            case INVERSE:    return minDist/dist;
            case EXPONENTIAL:return powf(minDist/dist, 2.0f);
        }
        return 1.0f;
    }
};

// ── Reverb Zone ──
struct ReverbZone {
    Vec3  position;
    f32   radius     = 20.0f;
    f32   roomSize   = 0.5f;
    f32   damping    = 0.5f;
    f32   wetMix     = 0.3f;
    f32   dryMix     = 0.7f;
};

// ═══════════════════════════════════════════════════════
//  AUDIO ENGINE
// ═══════════════════════════════════════════════════════
class AudioEngine {
public:
    static constexpr u32 SAMPLE_RATE    = 44100;
    static constexpr u32 BUFFER_SIZE    = 1024;
    static constexpr u32 MAX_SOURCES    = 64;
    static constexpr f32 SPEED_OF_SOUND = 343.0f;

    Vec3 listenerPos = Vec3::ZERO;
    Vec3 listenerVel = Vec3::ZERO;
    Vec3 listenerFwd = Vec3::FORWARD;
    Vec3 listenerUp  = Vec3::UP;
    f32  masterVolume = 1.0f;
    f32  musicVolume  = 0.7f;
    f32  sfxVolume    = 1.0f;
    bool dopplerEnabled = true;

    // ── Init ──
    bool init() {
        _mixBuffer = new f32[BUFFER_SIZE * 2]; // stereo
        _outBuffer = new i16[BUFFER_SIZE * 2];
        _reverbBuffer = new f32[BUFFER_SIZE * 2];
        memset(_mixBuffer, 0, sizeof(f32)*BUFFER_SIZE*2);
        _initPlatform();
        return true;
    }

    void shutdown() {
        _shutdownPlatform();
        delete[] _mixBuffer;
        delete[] _outBuffer;
        delete[] _reverbBuffer;
        for(auto* s : _sources) delete s;
        for(auto& b : _buffers) delete b.second;
    }

    // ── Buffer Management ──
    SoundBuffer* loadBuffer(const std::string& name, SoundBuffer* buf) {
        buf->id = _nextBufId++;
        _buffers[name] = buf;
        return buf;
    }

    SoundBuffer* getBuffer(const std::string& name) {
        auto it = _buffers.find(name);
        return it != _buffers.end() ? it->second : nullptr;
    }

    // ── Source Management ──
    AudioSource* createSource() {
        if(_sources.size() >= MAX_SOURCES) return nullptr;
        auto* s = new AudioSource();
        s->id = _nextSrcId++;
        _sources.push_back(s);
        return s;
    }

    void destroySource(AudioSource* s) {
        for(u32 i=0;i<_sources.size();i++) {
            if(_sources[i]==s){ _sources.erase(_sources.begin()+i); delete s; return; }
        }
    }

    // ── Playback ──
    void play(AudioSource* s) {
        if(!s) return;
        s->playing = true;
        s->paused  = false;
        if(!s->looping) s->cursor = 0;
    }

    void stop(AudioSource* s) {
        if(!s) return;
        s->playing = false;
        s->cursor  = 0;
    }

    void pause(AudioSource* s) { if(s) s->paused=true; }
    void resume(AudioSource* s) { if(s) s->paused=false; }

    AudioSource* playOneShot(SoundBuffer* buf, const Vec3& pos={},
                              f32 vol=1.0f, f32 pitch=1.0f) {
        auto* s = createSource();
        if(!s) return nullptr;
        s->buffer   = buf;
        s->position = pos;
        s->volume   = vol;
        s->pitch    = pitch;
        s->looping  = false;
        s->is3D     = true;
        play(s);
        return s;
    }

    // ── Listener ──
    void setListener(const Vec3& pos, const Vec3& vel,
                     const Vec3& fwd, const Vec3& up) {
        listenerPos = pos;
        listenerVel = vel;
        listenerFwd = fwd;
        listenerUp  = up;
    }

    // ── Reverb ──
    void addReverbZone(const ReverbZone& z) { _reverbZones.push_back(z); }

    // ── Main mix (called per audio frame) ──
    void mixFrame() {
        memset(_mixBuffer, 0, sizeof(f32)*BUFFER_SIZE*2);

        for(auto* src : _sources) {
            if(!src->playing || src->paused || !src->buffer) continue;
            _mixSource(src);
        }

        // Apply reverb
        _applyReverb();

        // Apply master volume + limiter
        for(u32 i=0;i<BUFFER_SIZE*2;i++) {
            f32 s = _mixBuffer[i] * masterVolume;
            // Soft clipping
            s = s / (1.0f + fabsf(s));
            _outBuffer[i] = (i16)(s * 32767.0f);
        }

        _submitAudio(_outBuffer, BUFFER_SIZE);

        // Cleanup one-shots
        for(u32 i=0;i<_sources.size();) {
            auto* s=_sources[i];
            if(!s->looping && !s->playing) {
                delete s; _sources.erase(_sources.begin()+i);
            } else i++;
        }
    }

    u32 getActiveSourceCount() const {
        u32 n=0;
        for(auto* s:_sources) if(s->playing) n++;
        return n;
    }

private:
    f32*   _mixBuffer    = nullptr;
    i16*   _outBuffer    = nullptr;
    f32*   _reverbBuffer = nullptr;
    f32    _reverbLine[4096] = {};
    u32    _reverbIdx   = 0;

    std::vector<AudioSource*>          _sources;
    std::vector<ReverbZone>            _reverbZones;
    std::unordered_map<std::string, SoundBuffer*> _buffers;
    u32 _nextSrcId = 1;
    u32 _nextBufId = 1;

    void _mixSource(AudioSource* src) {
        SoundBuffer* buf = src->buffer;
        f32 vol = src->volume * sfxVolume;

        // 3D processing
        f32 leftVol=vol, rightVol=vol;
        if(src->is3D) {
            Vec3 toSrc = src->position - listenerPos;
            f32  dist  = toSrc.length();

            // Attenuation
            f32 att = src->calcAttenuation(dist);
            vol *= att;

            // Panning
            if(dist > EPSILON) {
                Vec3 dir    = toSrc / dist;
                Vec3 right  = listenerFwd.cross(listenerUp).normalized();
                f32  pan    = dir.dot(right); // -1=left, +1=right
                leftVol     = vol * (1.0f - fmaxf(0,pan));
                rightVol    = vol * (1.0f + fminf(0,pan));
            }

            // Doppler
            if(dopplerEnabled) {
                Vec3 relVel    = src->velocity - listenerVel;
                Vec3 toSrcDir  = dist>EPSILON ? toSrc/dist : Vec3::ZERO;
                f32  relSpeed  = relVel.dot(toSrcDir);
                src->dopplerShift = SPEED_OF_SOUND / fmaxf(1.0f, SPEED_OF_SOUND - relSpeed);
                src->pitch = src->dopplerShift;
            }
        }

        // Mix samples with pitch shift
        f32 pitchStep = src->pitch;
        f32 readPos   = (f32)src->cursor;

        for(u32 i=0;i<BUFFER_SIZE;i++) {
            u32 idx = (u32)readPos;
            if(idx >= buf->samples) {
                if(src->looping) { readPos -= buf->samples; idx=0; }
                else { src->playing=false; break; }
            }

            // Linear interpolation for pitch
            f32 frac = readPos - idx;
            u32 next = (idx+1) % buf->samples;
            f32 sample = (buf->data[idx]*(1-frac) + buf->data[next]*frac) / 32768.0f;

            _mixBuffer[i*2]   += sample * leftVol;
            _mixBuffer[i*2+1] += sample * rightVol;

            readPos += pitchStep;
        }
        src->cursor = (u32)readPos;
    }

    void _applyReverb() {
        // Simple Schroeder reverb
        const u32 delays[] = {1557, 1617, 1491, 1422};
        f32 wet = 0.0f;

        // Find active reverb zone
        for(auto& z : _reverbZones) {
            f32 dist = (listenerPos - z.position).length();
            if(dist < z.radius) {
                f32 blend = 1.0f - dist/z.radius;
                wet = z.wetMix * blend;
                break;
            }
        }
        if(wet < 0.001f) return;

        for(u32 i=0;i<BUFFER_SIZE;i++) {
            f32 in = (_mixBuffer[i*2] + _mixBuffer[i*2+1]) * 0.5f;
            u32 idx = (_reverbIdx + delays[0]) % 4096;
            f32 echo = _reverbLine[idx] * 0.7f;
            _reverbLine[_reverbIdx] = in + echo * 0.5f;
            _reverbIdx = (_reverbIdx + 1) % 4096;

            f32 rev = echo * wet;
            _mixBuffer[i*2]   = _mixBuffer[i*2]   * (1-wet) + rev;
            _mixBuffer[i*2+1] = _mixBuffer[i*2+1] * (1-wet) + rev;
        }
    }

    // ── Platform Audio ──
#ifdef NOVA_PLATFORM_ANDROID
    SLObjectItf _engineObj   = nullptr;
    SLEngineItf _engine      = nullptr;
    SLObjectItf _mixObj      = nullptr;
    SLObjectItf _playerObj   = nullptr;
    SLPlayItf   _player      = nullptr;
    SLAndroidSimpleBufferQueueItf _bufQueue = nullptr;

    void _initPlatform() {
        slCreateEngine(&_engineObj, 0, nullptr, 0, nullptr, nullptr);
        (*_engineObj)->Realize(_engineObj, SL_BOOLEAN_FALSE);
        (*_engineObj)->GetInterface(_engineObj, SL_IID_ENGINE, &_engine);

        const SLInterfaceID ids[]={SL_IID_VOLUME};
        const SLboolean req[]={SL_BOOLEAN_FALSE};
        (*_engine)->CreateOutputMix(_engine, &_mixObj, 1, ids, req);
        (*_mixObj)->Realize(_mixObj, SL_BOOLEAN_FALSE);

        SLDataLocator_AndroidSimpleBufferQueue bq={SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE,2};
        SLDataFormat_PCM fmt={SL_DATAFORMAT_PCM,2,(SLuint32)(SAMPLE_RATE*1000),
            SL_PCMSAMPLEFORMAT_FIXED_16,SL_PCMSAMPLEFORMAT_FIXED_16,
            SL_SPEAKER_FRONT_LEFT|SL_SPEAKER_FRONT_RIGHT,SL_BYTEORDER_LITTLEENDIAN};
        SLDataSource src={&bq,&fmt};
        SLDataLocator_OutputMix outMix={SL_DATALOCATOR_OUTPUTMIX,_mixObj};
        SLDataSink sink={&outMix,nullptr};

        const SLInterfaceID pids[]={SL_IID_BUFFERQUEUE};
        const SLboolean preq[]={SL_BOOLEAN_TRUE};
        (*_engine)->CreateAudioPlayer(_engine,&_playerObj,&src,&sink,1,pids,preq);
        (*_playerObj)->Realize(_playerObj,SL_BOOLEAN_FALSE);
        (*_playerObj)->GetInterface(_playerObj,SL_IID_PLAY,&_player);
        (*_playerObj)->GetInterface(_playerObj,SL_IID_BUFFERQUEUE,&_bufQueue);
        (*_player)->SetPlayState(_player,SL_PLAYSTATE_PLAYING);
    }

    void _shutdownPlatform() {
        if(_playerObj){ (*_playerObj)->Destroy(_playerObj); _playerObj=nullptr; }
        if(_mixObj)   { (*_mixObj)->Destroy(_mixObj);       _mixObj=nullptr; }
        if(_engineObj){ (*_engineObj)->Destroy(_engineObj); _engineObj=nullptr; }
    }

    void _submitAudio(i16* data, u32 frames) {
        if(_bufQueue)
            (*_bufQueue)->Enqueue(_bufQueue, data, frames*2*sizeof(i16));
    }
#else
    void _initPlatform()    {}
    void _shutdownPlatform(){}
    void _submitAudio(i16*, u32) {}
#endif
};

} // namespace Nova
