package com.nova.engine

import android.content.Context
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.os.Handler
import android.os.HandlerThread

// ═══════════════════════════════════════════════════════
//  NOVA NATIVE — جسر Kotlin ↔ C++
//  يربط NOVA Engine بـ Android
// ═══════════════════════════════════════════════════════

object NovaNative {
    init {
        System.loadLibrary("nova-engine")
    }

    // ── JNI Functions (implemented in C++) ──
    external fun init(surface: Surface)
    external fun shutdown()
    external fun renderFrame()
    external fun surfaceChanged(width: Int, height: Int)
    external fun getBenchmarkReport(): String
    external fun getBestQuality(): Int

    // ── Touch Input ──
    external fun onTouchDown(x: Float, y: Float, pointerId: Int)
    external fun onTouchMove(x: Float, y: Float, pointerId: Int)
    external fun onTouchUp(pointerId: Int)

    // ── Quality Names ──
    val qualityNames = arrayOf(
        "480p", "720p", "1080p",
        "2K (غير حقيقي)", "2K (حقيقي)", "4K"
    )
}

// ═══════════════════════════════════════════════════════
//  NOVA SURFACE VIEW — السطح الذي يُرسم عليه
// ═══════════════════════════════════════════════════════
class NovaSurfaceView(context: Context) : SurfaceView(context),
    SurfaceHolder.Callback
{
    private var renderThread: HandlerThread? = null
    private var renderHandler: Handler? = null
    private var running = false

    init {
        holder.addCallback(this)
        holder.setFormat(android.graphics.PixelFormat.RGBX_8888)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        NovaNative.init(holder.surface)
        startRenderLoop()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        NovaNative.surfaceChanged(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        stopRenderLoop()
        NovaNative.shutdown()
    }

    private fun startRenderLoop() {
        running = true
        renderThread = HandlerThread("NovaRenderThread").also { it.start() }
        renderHandler = Handler(renderThread!!.looper)
        scheduleFrame()
    }

    private fun stopRenderLoop() {
        running = false
        renderThread?.quitSafely()
        renderThread = null
        renderHandler = null
    }

    private fun scheduleFrame() {
        renderHandler?.post {
            if(running) {
                NovaNative.renderFrame()
                scheduleFrame()
            }
        }
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        val action = event.actionMasked
        val idx    = event.actionIndex
        val pid    = event.getPointerId(idx)
        val x      = event.getX(idx)
        val y      = event.getY(idx)

        when(action) {
            android.view.MotionEvent.ACTION_DOWN,
            android.view.MotionEvent.ACTION_POINTER_DOWN ->
                NovaNative.onTouchDown(x, y, pid)
            android.view.MotionEvent.ACTION_MOVE -> {
                for(i in 0 until event.pointerCount)
                    NovaNative.onTouchMove(event.getX(i), event.getY(i), event.getPointerId(i))
            }
            android.view.MotionEvent.ACTION_UP,
            android.view.MotionEvent.ACTION_POINTER_UP ->
                NovaNative.onTouchUp(pid)
        }
        return true
    }
}

// ═══════════════════════════════════════════════════════
//  NOVA ACTIVITY — النشاط الرئيسي للعبة
// ═══════════════════════════════════════════════════════
class NovaActivity : android.app.Activity() {

    private lateinit var surfaceView: NovaSurfaceView

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)

        // Full screen
        window.setFlags(
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        surfaceView = NovaSurfaceView(this)
        setContentView(surfaceView)
    }

    override fun onPause()  { super.onPause() }
    override fun onResume() { super.onResume() }
    override fun onDestroy(){ super.onDestroy() }
}
