// stub.cpp — placeholder حتى تُضاف الجلسات التالية
#include "../../Nova.h"
