#pragma once
#include "../Nova.h"
#include "../renderer/SoftwareRenderer.h"
#include "../renderer/PerformanceTest.h"

// Android NDK headers
#ifdef NOVA_PLATFORM_ANDROID
    #include <android/native_window.h>
    #include <android/native_window_jni.h>
    #include <android/bitmap.h>
    #include <jni.h>
#endif

namespace Nova {

// ═══════════════════════════════════════════════════════
//  ANDROID RENDERER
//  يعرض نتيجة SoftwareRenderer على شاشة Android
//  بدون OpenGL — يكتب مباشرة في ANativeWindow
// ═══════════════════════════════════════════════════════
class AndroidRenderer {
public:
    SoftwareRenderer  renderer;
    QualityManager    qualityMgr;

#ifdef NOVA_PLATFORM_ANDROID
    ANativeWindow* window = nullptr;

    bool init(ANativeWindow* win) {
        window = win;
        ANativeWindow_acquire(window);

        // الحصول على أبعاد الشاشة
        u32 w = ANativeWindow_getWidth(window);
        u32 h = ANativeWindow_getHeight(window);

        // تهيئة renderer بحجم الشاشة
        renderer.init(w, h);

        // تشغيل اختبار الأداء
        qualityMgr.initialize(renderer);

        return true;
    }

    void shutdown() {
        renderer.shutdown();
        if(window) {
            ANativeWindow_release(window);
            window = nullptr;
        }
    }

    // ── نقل الـ Framebuffer إلى شاشة Android ──
    void present() {
        if(!window) return;

        ANativeWindow_Buffer buffer;
        ARect bounds = {0, 0,
            (i32)renderer.getStats().width,
            (i32)renderer.getStats().height};

        if(ANativeWindow_lock(window, &buffer, &bounds) < 0)
            return;

        const Pixel* src  = renderer.getPixelData();
        u32*         dst  = static_cast<u32*>(buffer.bits);
        u32 w = renderer.getStats().width;
        u32 h = renderer.getStats().height;
        i32 stride = buffer.stride;

        // نسخ البكسلات بتنسيق ARGB8888 (تنسيق Android)
        for(u32 y = 0; y < h; y++) {
            for(u32 x = 0; x < w; x++) {
                const Pixel& p = src[y * w + x];
                dst[y * stride + x] =
                    (0xFF      << 24) |   // Alpha
                    ((u32)p.r  << 16) |   // R
                    ((u32)p.g  <<  8) |   // G
                    ((u32)p.b  <<  0);    // B
            }
        }

        ANativeWindow_unlockAndPost(window);
    }

    // ── Resize عند تدوير الشاشة ──
    void onSurfaceChanged(u32 w, u32 h) {
        renderer.resize(w, h);
        ANativeWindow_setBuffersGeometry(window, w, h,
            WINDOW_FORMAT_RGBX_8888);
    }
#else
    // Desktop fallback
    bool init(u32 w, u32 h) {
        renderer.init(w, h);
        qualityMgr.initialize(renderer);
        return true;
    }
    void shutdown() { renderer.shutdown(); }
    void present() {}
    void onSurfaceChanged(u32 w, u32 h) { renderer.resize(w, h); }
#endif
};

} // namespace Nova

// ═══════════════════════════════════════════════════════
//  JNI Bridge — ربط C++ بـ Java/Kotlin على Android
// ═══════════════════════════════════════════════════════
#ifdef NOVA_PLATFORM_ANDROID
extern "C" {

static Nova::AndroidRenderer* g_renderer = nullptr;

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_init(JNIEnv* env, jobject obj, jobject surface) {
    ANativeWindow* window = ANativeWindow_fromSurface(env, surface);
    g_renderer = new Nova::AndroidRenderer();
    g_renderer->init(window);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_shutdown(JNIEnv*, jobject) {
    if(g_renderer) {
        g_renderer->shutdown();
        delete g_renderer;
        g_renderer = nullptr;
    }
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_renderFrame(JNIEnv*, jobject) {
    if(g_renderer) {
        g_renderer->renderer.beginFrame();
        // الـ game loop يتحكم بالرسم
        g_renderer->renderer.endFrame();
        g_renderer->present();
    }
}

JNIEXPORT void JNICALL
Java_com_nova_engine_NovaNative_surfaceChanged(
    JNIEnv*, jobject, jint w, jint h)
{
    if(g_renderer)
        g_renderer->onSurfaceChanged(w, h);
}

JNIEXPORT jstring JNICALL
Java_com_nova_engine_NovaNative_getBenchmarkReport(JNIEnv* env, jobject) {
    if(!g_renderer) return env->NewStringUTF("لا يوجد renderer");
    std::string report = g_renderer->qualityMgr.getTest().generateReport();
    return env->NewStringUTF(report.c_str());
}

JNIEXPORT jint JNICALL
Java_com_nova_engine_NovaNative_getBestQuality(JNIEnv*, jobject) {
    if(!g_renderer) return 0;
    return (jint)g_renderer->qualityMgr.getCurrentQuality();
}

} // extern "C"
#endif
