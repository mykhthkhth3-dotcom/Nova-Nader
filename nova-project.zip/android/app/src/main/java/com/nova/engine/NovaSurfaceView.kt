package com.nova.engine

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.view.*

// ═══════════════════════════════════════════════════════
//  NOVA SURFACE VIEW — سطح الرسم الرئيسي
// ═══════════════════════════════════════════════════════

class NovaSurfaceView(context: Context) : SurfaceView(context),
    SurfaceHolder.Callback {

    private var renderThread: HandlerThread? = null
    private var renderHandler: Handler? = null
    private var running = false
    private var surfaceReady = false

    init {
        holder.addCallback(this)
        holder.setFormat(android.graphics.PixelFormat.RGBX_8888)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        NovaNative.engineInit(holder.surface)
        surfaceReady = true
        _startRenderLoop()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        NovaNative.engineSurfaceChanged(w, h)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        _stopRenderLoop()
        NovaNative.engineShutdown()
        surfaceReady = false
    }

    private fun _startRenderLoop() {
        running = true
        renderThread = HandlerThread("NovaRender", android.os.Process.THREAD_PRIORITY_DISPLAY)
        renderThread!!.start()
        renderHandler = Handler(renderThread!!.looper)
        _scheduleFrame()
    }

    private fun _stopRenderLoop() {
        running = false
        renderThread?.quitSafely()
        renderThread?.join(500)
        renderThread = null
        renderHandler = null
    }

    private fun _scheduleFrame() {
        renderHandler?.post {
            if(running && surfaceReady) {
                NovaNative.engineTick()
                _scheduleFrame()
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = event.actionIndex
                NovaNative.engineTouchDown(
                    event.getX(idx), event.getY(idx),
                    event.getPointerId(idx)
                )
            }
            MotionEvent.ACTION_MOVE -> {
                for(i in 0 until event.pointerCount) {
                    NovaNative.engineTouchMove(
                        event.getX(i), event.getY(i),
                        event.getPointerId(i)
                    )
                }
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_POINTER_UP,
            MotionEvent.ACTION_CANCEL -> {
                val idx = event.actionIndex
                NovaNative.engineTouchUp(event.getPointerId(idx))
            }
        }
        return true
    }
}
