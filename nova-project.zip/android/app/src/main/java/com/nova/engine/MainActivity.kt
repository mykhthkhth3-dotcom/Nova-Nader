package com.nova.engine

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import com.nova.engine.ads.AdManager
import com.nova.engine.ai.AIBuilderActivity

// ═══════════════════════════════════════════════════════
//  MAIN ACTIVITY — نشاط NOVA Engine الرئيسي
// ═══════════════════════════════════════════════════════

class MainActivity : Activity() {

    private lateinit var surfaceView: NovaSurfaceView
    private lateinit var adManager: AdManager
    private lateinit var overlayLayout: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full screen immersive
        _setupFullscreen()

        // Root layout
        overlayLayout = FrameLayout(this)
        setContentView(overlayLayout)

        // ── Game Surface ──
        surfaceView = NovaSurfaceView(this)
        overlayLayout.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // ── AdMob ──
        adManager = AdManager(this)
        adManager.initialize()
        adManager.loadBanner(overlayLayout)
        adManager.loadInterstitial()
        adManager.loadRewarded()

        // ── Menu Button (إذهاب لـ AI Builder) ──
        val btnMenu = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_more)
            setBackgroundColor(android.graphics.Color.parseColor("#88000000"))
            setOnClickListener { _openMenu() }
        }
        overlayLayout.addView(btnMenu, FrameLayout.LayoutParams(dp(48), dp(48)).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.END
            topMargin = dp(8); rightMargin = dp(8)
        })
    }

    override fun onResume() {
        super.onResume()
        adManager.onResume()
    }

    override fun onPause() {
        super.onPause()
        adManager.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        adManager.onDestroy()
    }

    private fun _openMenu() {
        val menu = PopupMenu(this, overlayLayout)
        menu.menu.add(0, 1, 0, "🤖 AI Builder")
        menu.menu.add(0, 2, 0, "📊 اختبار الأداء")
        menu.menu.add(0, 3, 0, "⚙ الإعدادات")
        menu.setOnMenuItemClickListener { item ->
            when(item.itemId) {
                1 -> startActivity(Intent(this, AIBuilderActivity::class.java))
                2 -> _showBenchmark()
                3 -> _showSettings()
            }
            true
        }
        menu.show()
    }

    private fun _showBenchmark() {
        val report = NovaNative.getBenchmarkReport()
        android.app.AlertDialog.Builder(this)
            .setTitle("📊 اختبار الأداء")
            .setMessage(report)
            .setPositiveButton("موافق", null)
            .show()
    }

    private fun _showSettings() {
        // يمكن توسيعها لاحقاً
        Toast.makeText(this, "الإعدادات قريباً", Toast.LENGTH_SHORT).show()
    }

    private fun _setupFullscreen() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if(android.os.Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val decorView = window.decorView
        decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
