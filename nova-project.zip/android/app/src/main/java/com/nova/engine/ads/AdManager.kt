package com.nova.engine.ads

import android.app.Activity
import android.view.*
import android.widget.FrameLayout
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.*
import com.google.android.gms.ads.rewarded.*
import com.google.android.gms.ads.rewardedinterstitial.*

// ═══════════════════════════════════════════════════════
//  AD MANAGER — إدارة إعلانات AdMob الكاملة
//  Banner + Interstitial + Rewarded + Rewarded Interstitial
//  استبدل IDs الاختبار بـ IDs الحقيقية عند النشر
// ═══════════════════════════════════════════════════════

class AdManager(private val activity: Activity) {

    // ── Ad Unit IDs (Test IDs — غيّر عند النشر) ──
    companion object {
        // Banner
        const val BANNER_ID         = "ca-app-pub-3940256099942544/6300978111"
        // Interstitial
        const val INTERSTITIAL_ID   = "ca-app-pub-3940256099942544/1033173712"
        // Rewarded
        const val REWARDED_ID       = "ca-app-pub-3940256099942544/5224354917"
        // Rewarded Interstitial
        const val REWARDED_INT_ID   = "ca-app-pub-3940256099942544/5354046379"

        // إنتاج — استبدل هذه بـ IDs الحقيقية
        // const val BANNER_ID       = "ca-app-pub-XXXXX/XXXXX"
        // const val INTERSTITIAL_ID = "ca-app-pub-XXXXX/XXXXX"
        // const val REWARDED_ID     = "ca-app-pub-XXXXX/XXXXX"
    }

    private var bannerAd: AdView? = null
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var rewardedIntAd: RewardedInterstitialAd? = null

    private var bannerContainer: FrameLayout? = null
    private var adSessionCount = 0

    // ── Initialize ──
    fun initialize() {
        MobileAds.initialize(activity) { initStatus ->
            val statusMap = initStatus.adapterStatusMap
            for((adapter, status) in statusMap) {
                android.util.Log.d("AdMob", "Adapter: $adapter, Status: ${status.initializationState}")
            }
        }

        // Request configuration
        val config = RequestConfiguration.Builder()
            .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE)
            .build()
        MobileAds.setRequestConfiguration(config)
    }

    // ── Banner Ad ──
    fun loadBanner(parent: FrameLayout) {
        bannerContainer = parent

        bannerAd = AdView(activity).apply {
            adUnitId = BANNER_ID
            setAdSize(AdSize.BANNER)

            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    android.util.Log.d("AdMob", "Banner loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    android.util.Log.e("AdMob", "Banner failed: ${error.message}")
                    // إعادة المحاولة بعد 30 ثانية
                    activity.window.decorView.postDelayed({ loadBanner(parent) }, 30000)
                }
            }
        }

        val params = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL }

        parent.addView(bannerAd, params)
        bannerAd?.loadAd(buildRequest())
    }

    fun showBanner()  { bannerAd?.visibility = android.view.View.VISIBLE }
    fun hideBanner()  { bannerAd?.visibility = android.view.View.GONE }

    // ── Interstitial Ad ──
    fun loadInterstitial() {
        InterstitialAd.load(
            activity, INTERSTITIAL_ID, buildRequest(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            loadInterstitial() // إعادة التحميل
                        }
                        override fun onAdFailedToShowFullScreenContent(e: AdError) {
                            interstitialAd = null
                            loadInterstitial()
                        }
                    }
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    android.util.Log.e("AdMob", "Interstitial failed: ${error.message}")
                    activity.window.decorView.postDelayed({ loadInterstitial() }, 60000)
                }
            }
        )
    }

    fun showInterstitial(onDismissed: (() -> Unit)? = null): Boolean {
        val ad = interstitialAd ?: return false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                loadInterstitial()
                onDismissed?.invoke()
            }
        }
        ad.show(activity)
        return true
    }

    // ── Rewarded Ad ──
    fun loadRewarded() {
        RewardedAd.load(
            activity, REWARDED_ID, buildRequest(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    android.util.Log.d("AdMob", "Rewarded loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    android.util.Log.e("AdMob", "Rewarded failed: ${error.message}")
                    activity.window.decorView.postDelayed({ loadRewarded() }, 60000)
                }
            }
        )
    }

    fun showRewarded(
        onRewarded: (RewardItem) -> Unit,
        onDismissed: (() -> Unit)? = null
    ): Boolean {
        val ad = rewardedAd ?: return false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewarded()
                onDismissed?.invoke()
            }
            override fun onAdFailedToShowFullScreenContent(e: AdError) {
                rewardedAd = null
                loadRewarded()
            }
        }
        ad.show(activity) { reward -> onRewarded(reward) }
        return true
    }

    // ── Auto Show Logic ──
    fun onGameEvent(event: GameEvent) {
        adSessionCount++
        when(event) {
            GameEvent.LEVEL_COMPLETE -> {
                // أظهر Interstitial كل 3 مستويات
                if(adSessionCount % 3 == 0) showInterstitial()
            }
            GameEvent.PLAYER_DIED -> {
                // أظهر Rewarded لمنح حياة إضافية
                if(rewardedAd != null) {
                    showRewarded(
                        onRewarded = { reward ->
                            android.util.Log.d("AdMob", "Reward: ${reward.type} x${reward.amount}")
                            // أخبر المحرك بالمكافأة عبر JNI
                            NovaNative.onAdReward(reward.type, reward.amount)
                        }
                    )
                }
            }
            GameEvent.GAME_OVER -> {
                showInterstitial()
            }
            GameEvent.APP_OPEN -> {
                // يمكن إضافة App Open Ad هنا
            }
        }
    }

    enum class GameEvent {
        LEVEL_COMPLETE, PLAYER_DIED, GAME_OVER, APP_OPEN
    }

    // ── Lifecycle ──
    fun onResume()  { bannerAd?.resume() }
    fun onPause()   { bannerAd?.pause() }
    fun onDestroy() { bannerAd?.destroy() }

    // ── Request Builder ──
    private fun buildRequest(): AdRequest {
        return AdRequest.Builder().build()
    }
}

// ── JNI Callback for Rewards ──
object NovaNative {
    init { System.loadLibrary("nova-engine") }
    external fun getBenchmarkReport(): String
    external fun onAdReward(type: String, amount: Int)
    external fun engineInit(surface: android.view.Surface)
    external fun engineTick()
    external fun engineShutdown()
    external fun engineSurfaceChanged(w: Int, h: Int)
    external fun engineTouchDown(x: Float, y: Float, id: Int)
    external fun engineTouchMove(x: Float, y: Float, id: Int)
    external fun engineTouchUp(id: Int)
}
