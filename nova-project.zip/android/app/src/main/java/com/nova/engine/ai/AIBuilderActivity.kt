package com.nova.engine.ai

import android.app.Activity
import android.os.Bundle
import com.nova.engine.ai.AIBuilderScreen

// ═══════════════════════════════════════════════════════
//  AI BUILDER ACTIVITY
// ═══════════════════════════════════════════════════════

class AIBuilderActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(AIBuilderScreen(this))
    }
}
