#include <jni.h>
#include <android/log.h>
#include <android/native_window_jni.h>
#include "Nova.h"
#include "core/Engine.h"
#include "ai/AIBuilder.h"

#define LOG_TAG "NOVAEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ═══════════════════════════════════════════════════════
//  NOVA ENGINE JNI — جسر C++ ↔ Kotlin/Java
//  يجمع كل نقاط الدخول JNI في ملف واحد
// ═══════════════════════════════════════════════════════

// ── Global Instances ──
static Nova::Engine*     g_engine    = nullptr;
static Nova::AIBuilder*  g_aiBuilder = nullptr;
static JavaVM*           g_jvm       = nullptr;

// HTTP callback از Java
static jmethodID g_httpMethod = nullptr;
static jobject   g_httpObj    = nullptr;

extern "C" {

// ════════════════════════════════════════
//  JNI_OnLoad
// ════════════════════════════════════════
JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
    g_jvm = vm;
    LOGI("NOVA Engine JNI loaded");
    return JNI_VERSION_1_6;
}

// ════════════════════════════════════════
//  ENGINE — نقاط دخول المحرك الرئيسي
// ════════════════════════════════════════
JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_engineInit(JNIEnv* env, jobject obj, jobject surface) {
    LOGI("engineInit called");
    if(g_engine) { delete g_engine; g_engine=nullptr; }

    g_engine = new Nova::Engine();
    Nova::EngineConfig cfg;
    cfg.autoQuality    = true;
    cfg.mobileControls = true;
    cfg.enableAudio    = true;
    cfg.enablePhysics  = true;
    cfg.maxParticles   = 8000;
    g_engine->init(cfg);

    ANativeWindow* win = ANativeWindow_fromSurface(env, surface);
    if(win) {
        g_engine->renderer.init(win);
        LOGI("Surface initialized: %dx%d",
            ANativeWindow_getWidth(win),
            ANativeWindow_getHeight(win));
    }
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_engineTick(JNIEnv*, jobject) {
    if(g_engine) g_engine->tick();
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_engineShutdown(JNIEnv*, jobject) {
    LOGI("engineShutdown called");
    if(g_engine) { g_engine->shutdown(); delete g_engine; g_engine=nullptr; }
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_engineSurfaceChanged(JNIEnv*, jobject, jint w, jint h) {
    LOGI("Surface changed: %dx%d", w, h);
    if(g_engine) g_engine->onSurfaceChanged(w, h);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_engineTouchDown(JNIEnv*, jobject, jfloat x, jfloat y, jint id) {
    if(g_engine) g_engine->onTouchDown(x, y, (Nova::u32)id);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_engineTouchMove(JNIEnv*, jobject, jfloat x, jfloat y, jint id) {
    if(g_engine) g_engine->onTouchMove(x, y, (Nova::u32)id);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_engineTouchUp(JNIEnv*, jobject, jint id) {
    if(g_engine) g_engine->onTouchUp((Nova::u32)id);
}

JNIEXPORT jstring JNICALL
Java_com_nova_engine_ads_NovaNative_getBenchmarkReport(JNIEnv* env, jobject) {
    if(!g_engine) return env->NewStringUTF("المحرك غير مهيأ");
    std::string report = g_engine->quality.getTest().generateReport();
    return env->NewStringUTF(report.c_str());
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ads_NovaNative_onAdReward(JNIEnv*, jobject, jstring type, jint amount) {
    // مكافأة الإعلان — يمكن إخبار اللعبة
    LOGI("Ad reward: amount=%d", amount);
    if(g_engine) {
        // مثال: إعطاء اللاعب حياة إضافية أو عملات
        // g_engine->scene.findNode("Player")->getComponent<PlayerScript>()->addLives(1);
    }
}

// ════════════════════════════════════════
//  AI BUILDER — نقاط دخول AI Builder
// ════════════════════════════════════════
JNIEXPORT void JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeInit(JNIEnv* env, jobject obj) {
    if(g_aiBuilder) { delete g_aiBuilder; }
    g_aiBuilder = new Nova::AIBuilder();

    // ربط HTTP provider بـ Java
    g_httpObj = env->NewGlobalRef(obj);
    jclass cls = env->GetObjectClass(obj);
    g_httpMethod = env->GetStaticMethodID(cls, "httpRequest",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");

    // تعيين الـ HTTP provider
    g_aiBuilder->httpProvider = [](const std::string& url,
                                    const std::string& key,
                                    const std::string& body) -> Nova::HttpResponse
    {
        if(!g_jvm || !g_httpMethod || !g_httpObj)
            return {0, "", false};

        JNIEnv* jenv = nullptr;
        bool attached = false;
        if(g_jvm->GetEnv((void**)&jenv, JNI_VERSION_1_6) == JNI_EDETACHED) {
            g_jvm->AttachCurrentThread(&jenv, nullptr);
            attached = true;
        }

        jstring jUrl  = jenv->NewStringUTF(url.c_str());
        jstring jKey  = jenv->NewStringUTF(key.c_str());
        jstring jBody = jenv->NewStringUTF(body.c_str());

        jstring result = (jstring)jenv->CallStaticObjectMethod(
            jenv->GetObjectClass(g_httpObj), g_httpMethod, jUrl, jKey, jBody
        );

        Nova::HttpResponse resp;
        if(result) {
            const char* str = jenv->GetStringUTFChars(result, nullptr);
            std::string s(str);
            jenv->ReleaseStringUTFChars(result, str);

            // Format: "STATUS_CODE\nbody"
            size_t nl = s.find('\n');
            if(nl != std::string::npos) {
                resp.statusCode = (Nova::u32)std::stoul(s.substr(0, nl));
                resp.body       = s.substr(nl+1);
                resp.ok         = resp.statusCode == 200;
            }
        }

        jenv->DeleteLocalRef(jUrl);
        jenv->DeleteLocalRef(jKey);
        jenv->DeleteLocalRef(jBody);

        if(attached) g_jvm->DetachCurrentThread();
        return resp;
    };

    // Logging callback
    g_aiBuilder->onLog = [](const std::string& level, const std::string& msg) {
        if(level=="ERROR") LOGE("[AI] %s", msg.c_str());
        else LOGI("[AI] %s", msg.c_str());
    };

    LOGI("AI Builder initialized");
}

JNIEXPORT jboolean JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeAddWorker(
    JNIEnv* env, jobject,
    jstring jId, jstring jName, jstring jKey,
    jstring jModel, jint maxTok, jint rpm, jint priority)
{
    if(!g_aiBuilder) return JNI_FALSE;

    Nova::AIWorkerConfig w;
    auto jstr = [&](jstring s) -> std::string {
        const char* c = env->GetStringUTFChars(s, nullptr);
        std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
    };

    w.id        = jstr(jId);
    w.name      = jstr(jName);
    w.apiKey    = jstr(jKey);
    w.model     = jstr(jModel);
    w.maxTokens = (Nova::u32)maxTok;
    w.rpm       = (Nova::u32)rpm;
    w.priority  = (Nova::u32)priority;

    return g_aiBuilder->addWorker(w) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeSetOrchestrator(
    JNIEnv* env, jobject,
    jstring jId, jstring jName, jstring jKey,
    jstring jModel, jint maxTok, jint rpm)
{
    if(!g_aiBuilder) return JNI_FALSE;

    Nova::AIWorkerConfig w;
    auto jstr = [&](jstring s) -> std::string {
        const char* c = env->GetStringUTFChars(s, nullptr);
        std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
    };

    w.id        = jstr(jId);
    w.name      = jstr(jName);
    w.apiKey    = jstr(jKey);
    w.model     = jstr(jModel);
    w.maxTokens = (Nova::u32)maxTok;
    w.rpm       = (Nova::u32)rpm;

    return g_aiBuilder->setOrchestrator(w) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeRemoveWorker(JNIEnv* env, jobject, jstring jId) {
    if(!g_aiBuilder) return;
    const char* c = env->GetStringUTFChars(jId, nullptr);
    g_aiBuilder->removeWorker(c);
    env->ReleaseStringUTFChars(jId, c);
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeClearWorkers(JNIEnv*, jobject) {
    if(g_aiBuilder) g_aiBuilder->clearWorkers();
}

JNIEXPORT jint JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeGetWorkerCount(JNIEnv*, jobject) {
    return g_aiBuilder ? (jint)g_aiBuilder->getWorkerCount() : 0;
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeBuild(
    JNIEnv* env, jobject,
    jstring jName, jstring jDesc, jstring jType, jstring jLang, jboolean multiApi)
{
    if(!g_aiBuilder) return;

    auto jstr = [&](jstring s) -> std::string {
        const char* c = env->GetStringUTFChars(s, nullptr);
        std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
    };

    g_aiBuilder->buildProject(
        jstr(jName), jstr(jDesc), jstr(jType), jstr(jLang),
        multiApi == JNI_TRUE
    );
}

JNIEXPORT void JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeCancel(JNIEnv*, jobject) {
    if(g_aiBuilder) g_aiBuilder->cancel();
}

JNIEXPORT jboolean JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeIsRunning(JNIEnv*, jobject) {
    return (g_aiBuilder && g_aiBuilder->isRunning()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeGetOutputFiles(JNIEnv* env, jobject) {
    if(!g_aiBuilder) return env->NewStringUTF("{}");

    std::string json = "{";
    bool first = true;
    for(auto& [name, code] : g_aiBuilder->getOutputFiles()) {
        if(!first) json += ",";
        // Escape JSON
        auto esc = [](const std::string& s) {
            std::string r;
            for(char c:s) {
                if(c=='"')  r+="\\\"";
                else if(c=='\\') r+="\\\\";
                else if(c=='\n') r+="\\n";
                else r+=c;
            }
            return r;
        };
        json += "\"" + esc(name) + "\":\"" + esc(code) + "\"";
        first = false;
    }
    json += "}";
    return env->NewStringUTF(json.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_nova_engine_ai_AIBuilderBridge_nativeGetStats(JNIEnv* env, jobject) {
    if(!g_aiBuilder) return env->NewStringUTF("{}");

    auto& s = g_aiBuilder->getStats();
    char buf[512];
    snprintf(buf, sizeof(buf),
        "{\"phase\":\"%s\",\"progress\":%.1f,\"totalFiles\":%u,"
        "\"totalLines\":%u,\"totalRequests\":%u,\"totalTokens\":%u,"
        "\"elapsedSec\":%.2f,\"lastLog\":\"%s\"}",
        s.phase.c_str(), s.progressPct,
        s.totalFiles, s.totalLines,
        s.totalRequests, s.totalTokens,
        s.elapsedSec, s.lastLog.c_str()
    );
    return env->NewStringUTF(buf);
}

} // extern "C"
