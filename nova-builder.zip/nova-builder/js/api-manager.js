// ═══════════════════════════════════════
//  NOVA BUILDER — API MANAGER
// ═══════════════════════════════════════

const ApiManager = {
  apis: [],

  load() { this.apis = Storage.getApis(); },

  save() { Storage.saveApis(this.apis); },

  add(api) {
    api.id = 'api_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
    api.createdAt = Date.now();
    api.usageCount = 0;
    api.totalTokens = 0;
    this.apis.push(api);
    this.save();
    return api;
  },

  remove(id) {
    this.apis = this.apis.filter(a => a.id !== id);
    this.save();
  },

  get(id) { return this.apis.find(a => a.id === id); },

  getAll() { return this.apis; },

  updateUsage(id, tokens) {
    const api = this.get(id);
    if(api){ api.usageCount++; api.totalTokens = (api.totalTokens||0)+tokens; this.save(); }
  },

  // ── Single request to ONE api ──
  async request(apiId, messages, systemPrompt='', maxTokens=4000, model='') {
    const api = this.get(apiId);
    if(!api) throw new Error('API غير موجود: '+apiId);

    const m = model || api.model || 'claude-sonnet-4-20250514';
    const tok = maxTokens || api.maxTokens || 4000;

    const body = {
      model: m,
      max_tokens: tok,
      system: systemPrompt || 'أنت مطور خبير. أجب فقط بالكود المطلوب بدون أي شرح أو نص إضافي أو markdown backticks. فقط الكود النظيف المباشر.',
      messages
    };

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': api.key,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify(body)
    });

    if(!res.ok){
      const err = await res.json().catch(()=>({}));
      throw new Error(`API Error ${res.status}: ${err.error?.message||res.statusText}`);
    }

    const data = await res.json();
    const text = (data.content||[]).map(c=>c.text||'').join('').trim();
    const inputTok = data.usage?.input_tokens||0;
    const outputTok = data.usage?.output_tokens||0;
    this.updateUsage(apiId, inputTok+outputTok);

    return { text, inputTokens: inputTok, outputTokens: outputTok };
  },

  // ── Rate-limited request with retry ──
  async rateLimitedRequest(apiId, messages, systemPrompt, maxTokens, model, rpm) {
    const delay = (60/rpm)*1000;
    await this._sleep(delay);
    return this.request(apiId, messages, systemPrompt, maxTokens, model);
  },

  _sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
};
