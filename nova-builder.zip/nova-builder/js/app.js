// ═══════════════════════════════════════
//  NOVA BUILDER — APP CONTROLLER
// ═══════════════════════════════════════

// ── State ──
let buildMode = 'single';
let selectedWorkers = [];
let currentApiEditId = null;

// ── Init ──
window.addEventListener('DOMContentLoaded', () => {
  initSplash();
});

function initSplash() {
  const fill = document.getElementById('splashFill');
  const status = document.getElementById('splashStatus');
  const steps = [
    [10, 'تحميل المكتبات...'],
    [30, 'تهيئة قاعدة البيانات...'],
    [55, 'تحميل APIs...'],
    [75, 'إعداد واجهة المستخدم...'],
    [90, 'الفحص النهائي...'],
    [100, 'جاهز ✓'],
  ];
  let i = 0;
  const run = () => {
    if(i >= steps.length){ setTimeout(launchApp, 400); return; }
    fill.style.width = steps[i][0]+'%';
    status.textContent = steps[i][1];
    i++;
    setTimeout(run, 300+Math.random()*200);
  };
  setTimeout(run, 200);
}

function launchApp() {
  // Load data
  ApiManager.load();

  // Apply theme
  const settings = Storage.getSettings();
  if(settings.theme) document.body.setAttribute('data-theme', settings.theme);

  // Render APIs
  renderApisList();
  renderProjects();
  populateApiSelects();

  // Wire nav buttons
  document.querySelectorAll('.nav-btn[data-view]').forEach(btn => {
    btn.addEventListener('click', () => {
      switchView(btn.dataset.view);
      closeSidebar();
    });
  });

  document.getElementById('menuBtn').addEventListener('click', toggleSidebar);
  document.getElementById('settingsBtn').addEventListener('click', () => {
    switchView('settings'); closeSidebar();
  });

  // Hide splash
  document.getElementById('splash').classList.add('hidden');
  document.getElementById('app').style.display = 'flex';
  setStatus('idle');
}

// ── Navigation ──
function switchView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const v = document.getElementById('view-'+name);
  if(v) v.classList.add('active');
  const b = document.querySelector(`.nav-btn[data-view="${name}"]`);
  if(b) b.classList.add('active');
}

// ── Sidebar ──
function toggleSidebar() {
  const s = document.getElementById('sidebar');
  const o = document.getElementById('sideOverlay');
  const open = s.classList.toggle('sidebar-open');
  o.classList.toggle('visible', open);
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('sidebar-open');
  document.getElementById('sideOverlay').classList.remove('visible');
}

// ── Status ──
function setStatus(state) {
  const d = document.getElementById('statusDot');
  d.className = 'status-dot';
  if(state==='active') d.classList.add('active');
  else if(state==='busy') d.classList.add('busy');
  else if(state==='error') d.classList.add('error');
}
function setIdle(){ setStatus('idle'); }

// ── Mode ──
function setMode(m) {
  buildMode = m;
  document.getElementById('modeSingle').classList.toggle('active', m==='single');
  document.getElementById('modeMulti').classList.toggle('active', m==='multi');
  document.getElementById('singleConfig').style.display = m==='single'?'':'none';
  document.getElementById('multiConfig').style.display = m==='multi'?'':'none';
}

// ── Build ──
function startBuild() {
  const name = document.getElementById('projName').value.trim();
  const desc = document.getElementById('projDesc').value.trim();
  const type = document.getElementById('projType').value;
  const lang = document.getElementById('projLang').value;
  const rpm = parseInt(document.getElementById('rpmSlider').value)||10;
  const maxTok = parseInt(document.getElementById('tokSlider').value)||4000;
  const model = document.getElementById('modelInput').value.trim()||'claude-sonnet-4-20250514';

  if(!name){ alert('أدخل اسم المشروع'); return; }
  if(!desc){ alert('أدخل وصف المشروع'); return; }

  let config = { name, desc, type, lang, rpm, maxTokens:maxTok, model, mode: buildMode };

  if(buildMode === 'single') {
    const apiId = document.getElementById('singleApiSelect').value;
    if(!apiId){ alert('اختر API'); return; }
    config.singleApiId = apiId;
  } else {
    const orchId = document.getElementById('orchApiSelect').value;
    if(!orchId){ alert('اختر API المنظم'); return; }
    if(selectedWorkers.length === 0){ alert('أضف API عمال على الأقل'); return; }
    config.orchApiId = orchId;
    config.workerApiIds = [...selectedWorkers];
  }

  Builder.build(config);
}

function cancelBuild() {
  Builder.cancel();
}

function clearLog() {
  document.getElementById('buildLog').innerHTML = '';
}

// ── Progress ──
function updateProgress(pct, label) {
  document.getElementById('progressFill').style.width = pct+'%';
  document.getElementById('progressLabel').textContent = pct+'%';
  document.getElementById('progressEta').textContent = label||'';
}
function setPhase(phase) {
  document.getElementById('buildPhaseLabel').textContent = phase;
}
function updateStat(id, val) {
  const el = document.getElementById(id);
  if(el) el.textContent = val;
}

// ── API Management ──
function openAddApiModal(editId=null) {
  currentApiEditId = editId;
  if(editId) {
    const api = ApiManager.get(editId);
    if(api){
      document.getElementById('apiName').value = api.name||'';
      document.getElementById('apiKey').value = api.key||'';
      document.getElementById('apiModel').value = api.model||'claude-sonnet-4-20250514';
      document.getElementById('apiRpm').value = api.rpm||10;
      document.getElementById('apiTok').value = api.maxTokens||4000;
      document.getElementById('apiPriority').value = api.priority||2;
    }
  } else {
    document.getElementById('apiName').value = '';
    document.getElementById('apiKey').value = '';
    document.getElementById('apiModel').value = 'claude-sonnet-4-20250514';
    document.getElementById('apiRpm').value = '10';
    document.getElementById('apiTok').value = '4000';
    document.getElementById('apiPriority').value = '2';
  }
  openModal('addApiModal');
}

function saveApi() {
  const name = document.getElementById('apiName').value.trim();
  const key = document.getElementById('apiKey').value.trim();
  const model = document.getElementById('apiModel').value.trim()||'claude-sonnet-4-20250514';
  const rpm = parseInt(document.getElementById('apiRpm').value)||10;
  const maxTokens = parseInt(document.getElementById('apiTok').value)||4000;
  const priority = parseInt(document.getElementById('apiPriority').value)||2;

  if(!name){ alert('أدخل اسم الـ API'); return; }
  if(!key || !key.startsWith('sk-')){ alert('مفتاح API غير صالح — يجب أن يبدأ بـ sk-'); return; }

  if(currentApiEditId) {
    const api = ApiManager.get(currentApiEditId);
    if(api){ Object.assign(api, {name,key,model,rpm,maxTokens,priority}); ApiManager.save(); }
  } else {
    ApiManager.add({name,key,model,rpm,maxTokens,priority});
  }

  closeModal('addApiModal');
  renderApisList();
  populateApiSelects();
}

function deleteApi(id) {
  if(confirm('حذف هذا الـ API؟')) {
    ApiManager.remove(id);
    selectedWorkers = selectedWorkers.filter(w=>w!==id);
    renderApisList();
    renderWorkerList();
    populateApiSelects();
  }
}

function toggleKey() {
  const inp = document.getElementById('apiKey');
  inp.type = inp.type==='password'?'text':'password';
}

function renderApisList() {
  const container = document.getElementById('apisList');
  const apis = ApiManager.getAll();
  if(!apis.length){
    container.innerHTML = '<div class="empty-state">لا توجد APIs — أضف API للبدء</div>';
    return;
  }
  container.innerHTML = apis.map(api=>`
    <div class="api-card">
      <div class="api-icon">🔑</div>
      <div class="api-info">
        <div class="api-name">${api.name}</div>
        <div class="api-meta">${api.model||'claude-sonnet-4-20250514'} | ${api.rpm||10} req/min | ${(api.maxTokens||4000).toLocaleString()} tok</div>
        <div class="api-meta">الاستخدام: ${api.usageCount||0} طلب | ${(api.totalTokens||0).toLocaleString()} توكن</div>
      </div>
      <div class="api-actions">
        <button class="btn-sm" onclick="openAddApiModal('${api.id}')">✏</button>
        <button class="btn-sm" style="color:var(--danger)" onclick="deleteApi('${api.id}')">🗑</button>
      </div>
    </div>
  `).join('');
}

function populateApiSelects() {
  const apis = ApiManager.getAll();
  const opts = '<option value="">— اختر —</option>' + apis.map(a=>`<option value="${a.id}">${a.name}</option>`).join('');
  document.getElementById('singleApiSelect').innerHTML = opts;
  document.getElementById('orchApiSelect').innerHTML = opts;
}

// ── Multi API Workers ──
function openApiPicker() {
  const apis = ApiManager.getAll();
  if(!apis.length){ alert('أضف APIs أولاً من قسم إدارة APIs'); return; }
  document.getElementById('apiPickerList').innerHTML = apis.map(a=>`
    <label class="api-pick-item">
      <input type="checkbox" value="${a.id}" ${selectedWorkers.includes(a.id)?'checked':''} onchange="onWorkerCheck(this)">
      <div class="api-pick-name">${a.name}</div>
      <div class="api-pick-meta">${a.rpm||10}/min | ${(a.maxTokens||4000).toLocaleString()}tok</div>
    </label>
  `).join('');
  openModal('apiPickerModal');
}

function onWorkerCheck(cb) {
  if(cb.checked){
    if(!selectedWorkers.includes(cb.value)){
      if(selectedWorkers.length >= 25){ cb.checked=false; alert('الحد الأقصى 25 API'); return; }
      selectedWorkers.push(cb.value);
    }
  } else {
    selectedWorkers = selectedWorkers.filter(w=>w!==cb.value);
  }
}

function confirmApiPicker() {
  closeModal('apiPickerModal');
  renderWorkerList();
}

function renderWorkerList() {
  const container = document.getElementById('workerList');
  document.getElementById('workerCount').textContent = selectedWorkers.length;
  container.innerHTML = selectedWorkers.map(id=>{
    const api = ApiManager.get(id);
    return `
      <div class="worker-item">
        <span class="worker-name">${api?.name||id}</span>
        <span class="worker-rpm">${api?.rpm||10}/min</span>
        <button class="worker-remove" onclick="removeWorker('${id}')">✕</button>
      </div>
    `;
  }).join('') || '<div style="color:var(--text3);font-size:12px;text-align:center;padding:10px">لا يوجد عمال</div>';
}

function removeWorker(id) {
  selectedWorkers = selectedWorkers.filter(w=>w!==id);
  renderWorkerList();
}

// ── Projects ──
function renderProjects() {
  const container = document.getElementById('projectsList');
  const projects = Storage.getProjects();
  if(!projects.length){
    container.innerHTML = '<div class="empty-state">لا توجد مشاريع — ابدأ بإنشاء مشروع جديد!</div>';
    return;
  }
  container.innerHTML = projects.map(p=>`
    <div class="project-card" onclick="openProject('${p.id}')">
      <div class="project-name">${p.name}</div>
      <div class="project-meta">${new Date(p.createdAt).toLocaleDateString('ar')} | ${p.stats?.files||0} ملفات | ${p.stats?.lines?.toLocaleString()||0} سطر</div>
      <div class="project-tags">
        <span class="project-tag">${p.type}</span>
        <span class="project-tag">${p.lang}</span>
        <span class="project-tag">${p.mode==='multi'?'⚡ متعدد':'🤖 واحد'}</span>
      </div>
    </div>
  `).join('');
}

function openProject(id) {
  const projects = Storage.getProjects();
  const proj = projects.find(p=>p.id===id);
  if(proj){ renderOutput(proj); switchView('output'); }
}

// ── Output ──
function renderOutput(proj) {
  const container = document.getElementById('outputContent');
  const files = proj.files || {};
  if(!Object.keys(files).length){
    container.innerHTML = '<div class="empty-state">لا توجد ملفات</div>';
    return;
  }
  container.innerHTML = `
    <div class="card">
      <div class="card-title">${proj.name} — ${Object.keys(files).length} ملف</div>
      <div class="stats-row">
        <div class="stat-box"><div class="stat-num">${Object.keys(files).length}</div><div class="stat-name">ملفات</div></div>
        <div class="stat-box"><div class="stat-num">${Object.values(files).reduce((s,c)=>s+c.split('\n').length,0).toLocaleString()}</div><div class="stat-name">سطر</div></div>
        <div class="stat-box"><div class="stat-num">${proj.stats?.requests||0}</div><div class="stat-name">طلبات</div></div>
        <div class="stat-box"><div class="stat-num">${(proj.stats?.tokens||0).toLocaleString()}</div><div class="stat-name">توكن</div></div>
      </div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap">
      <button class="btn-primary" onclick="downloadAll('${proj.id}')">⬇ تحميل ZIP</button>
      <button class="btn-ghost" onclick="copyAllCode('${proj.id}')">📋 نسخ الكل</button>
    </div>
    ${Object.entries(files).map(([name,code])=>`
      <div class="output-file">
        <div class="output-icon">${fileIcon(name)}</div>
        <div class="output-name">${name}</div>
        <div class="output-size">${code.split('\n').length} سطر</div>
        <div class="output-actions">
          <button class="btn-sm" onclick="viewCode('${proj.id}','${name}')">👁</button>
          <button class="btn-sm" onclick="downloadFile('${name}',\`${encodeURIComponent(code)}\`)">⬇</button>
        </div>
      </div>
    `).join('')}
  `;
  switchView('output');
  renderProjects();
}

function fileIcon(name) {
  if(name.endsWith('.html')) return '🌐';
  if(name.endsWith('.css')) return '🎨';
  if(name.endsWith('.js')||name.endsWith('.ts')) return '⚡';
  if(name.endsWith('.json')) return '📋';
  if(name.endsWith('.py')) return '🐍';
  if(name.endsWith('.dart')) return '💙';
  if(name.endsWith('.md')) return '📝';
  if(name.endsWith('.cpp')||name.endsWith('.h')) return '⚙';
  return '📄';
}

function viewCode(projId, fileName) {
  const proj = Storage.getProjects().find(p=>p.id===projId);
  if(!proj) return;
  const code = proj.files[fileName]||'';
  document.getElementById('codeModalTitle').textContent = fileName;
  document.getElementById('codeContent').textContent = code;
  openModal('codeModal');
  window._currentCode = code;
}

function copyCode() {
  if(window._currentCode) {
    navigator.clipboard.writeText(window._currentCode).then(()=>alert('تم النسخ!'));
  }
}

function downloadFile(name, encoded) {
  const code = decodeURIComponent(encoded);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([code]));
  a.download = name; a.click();
}

function downloadAll(projId) {
  const proj = Storage.getProjects().find(p=>p.id===projId);
  if(!proj) return;

  // Build a simple ZIP-like bundle as text (real ZIP needs library)
  // For now, create individual downloads
  const files = Object.entries(proj.files||{});
  if(files.length === 0) return;

  // Single file: direct download
  if(files.length === 1) {
    downloadFile(files[0][0], encodeURIComponent(files[0][1]));
    return;
  }

  // Multi: create an HTML bundle with all files embedded
  const bundle = `<!DOCTYPE html>
<!-- NOVA BUILDER EXPORT: ${proj.name} -->
<!-- Generated: ${new Date().toLocaleString('ar')} -->
<!-- Files: ${files.length} -->
<html><head><meta charset="UTF-8"><title>${proj.name} — Export</title>
<style>body{background:#000;color:#0f0;font-family:monospace;padding:20px}h1{color:#0ff}details{margin:10px 0}summary{cursor:pointer;color:#0ff;padding:5px}pre{background:#111;padding:14px;border-radius:6px;overflow-x:auto;white-space:pre-wrap}</style>
</head><body>
<h1>📦 ${proj.name}</h1>
<p style="color:#888">تصدير NOVA Builder — ${files.length} ملف</p>
${files.map(([n,c])=>`<details><summary>${fileIcon(n)} ${n} (${c.split('\n').length} سطر)</summary><pre>${c.replace(/</g,'&lt;')}</pre></details>`).join('')}
</body></html>`;

  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([bundle],{type:'text/html'}));
  a.download = proj.name.replace(/\s+/g,'_')+'_export.html';
  a.click();
}

function copyAllCode(projId) {
  const proj = Storage.getProjects().find(p=>p.id===projId);
  if(!proj) return;
  const all = Object.entries(proj.files||{}).map(([n,c])=>`// ═══ ${n} ═══\n${c}`).join('\n\n');
  navigator.clipboard.writeText(all).then(()=>alert('تم نسخ كل الكود!'));
}

// ── Modals ──
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }

// ── Settings ──
function setTheme(t) {
  document.body.setAttribute('data-theme',t);
  const s = Storage.getSettings();
  s.theme = t; Storage.saveSettings(s);
}

function clearAll() {
  ['nova_apis','nova_projects','nova_settings'].forEach(k=>localStorage.removeItem(k));
  location.reload();
}

// ── New Project ──
document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('newProjectBtn')?.addEventListener('click', ()=>{
    switchView('builder');
    document.getElementById('projName').value = '';
    document.getElementById('projDesc').value = '';
    document.getElementById('buildProgress').style.display = 'none';
  });
});
