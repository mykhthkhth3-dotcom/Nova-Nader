// ═══════════════════════════════════════
//  NOVA BUILDER — BUILD ENGINE
//  يبني المشروع بالكامل باستخدام AI
// ═══════════════════════════════════════

const Builder = {
  running: false,
  cancelled: false,
  currentProject: null,
  outputFiles: {},
  stats: { requests:0, tokens:0, files:0, lines:0 },
  workerStats: {},   // apiId -> {name, state, task, requests, tokens}
  startTime: 0,

  // ── Entry Point ──
  async build(config) {
    this.running = true;
    this.cancelled = false;
    this.outputFiles = {};
    this.stats = { requests:0, tokens:0, files:0, lines:0 };
    this.workerStats = {};
    this.startTime = Date.now();
    this.currentProject = config;

    setStatus('busy');
    document.getElementById('buildProgress').style.display='block';
    document.getElementById('buildBtn').disabled=true;
    document.getElementById('cancelBtn').style.display='';

    this.log('🚀 بدء البناء: '+config.name, 'info');
    this.log(`📋 النوع: ${config.type} | اللغة: ${config.lang}`, 'info');

    try {
      if(config.mode === 'multi') {
        await this.buildMulti(config);
      } else {
        await this.buildSingle(config);
      }

      if(!this.cancelled){
        this.log('✅ اكتمل البناء بنجاح!', 'success');
        this.log(`📊 الملفات: ${this.stats.files} | الأسطر: ${this.stats.lines} | الطلبات: ${this.stats.requests}`, 'success');
        this.finalize(config);
      }
    } catch(err) {
      this.log('❌ خطأ: '+err.message, 'error');
    } finally {
      this.running = false;
      setStatus(this.cancelled?'idle':'active');
      document.getElementById('buildBtn').disabled=false;
      updateProgress(this.cancelled?0:100, this.cancelled?'ملغى':'مكتمل');
    }
  },

  // ══════════════════════════════════════
  //  SINGLE API BUILD
  // ══════════════════════════════════════
  async buildSingle(config) {
    const apiId = config.singleApiId;
    const rpm = config.rpm;
    const maxTok = config.maxTokens;
    const model = config.model;

    this.log(`🤖 API: ${ApiManager.get(apiId)?.name||apiId}`, 'info');

    // Step 1: Plan
    this.log('📐 المرحلة 1: تخطيط الهيكل...', 'orch');
    setPhase('تخطيط');
    updateProgress(5, 'تخطيط المشروع');

    const plan = await this._planProject(apiId, config, rpm, maxTok, model);
    if(this.cancelled) return;

    this.log(`📋 الخطة: ${plan.files.length} ملف`, 'info');

    // Step 2: Build each file
    const total = plan.files.length;
    for(let i=0; i<total; i++){
      if(this.cancelled) return;
      const file = plan.files[i];
      const pct = 10 + Math.round((i/total)*85);
      updateProgress(pct, `بناء: ${file.name}`);
      setPhase(`ملف ${i+1}/${total}`);
      this.log(`🔨 بناء: ${file.name}`, 'info');

      const code = await this._buildFile(apiId, config, plan, file, rpm, maxTok, model);
      if(this.cancelled) return;

      this.addFile(file.name, code);
      this.log(`✓ ${file.name} (${code.split('\n').length} سطر)`, 'code');

      // Rate limit pause
      await this._sleep((60/rpm)*1000);
    }
  },

  // ══════════════════════════════════════
  //  MULTI API BUILD (Orchestrated)
  // ══════════════════════════════════════
  async buildMulti(config) {
    const orchId = config.orchApiId;
    const workers = config.workerApiIds; // array of ids
    const rpm = config.rpm;
    const maxTok = config.maxTokens;
    const model = config.model;

    // Init worker stats
    workers.forEach(id => {
      const api = ApiManager.get(id);
      this.workerStats[id] = { name: api?.name||id, state:'idle', task:'', requests:0, tokens:0 };
    });
    document.getElementById('workersStatus').style.display='block';
    this.renderWorkerStatus();

    this.log(`🎯 Orchestrator: ${ApiManager.get(orchId)?.name||orchId}`, 'orch');
    this.log(`⚡ العمال: ${workers.length} API`, 'info');

    // Step 1: Orchestrator creates plan + assigns tasks
    this.log('🧠 الـ Orchestrator يضع خطة التوزيع...', 'orch');
    setPhase('تخطيط التوزيع');
    updateProgress(5, 'Orchestrator يخطط');

    const plan = await this._orchestratorPlan(orchId, config, workers, rpm, maxTok, model);
    if(this.cancelled) return;

    this.log(`📋 الخطة: ${plan.tasks.length} مهمة على ${workers.length} عامل`, 'orch');

    // Step 2: Distribute tasks to workers
    setPhase('توزيع المهام');
    updateProgress(12, 'توزيع المهام');
    this.log('⚡ توزيع المهام على العمال...', 'orch');

    // Build task queue
    const taskQueue = [...plan.tasks];
    const workerQueue = [...workers];
    const results = {};
    const running = new Map(); // workerId -> Promise

    const processTask = async (workerId, task) => {
      const ws = this.workerStats[workerId];
      ws.state = 'working';
      ws.task = task.file;
      this.renderWorkerStatus();

      this.log(`🔧 [${ws.name}] → ${task.file}`, 'info');

      try {
        const code = await this._buildFileWithContext(
          workerId, config, plan, task, rpm, maxTok, model
        );
        results[task.file] = code;
        ws.state = 'done';
        ws.task = '✓ '+task.file;
        ws.requests++;
        this.addFile(task.file, code);
        this.log(`✓ [${ws.name}] ${task.file} (${code.split('\n').length} سطر)`, 'code');
      } catch(err) {
        ws.state = 'error';
        ws.task = '✗ خطأ';
        this.log(`✗ [${ws.name}] ${task.file}: ${err.message}`, 'error');
        results[task.file] = '// خطأ في البناء: '+err.message;
      }
      this.renderWorkerStatus();
    };

    // Parallel dispatch with pool
    const POOL = Math.min(workers.length, taskQueue.length);
    let taskIndex = 0;
    const totalTasks = taskQueue.length;

    const runWorker = async (workerId) => {
      while(!this.cancelled && taskIndex < taskQueue.length) {
        const task = taskQueue[taskIndex++];
        if(!task) break;
        await processTask(workerId, task);
        const pct = 15 + Math.round((Object.keys(results).length/totalTasks)*80);
        updateProgress(pct, `${Object.keys(results).length}/${totalTasks} ملف`);
        await this._sleep((60/rpm)*1000);
      }
    };

    // Launch all workers
    await Promise.all(workers.map(wid => runWorker(wid)));

    if(this.cancelled) return;

    // Step 3: Orchestrator reviews & integrates
    this.log('🧩 Orchestrator يدمج ويراجع النتائج...', 'orch');
    setPhase('مراجعة ودمج');
    updateProgress(95, 'مراجعة نهائية');

    const integration = await this._orchestratorIntegrate(orchId, config, plan, results, rpm, maxTok, model);
    if(integration && integration.trim()) {
      this.addFile('_integration_notes.md', integration);
    }
  },

  // ══════════════════════════════════════
  //  AI CALLS
  // ══════════════════════════════════════

  async _planProject(apiId, config, rpm, maxTok, model) {
    const res = await this._call(apiId, [
      { role:'user', content: this._planPrompt(config) }
    ], this._systemPrompt('planner'), maxTok, model);

    return this._parsePlan(res.text, config);
  },

  async _orchestratorPlan(orchId, config, workers, rpm, maxTok, model) {
    const workerInfo = workers.map(id=>{
      const a = ApiManager.get(id);
      return `- ${a?.name||id} (${a?.rpm||10} طلب/دقيقة)`;
    }).join('\n');

    const res = await this._call(orchId, [{
      role:'user',
      content: this._orchPlanPrompt(config, workers.length, workerInfo)
    }], this._systemPrompt('orchestrator'), maxTok, model);

    return this._parseOrchPlan(res.text, config, workers);
  },

  async _buildFile(apiId, config, plan, file, rpm, maxTok, model) {
    const res = await this._call(apiId, [{
      role:'user',
      content: this._buildFilePrompt(config, plan, file)
    }], this._systemPrompt('coder'), maxTok, model);

    return this._extractCode(res.text);
  },

  async _buildFileWithContext(workerId, config, plan, task, rpm, maxTok, model) {
    const res = await this._call(workerId, [{
      role:'user',
      content: this._buildTaskPrompt(config, plan, task)
    }], this._systemPrompt('coder'), maxTok, model);

    return this._extractCode(res.text);
  },

  async _orchestratorIntegrate(orchId, config, plan, results, rpm, maxTok, model) {
    const filesSummary = Object.entries(results)
      .map(([f,c])=>`${f}: ${c.split('\n').length} سطر`).join('\n');

    const res = await this._call(orchId, [{
      role:'user',
      content: `راجع هذه الملفات المبنية وأعط ملاحظات التكامل:\nالمشروع: ${config.name}\n\nالملفات:\n${filesSummary}\n\nاكتب فقط ملاحظات التكامل والتوصيل بين الملفات.`
    }], this._systemPrompt('orchestrator'), 2000, model);

    return res.text;
  },

  async _call(apiId, messages, system, maxTok, model) {
    this.stats.requests++;
    updateStat('statRequests', this.stats.requests);
    const res = await ApiManager.request(apiId, messages, system, maxTok, model);
    this.stats.tokens += res.inputTokens + res.outputTokens;
    updateStat('statTokens', this.stats.tokens.toLocaleString());
    if(this.workerStats[apiId]) {
      this.workerStats[apiId].tokens += res.inputTokens+res.outputTokens;
      this.workerStats[apiId].requests++;
    }
    return res;
  },

  // ══════════════════════════════════════
  //  PROMPTS
  // ══════════════════════════════════════

  _systemPrompt(role) {
    const base = 'أنت مطور خبير. أجب فقط بالكود المطلوب دون أي نص إضافي أو شرح أو backticks. الكود النظيف فقط.';
    if(role==='orchestrator') return 'أنت مهندس معمارية خبير ومنظم فرق تطوير. تخطط وتوزع وتنسق. كن دقيقاً وعملياً.';
    if(role==='planner') return 'أنت مهندس برمجيات خبير. تخطط هيكل المشاريع بدقة. أجب بصيغة JSON فقط.';
    return base;
  },

  _planPrompt(config) {
    return `خطط هيكل المشروع التالي وأعطني قائمة الملفات المطلوبة بصيغة JSON:

المشروع: ${config.name}
الوصف: ${config.desc}
النوع: ${config.type}
اللغة/الإطار: ${config.lang}

أعطني JSON بالشكل:
{"files":[{"name":"index.html","desc":"الصفحة الرئيسية","priority":1},{"name":"style.css","desc":"التصميم","priority":2}]}

قائمة الملفات فقط بدون أي نص آخر.`;
  },

  _orchPlanPrompt(config, workerCount, workerInfo) {
    return `أنت Orchestrator. خطط توزيع المهام لهذا المشروع على ${workerCount} عمال:

المشروع: ${config.name}
الوصف: ${config.desc}
النوع: ${config.type}
اللغة: ${config.lang}

العمال المتاحون:
${workerInfo}

أعطني JSON توزيع المهام:
{"tasks":[{"file":"index.html","desc":"الصفحة الرئيسية","priority":1,"complexity":"medium"},{"file":"app.js","desc":"المنطق الرئيسي","priority":2,"complexity":"high"}]}

JSON فقط.`;
  },

  _buildFilePrompt(config, plan, file) {
    const others = plan.files.filter(f=>f.name!==file.name).map(f=>f.name).join(', ');
    return `اكتب الكود الكامل لملف: ${file.name}

المشروع: ${config.name}
الوصف: ${config.desc}
النوع: ${config.type}
اللغة: ${config.lang}
وصف الملف: ${file.desc}
الملفات الأخرى في المشروع: ${others}

الكود الكامل فقط. لا شرح. لا backticks. الكود المباشر فقط.`;
  },

  _buildTaskPrompt(config, plan, task) {
    const others = plan.tasks.filter(t=>t.file!==task.file).map(t=>t.file).join(', ');
    return `اكتب الكود الكامل لملف: ${task.file}

المشروع: ${config.name}
الوصف: ${config.desc}
النوع: ${config.type}
اللغة: ${config.lang}
وصف المهمة: ${task.desc}
التعقيد: ${task.complexity||'medium'}
الملفات الأخرى: ${others}

الكود الكامل فقط. لا شرح. لا backticks. الكود المباشر.`;
  },

  // ══════════════════════════════════════
  //  HELPERS
  // ══════════════════════════════════════

  _parsePlan(text, config) {
    try {
      const clean = text.replace(/```json|```/g,'').trim();
      const obj = JSON.parse(clean);
      if(obj.files && Array.isArray(obj.files)) return obj;
    } catch(e){}

    // Fallback: generate sensible plan
    return this._fallbackPlan(config);
  },

  _parseOrchPlan(text, config, workers) {
    try {
      const clean = text.replace(/```json|```/g,'').trim();
      const obj = JSON.parse(clean);
      if(obj.tasks && Array.isArray(obj.tasks)) return obj;
    } catch(e){}
    return { tasks: this._fallbackPlan(config).files.map(f=>({...f, complexity:'medium'})) };
  },

  _fallbackPlan(config) {
    const lang = config.lang;
    const maps = {
      html: [{name:'index.html',desc:'الصفحة الرئيسية',priority:1},{name:'style.css',desc:'التصميم',priority:2},{name:'app.js',desc:'المنطق',priority:3}],
      react: [{name:'src/App.jsx',desc:'المكون الرئيسي',priority:1},{name:'src/index.js',desc:'نقطة الدخول',priority:2},{name:'src/styles.css',desc:'التصميم',priority:3},{name:'package.json',desc:'الإعدادات',priority:4}],
      python: [{name:'main.py',desc:'الملف الرئيسي',priority:1},{name:'utils.py',desc:'المساعدات',priority:2},{name:'requirements.txt',desc:'المتطلبات',priority:3}],
      flutter: [{name:'lib/main.dart',desc:'نقطة الدخول',priority:1},{name:'lib/app.dart',desc:'التطبيق',priority:2},{name:'pubspec.yaml',desc:'الإعدادات',priority:3}],
      cpp: [{name:'main.cpp',desc:'الملف الرئيسي',priority:1},{name:'CMakeLists.txt',desc:'إعدادات البناء',priority:2}],
    };
    return { files: maps[lang] || maps.html };
  },

  _extractCode(text) {
    // Remove markdown backticks if present
    let code = text.trim();
    const fenced = code.match(/^```[\w]*\n?([\s\S]*?)```$/);
    if(fenced) code = fenced[1].trim();
    return code;
  },

  addFile(name, content) {
    this.outputFiles[name] = content;
    this.stats.files = Object.keys(this.outputFiles).length;
    this.stats.lines = Object.values(this.outputFiles).reduce((s,c)=>s+c.split('\n').length,0);
    updateStat('statFiles', this.stats.files);
    updateStat('statLines', this.stats.lines.toLocaleString());
  },

  finalize(config) {
    // Save project
    const projects = Storage.getProjects();
    const proj = {
      id: 'proj_'+Date.now(),
      name: config.name,
      desc: config.desc,
      type: config.type,
      lang: config.lang,
      mode: config.mode,
      createdAt: Date.now(),
      stats: { ...this.stats },
      files: { ...this.outputFiles }
    };
    projects.unshift(proj);
    Storage.saveProjects(projects);

    // Render output view
    renderOutput(proj);
    document.getElementById('projectTitle').textContent = config.name;
  },

  renderWorkerStatus() {
    const container = document.getElementById('workerStatusList');
    if(!container) return;
    container.innerHTML = Object.entries(this.workerStats).map(([id,ws])=>`
      <div class="worker-status-item">
        <div class="worker-status-dot ${ws.state}"></div>
        <div class="worker-status-name">${ws.name}</div>
        <div class="worker-status-task">${ws.task||'انتظار'}</div>
        <div class="worker-status-count">${ws.requests}طلب</div>
      </div>
    `).join('');
  },

  log(msg, type='') {
    const container = document.getElementById('buildLog');
    if(!container) return;
    const el = document.createElement('div');
    el.className = 'log-entry '+(type||'');
    const time = new Date().toLocaleTimeString('ar',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    el.textContent = `[${time}] ${msg}`;
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
  },

  cancel() {
    this.cancelled = true;
    this.running = false;
    this.log('⛔ تم إلغاء البناء', 'warn');
  },

  _sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
};
