// ═══════════════════════════════════════
//  NOVA BUILDER — STORAGE MODULE
// ═══════════════════════════════════════
const Storage = {
  get(key, def=null){
    try { const v=localStorage.getItem('nova_'+key); return v?JSON.parse(v):def; }
    catch(e){ return def; }
  },
  set(key,val){
    try { localStorage.setItem('nova_'+key, JSON.stringify(val)); return true; }
    catch(e){ return false; }
  },
  del(key){ localStorage.removeItem('nova_'+key); },
  getApis(){ return this.get('apis',[]); },
  saveApis(apis){ this.set('apis',apis); },
  getProjects(){ return this.get('projects',[]); },
  saveProjects(p){ this.set('projects',p); },
  getSettings(){ return this.get('settings',{theme:'dark'}); },
  saveSettings(s){ this.set('settings',s); },
};
